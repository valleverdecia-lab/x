"use client";

import { type ReactNode, useEffect, useState } from "react";
import { play } from "@/lib/client/audio";
import { api, newKey, useCountdown } from "@/lib/client/hooks";
import type { PlanId, PublicUser } from "@/lib/shared/domain";
import { Glass, Icon, MutexButton, SectionTitle, formatDate } from "./ui";

interface PlanView {
  id: PlanId;
  label: string;
  priceCents: number;
  days: number;
  tier: "basic" | "god";
  flash: boolean;
  features: string[];
  available: boolean;
}

interface CommerceState {
  serverNow: string;
  flashEnabled: boolean;
  flashActive: boolean;
  flashEndsAt: string | null;
  vipActive: boolean;
  vipTier: "none" | "basic" | "god";
  vipUntil: string | null;
  vipPermanent: boolean;
  plans: PlanView[];
}

interface CheckoutReceipt {
  purchase: { reference: string; planId: string; amountCents: number; status: string; paymentMethod: string };
  instructions: string;
}

function price(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

function clock(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export function PostWall({
  title,
  teaser,
  cta,
  onCta,
}: {
  title: string;
  teaser: string;
  cta: string;
  onCta: () => void;
}) {
  return (
    <div className="kalo-blur-wall kalo-glass relative min-h-[260px] p-6">
      <div className="absolute inset-0 select-none p-6" aria-hidden="true">
        <div className="grid grid-cols-3 gap-3">
          {["Grasa 12%", "Simetria 91", "Potencial 94", "Aura 88", "Metabolismo 62", "Inflamacion 18"].map((line) => (
            <div key={line} className="rounded-2xl border border-white/10 p-3 text-xs">
              {line}
            </div>
          ))}
        </div>
        <div className="mt-6 space-y-3">
          <div className="h-3 w-4/5 rounded-full bg-white/15" />
          <div className="h-3 w-3/5 rounded-full bg-white/10" />
          <div className="h-3 w-2/3 rounded-full bg-white/15" />
        </div>
      </div>
      <div className="kalo-blur-layer kalo-blur-soft" aria-hidden="true" />
      <div className="kalo-blur-layer kalo-blur-mid" aria-hidden="true" />
      <div className="kalo-blur-layer kalo-blur-deep" aria-hidden="true" />
      <div className="relative z-10 flex h-full min-h-[240px] flex-col justify-end gap-4">
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-[rgba(229,193,88,0.4)] px-3 py-1 text-[10px] uppercase tracking-[0.18em] text-[color:var(--kalo-gold)]">
          <Icon name="lock" size={12} />
          {title}
        </span>
        <p className="text-sm leading-relaxed text-[color:var(--kalo-titanium)]">{teaser}</p>
        <MutexButton className="w-full" onPress={onCta}>
          {cta}
        </MutexButton>
      </div>
    </div>
  );
}

function PlanCard({
  plan,
  remainingMs,
  busy,
  onBuy,
  decoy,
}: {
  plan: PlanView;
  remainingMs: number;
  busy: boolean;
  onBuy: () => void;
  decoy?: boolean;
}) {
  const god = plan.flash;
  return (
    <Glass className={`relative flex flex-col gap-4 p-5 ${god ? "border-[rgba(229,193,88,0.55)]" : ""} ${decoy ? "opacity-80" : ""}`}>
      {god ? (
        <span className="absolute right-4 top-4 rounded-full bg-[#E5C158] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#070709]">
          Oferta relampago
        </span>
      ) : null}
      <div>
        <p className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-muted)]">{plan.tier === "god" ? "Acceso total" : "Acceso estandar"}</p>
        <p className={`mt-1 text-lg font-semibold ${god ? "kalo-gold-text" : ""}`}>{plan.label}</p>
      </div>
      <div className="flex items-end gap-2">
        <span className="text-3xl font-semibold tracking-tight">{price(plan.priceCents)}</span>
        <span className="pb-1 text-xs text-[color:var(--kalo-muted)]">{plan.days === 30 ? "/ mes" : `/ ${plan.days} dias`}</span>
      </div>
      <ul className="space-y-2">
        {plan.features.map((feature) => (
          <li key={feature} className="flex items-start gap-2 text-xs leading-relaxed text-[color:var(--kalo-muted)]">
            <span className="mt-0.5 text-[color:var(--kalo-gold)]">
              <Icon name="check" size={13} />
            </span>
            {feature}
          </li>
        ))}
      </ul>
      {god ? (
        <p className="text-xs text-[color:var(--kalo-titanium)]" role="timer" aria-live="off">
          {plan.available ? `Tiempo restante: ${clock(remainingMs)}` : "La oferta relampago ya expiro para tu cuenta."}
        </p>
      ) : null}
      <MutexButton className="w-full" onPress={onBuy} ready={plan.available} disabled={busy} busyLabel="Procesando" variant={god ? "gold" : "ghost"}>
        {plan.available ? "Elegir plan" : "No disponible"}
      </MutexButton>
    </Glass>
  );
}

export function Paywall({ user, onChanged }: { user: PublicUser; onChanged: () => Promise<void> | void }) {
  const [state, setState] = useState<CommerceState | null>(null);
  const [method, setMethod] = useState<"card_usd" | "transfermovil_cup">("card_usd");
  const [receipt, setReceipt] = useState<CheckoutReceipt | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const remaining = useCountdown(state?.flashActive ? state.flashEndsAt : null);

  const load = async () => {
    const result = await api<CommerceState>("/api/commerce/state");
    if (result.ok) setState(result.data);
  };

  useEffect(() => {
    let alive = true;
    const view = async () => {
      const result = await api<CommerceState>("/api/commerce/view", { body: {} });
      if (alive && result.ok) setState(result.data);
    };
    void view();
    return () => {
      alive = false;
    };
  }, []);

  const buy = async (planId: PlanId) => {
    setError(null);
    const result = await api<CheckoutReceipt>("/api/commerce/checkout", {
      body: { planId, method },
      idempotencyKey: newKey(),
    });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    play("success");
    setReceipt(result.data);
    await load();
  };

  const copyReference = async () => {
    if (!receipt) return;
    try {
      await navigator.clipboard.writeText(receipt.purchase.reference);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const plans = state?.plans ?? [];
  const basic = plans.find((plan) => plan.id === "basic_monthly");
  const decoy = plans.find((plan) => plan.id === "decoy_quarterly");
  const god = plans.find((plan) => plan.id === "god_mode");
  const vipLabel = state?.vipActive
    ? state.vipPermanent
      ? "Acceso permanente activo"
      : `${state.vipTier === "god" ? "MODO DIOS" : "Basico"} activo hasta ${state.vipUntil ? formatDate(state.vipUntil) : "-"}`
    : "Sin suscripcion activa";

  return (
    <div className="kalo-fade-in space-y-8 pt-2">
      <SectionTitle eyebrow="Acceso" title="Planes KALO" />
      <Glass className="flex items-center justify-between gap-3 p-4">
        <div className="min-w-0">
          <p className="text-[10px] uppercase tracking-[0.18em] text-[color:var(--kalo-muted)]">Estado</p>
          <p className="kalo-ellipsis mt-1 text-sm font-semibold">{vipLabel}</p>
        </div>
        <span className="shrink-0 text-[11px] text-[color:var(--kalo-muted)]">{user.name}</span>
      </Glass>

      <div className="grid grid-cols-2 gap-1 rounded-2xl bg-white/[0.04] p-1" role="radiogroup" aria-label="Metodo de pago">
        {(
          [
            { id: "card_usd", label: "Tarjeta (USD)" },
            { id: "transfermovil_cup", label: "Transfermovil (CUP)" },
          ] as const
        ).map((option) => (
          <button
            key={option.id}
            type="button"
            role="radio"
            aria-checked={method === option.id}
            onClick={() => setMethod(option.id)}
            className={`min-h-[40px] rounded-xl text-xs font-medium ${method === option.id ? "bg-white/[0.08] text-[color:var(--kalo-gold)]" : "text-[color:var(--kalo-muted)]"}`}
          >
            {option.label}
          </button>
        ))}
      </div>

      {state === null ? (
        <p className="text-sm text-[color:var(--kalo-muted)]" role="status">
          Cargando planes...
        </p>
      ) : (
        <div className="space-y-4">
          {basic ? <PlanCard plan={basic} remainingMs={0} busy={false} onBuy={() => buy(basic.id)} /> : null}
          {decoy ? <PlanCard plan={decoy} remainingMs={0} busy={false} onBuy={() => buy(decoy.id)} decoy /> : null}
          {god ? (
            <PlanCard
              plan={{ ...god, available: god.available && remaining > 0 }}
              remainingMs={remaining}
              busy={false}
              onBuy={() => buy(god.id)}
            />
          ) : null}
        </div>
      )}

      {error ? (
        <p role="alert" className="text-sm text-[color:var(--kalo-danger)]">
          {error}
        </p>
      ) : null}

      {receipt ? (
        <Glass className="kalo-fade-in space-y-4 p-5">
          <p className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-gold)]">Orden creada</p>
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">Referencia</p>
              <p className="font-mono text-lg tracking-[0.12em]">{receipt.purchase.reference}</p>
            </div>
            <button type="button" onClick={copyReference} className="kalo-btn kalo-btn-ghost kalo-btn-sm shrink-0">
              <Icon name="copy" size={14} />
              {copied ? "Copiada" : "Copiar"}
            </button>
          </div>
          <p className="text-xs leading-relaxed text-[color:var(--kalo-muted)]">{receipt.instructions}</p>
          <p className="text-xs text-[color:var(--kalo-muted)]">
            Estado: <span className="text-[color:var(--kalo-titanium)]">Pendiente de confirmacion</span>
          </p>
        </Glass>
      ) : null}

      <p className="text-[11px] leading-relaxed text-[color:var(--kalo-muted)]">
        El precio se calcula en el servidor a partir del plan elegido. Las suscripciones se activan solo con la confirmacion firmada del proveedor o la validacion manual de la transferencia.
      </p>
    </div>
  );
}
