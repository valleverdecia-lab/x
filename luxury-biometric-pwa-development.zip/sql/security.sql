-- KALO // AURA AI: database security layer.
-- Idempotent. Applied automatically by src/lib/server/db.ts (ensureDbSecurity) before the first request.
-- Model:
--   * Application traffic runs inside transactions that execute SET LOCAL ROLE kalo_app and
--     set_config('app.user_id', <session user uuid>, true). RLS policies compare every row against app_uid().
--   * kalo_app cannot read sessions, rate limits, idempotency keys, affiliates or settings at all.
--   * Privileged server code (login, webhook, owner vault) uses the table owner connection and enforces
--     its own checks; it never trusts client-supplied role, is_vip, price or status fields.

BEGIN;
SELECT pg_advisory_xact_lock(727274);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'kalo_app') THEN
    CREATE ROLE kalo_app NOLOGIN NOINHERIT;
  END IF;
END
$$;

GRANT kalo_app TO CURRENT_USER;
GRANT USAGE ON SCHEMA public TO kalo_app;

CREATE OR REPLACE FUNCTION public.app_uid() RETURNS uuid
  LANGUAGE sql STABLE SET search_path = public
  AS $$ SELECT NULLIF(current_setting('app.user_id', true), '')::uuid $$;

CREATE OR REPLACE FUNCTION public.app_is_owner() RETURNS boolean
  LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
  AS $$
    SELECT EXISTS (
      SELECT 1 FROM public.users u
      WHERE u.id = public.app_uid()
        AND u.role = 'owner'
        AND u.email = 'valleverdecia@gmail.com'
    )
  $$;

CREATE OR REPLACE FUNCTION public.users_guard() RETURNS trigger
  LANGUAGE plpgsql SET search_path = public
  AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Every new account is born as a plain user without VIP. Only privileged code can promote later.
    NEW.role := 'user';
    NEW.is_vip := false;
    NEW.vip_tier := 'none';
    NEW.vip_until := NULL;
    NEW.vip_permanent := false;
    RETURN NEW;
  END IF;

  IF current_user = 'kalo_app' THEN
    IF NEW.role IS DISTINCT FROM OLD.role
       OR NEW.is_vip IS DISTINCT FROM OLD.is_vip
       OR NEW.vip_tier IS DISTINCT FROM OLD.vip_tier
       OR NEW.vip_until IS DISTINCT FROM OLD.vip_until
       OR NEW.vip_permanent IS DISTINCT FROM OLD.vip_permanent
       OR NEW.email IS DISTINCT FROM OLD.email
       OR NEW.password_hash IS DISTINCT FROM OLD.password_hash
       OR NEW.invite_code IS DISTINCT FROM OLD.invite_code
       OR NEW.affiliate_id IS DISTINCT FROM OLD.affiliate_id
       OR NEW.invited_by_user_id IS DISTINCT FROM OLD.invited_by_user_id THEN
      RAISE EXCEPTION 'privileged column update denied' USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS users_guard_trg ON public.users;
CREATE TRIGGER users_guard_trg
  BEFORE INSERT OR UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION public.users_guard();

CREATE OR REPLACE FUNCTION public.purchases_guard() RETURNS trigger
  LANGUAGE plpgsql SET search_path = public
  AS $$
BEGIN
  -- Clients can only create pending orders. Settlement happens through the signed webhook or owner confirmation.
  IF current_user = 'kalo_app' THEN
    NEW.status := 'pending';
    NEW.paid_at := NULL;
    NEW.provider_ref := NULL;
  END IF;
  RETURN NEW;
END
$$;

DROP TRIGGER IF EXISTS purchases_guard_trg ON public.purchases;
CREATE TRIGGER purchases_guard_trg
  BEFORE INSERT ON public.purchases
  FOR EACH ROW EXECUTE FUNCTION public.purchases_guard();

REVOKE ALL ON ALL TABLES IN SCHEMA public FROM kalo_app;

GRANT SELECT ON public.users TO kalo_app;
GRANT UPDATE (name, age, goal_kcal, goal_protein, diet_plan, theme, unlocked_themes, xp, streak_days,
              streak_last_day, last_activity_at, last_seen_at, promise_signed_at, promise_hash,
              flash_offer_until, updated_at)
  ON public.users TO kalo_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meals TO kalo_app;
GRANT SELECT, INSERT, DELETE ON public.body_scans TO kalo_app;
GRANT SELECT, INSERT, DELETE ON public.posts TO kalo_app;
GRANT SELECT ON public.reward_rolls TO kalo_app;
GRANT SELECT, INSERT, DELETE ON public.guild_members TO kalo_app;
GRANT SELECT, INSERT ON public.guilds TO kalo_app;
GRANT SELECT, INSERT ON public.purchases TO kalo_app;
GRANT SELECT, INSERT ON public.paywall_events TO kalo_app;

-- Users: a person can read and edit only their own row. Owner vault reads go through the privileged connection.
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS users_self_select ON public.users;
CREATE POLICY users_self_select ON public.users FOR SELECT TO kalo_app
  USING (id = public.app_uid());

DROP POLICY IF EXISTS users_self_update ON public.users;
CREATE POLICY users_self_update ON public.users FOR UPDATE TO kalo_app
  USING (id = public.app_uid())
  WITH CHECK (id = public.app_uid());

-- Owner-only visibility for the owner account inside the database as a second layer.
DROP POLICY IF EXISTS users_owner_select ON public.users;
CREATE POLICY users_owner_select ON public.users FOR SELECT TO kalo_app
  USING (public.app_is_owner());

ALTER TABLE public.meals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS meals_owner_all ON public.meals;
CREATE POLICY meals_owner_all ON public.meals FOR ALL TO kalo_app
  USING (user_id = public.app_uid())
  WITH CHECK (user_id = public.app_uid());

ALTER TABLE public.body_scans ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS body_scans_owner_all ON public.body_scans;
CREATE POLICY body_scans_owner_all ON public.body_scans FOR ALL TO kalo_app
  USING (user_id = public.app_uid())
  WITH CHECK (user_id = public.app_uid());

ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS posts_owner_all ON public.posts;
CREATE POLICY posts_owner_all ON public.posts FOR ALL TO kalo_app
  USING (user_id = public.app_uid())
  WITH CHECK (user_id = public.app_uid());

ALTER TABLE public.reward_rolls ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS reward_rolls_owner_select ON public.reward_rolls;
CREATE POLICY reward_rolls_owner_select ON public.reward_rolls FOR SELECT TO kalo_app
  USING (user_id = public.app_uid());

ALTER TABLE public.guild_members ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS guild_members_owner_all ON public.guild_members;
CREATE POLICY guild_members_owner_all ON public.guild_members FOR ALL TO kalo_app
  USING (user_id = public.app_uid())
  WITH CHECK (user_id = public.app_uid());

ALTER TABLE public.guilds ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS guilds_read ON public.guilds;
CREATE POLICY guilds_read ON public.guilds FOR SELECT TO kalo_app
  USING (true);
DROP POLICY IF EXISTS guilds_create ON public.guilds;
CREATE POLICY guilds_create ON public.guilds FOR INSERT TO kalo_app
  WITH CHECK (created_by_user_id = public.app_uid());

ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS purchases_owner_all ON public.purchases;
CREATE POLICY purchases_owner_all ON public.purchases FOR ALL TO kalo_app
  USING (user_id = public.app_uid())
  WITH CHECK (user_id = public.app_uid());

ALTER TABLE public.paywall_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS paywall_events_owner_all ON public.paywall_events;
CREATE POLICY paywall_events_owner_all ON public.paywall_events FOR ALL TO kalo_app
  USING (user_id = public.app_uid())
  WITH CHECK (user_id = public.app_uid());

-- Privileged-only tables: RLS enabled with no policy for kalo_app means deny by default.
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.idempotency_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliate_clicks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.global_settings ENABLE ROW LEVEL SECURITY;

COMMIT;
