"use client";

import { type FormEvent, useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client/hooks";
import { Glass, MutexButton, ProgressBar, SectionTitle, Skeleton, formatDate, formatUsd } from "@/components/kalo/ui";

type Tab = "resumen" | "usuarios" | "afiliados" | "pagos";

interface Overview {
  totalUsers: number;
  activeToday: number;
  revenueMonthCents: number;
  paywallViewers: number;
  paywallBuyers: number;
  conversionPct: number;
  flashEnabled: boolean;
}

interface UserRow {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  role: string;
  vipTier: string;
  vipActive: boolean;
  vipUntil: string | null;
  vipPermanent: boolean;
  streakDays: number;
  xp: number;
  inviterEmail: string | null;
  affiliateCode: string | null;
  lastPaymentStatus: string | null;
}

interface AffiliateRow {
  id: string;
  code: string;
  label: string;
  commissionPct: number;
  active: boolean;
  createdAt: string;
  uniqueClicks: number;
  registrations: number;
  vipPurchases: number;
  revenueCents: number;
  commissionCents: number;
}

interface PendingPurchase {
  reference: string;
  planId: string;
  amountCents: number;
  paymentMethod: string;
  createdAt: string;
  userEmail: string;
}

const TABS: Array<{ id: Tab; label: string }> = [
  { id: "resumen", label: "Resumen" },
  { id: "usuarios", label: "Usuarios" },
  { id: "afiliados", label: "Afiliados" },
  { id: "pagos", label: "Pagos" },
];

function Metric({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <Glass className="p-5">
      <p className="text-[10px] uppercase tracking-[0.18em] text-[color:var(--kalo-muted)]">{label}</p>
      <p className="mt-2 text-2xl font-semibold tracking-tight">{value}</p>
      {hint ? <p className="mt-1 text-[11px] text-[color:var(--kalo-muted)]">{hint}</p> : null}
    </Glass>
  );
}

function OverviewPanel() {
  const [data, setData] = useState<Overview | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const load = useCallback(async () => {
    const result = await api<Overview>("/api/owner/overview");
    if (result.ok) setData(result.data);
    else setMessage(result.error);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const toggleFlash = async () => {
    if (!data) return;
    setMessage(null);
    const result = await api<{ flashEnabled: boolean }>("/api/owner/flash", { body: { enabled: !data.flashEnabled } });
    if (!result.ok) {
      setMessage(result.error);
      return;
    }
    setMessage(result.data.flashEnabled ? "Ofertas relampago activadas para toda la app." : "Ofertas relampago desactivadas.");
    await load();
  };

  if (!data) return <Skeleton className="h-60 w-full" />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Metric label="Usuarios" value={String(data.totalUsers)} />
        <Metric label="Activos 24h" value={String(data.activeToday)} />
        <Metric label="Ingresos del mes" value={formatUsd(data.revenueMonthCents)} />
        <Metric label="Conversion paywall" value={`${data.conversionPct}%`} hint={`${data.paywallBuyers} de ${data.paywallViewers} vieron el paywall`} />
      </div>
      <Glass className="flex flex-col gap-4 p-5 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-sm font-semibold">Ofertas relampago</p>
          <p className="mt-1 text-xs text-[color:var(--kalo-muted)]">
            Estado: {data.flashEnabled ? "activo para todos los usuarios" : "desactivado"}. Cada usuario ve un contador de 14 minutos desde su primera visita al paywall.
          </p>
        </div>
        <MutexButton variant={data.flashEnabled ? "danger" : "gold"} onPress={toggleFlash} className="shrink-0">
          {data.flashEnabled ? "Desactivar ofertas" : "Activar ofertas"}
        </MutexButton>
      </Glass>
      <ProgressBar value={data.conversionPct * 4} tone="neon" />
      {message ? <p role="status" className="text-xs text-[color:var(--kalo-gold)]">{message}</p> : null}
    </div>
  );
}

function UserRowItem({ row, onGranted }: { row: UserRow; onGranted: () => Promise<void> | void }) {
  const [duration, setDuration] = useState<"7d" | "30d" | "1y" | "permanent">("30d");
  const [note, setNote] = useState<string | null>(null);

  const grant = async () => {
    setNote(null);
    const result = await api<{ ok: boolean }>("/api/owner/vip", { body: { userId: row.id, duration } });
    if (!result.ok) {
      setNote(result.error);
      return;
    }
    setNote("VIP activado.");
    await onGranted();
  };

  return (
    <li className="kalo-glass space-y-3 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="kalo-ellipsis text-sm font-semibold">{row.email}</p>
          <p className="kalo-ellipsis text-xs text-[color:var(--kalo-muted)]">
            {row.name} · alta {formatDate(row.createdAt)} · racha {row.streakDays} · XP {row.xp}
          </p>
        </div>
        <span
          className={`shrink-0 rounded-full border px-2.5 py-1 text-[10px] uppercase tracking-[0.12em] ${row.vipActive ? "border-[rgba(229,193,88,0.5)] text-[color:var(--kalo-gold)]" : "border-white/10 text-[color:var(--kalo-muted)]"}`}
        >
          {row.vipActive ? (row.vipPermanent ? "VIP permanente" : `VIP ${row.vipTier}`) : "Sin VIP"}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs text-[color:var(--kalo-muted)]">
        <span className="kalo-ellipsis">Invitado por: {row.inviterEmail ?? "-"}</span>
        <span className="kalo-ellipsis">Afiliado: {row.affiliateCode ?? "-"}</span>
        <span className="kalo-ellipsis">Ultimo pago: {row.lastPaymentStatus ?? "sin pagos"}</span>
        <span className="kalo-ellipsis">Rol: {row.role}</span>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <label className="sr-only" htmlFor={`duration-${row.id}`}>
          Duracion del VIP
        </label>
        <select
          id={`duration-${row.id}`}
          value={duration}
          onChange={(event) => setDuration(event.target.value as typeof duration)}
          className="kalo-input h-10 w-auto min-h-[40px] py-0"
        >
          <option value="7d">7 dias</option>
          <option value="30d">30 dias</option>
          <option value="1y">1 ano</option>
          <option value="permanent">Permanente</option>
        </select>
        <MutexButton className="kalo-btn-sm" onPress={grant} busyLabel="Activando">
          Activar VIP manual
        </MutexButton>
        {note ? <span className="text-xs text-[color:var(--kalo-gold)]">{note}</span> : null}
      </div>
    </li>
  );
}

function UsersPanel() {
  const [query, setQuery] = useState("");
  const [rows, setRows] = useState<UserRow[] | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const search = useCallback(async (term: string) => {
    setMessage(null);
    const result = await api<{ users: UserRow[] }>(`/api/owner/users?q=${encodeURIComponent(term)}`);
    if (result.ok) setRows(result.data.users);
    else setMessage(result.error);
  }, []);

  useEffect(() => {
    void search("");
  }, [search]);

  return (
    <div className="space-y-5">
      <form
        className="flex gap-2"
        onSubmit={(event: FormEvent) => {
          event.preventDefault();
          void search(query.trim());
        }}
      >
        <input
          className="kalo-input"
          placeholder="Buscar por correo o nombre"
          value={query}
          maxLength={80}
          onChange={(event) => setQuery(event.target.value)}
          aria-label="Buscar usuarios"
        />
        <button type="submit" className="kalo-btn kalo-btn-gold shrink-0">
          Buscar
        </button>
      </form>
      {message ? <p role="alert" className="text-xs text-[color:var(--kalo-danger)]">{message}</p> : null}
      {rows === null ? (
        <Skeleton className="h-40 w-full" />
      ) : (
        <ul className="space-y-3">
          {rows.map((row) => (
            <UserRowItem key={row.id} row={row} onGranted={() => search(query.trim())} />
          ))}
          {rows.length === 0 ? <li className="text-sm text-[color:var(--kalo-muted)]">Sin resultados.</li> : null}
        </ul>
      )}
    </div>
  );
}

function AffiliatesPanel() {
  const [rows, setRows] = useState<AffiliateRow[] | null>(null);
  const [code, setCode] = useState("");
  const [label, setLabel] = useState("");
  const [commission, setCommission] = useState("20");
  const [message, setMessage] = useState<string | null>(null);

  const load = useCallback(async () => {
    const result = await api<{ affiliates: AffiliateRow[] }>("/api/owner/affiliates");
    if (result.ok) setRows(result.data.affiliates);
    else setMessage(result.error);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const create = async () => {
    setMessage(null);
    const result = await api<{ affiliate: { code: string } }>("/api/owner/affiliate", {
      body: { code: code.trim().toLowerCase(), label: label.trim(), commissionPct: Number(commission) },
    });
    if (!result.ok) {
      setMessage(result.error);
      return;
    }
    setMessage(`Enlace creado: ${window.location.origin}/?ref=${result.data.affiliate.code}`);
    setCode("");
    setLabel("");
    await load();
  };

  const toggle = async (row: AffiliateRow) => {
    const result = await api("/api/owner/affiliate-toggle", { body: { id: row.id, active: !row.active } });
    if (!result.ok) setMessage(result.error);
    await load();
  };

  return (
    <div className="space-y-6">
      <Glass className="grid gap-3 p-5 md:grid-cols-[1fr_1fr_120px_auto] md:items-end">
        <label className="block">
          <span className="mb-1.5 block text-[11px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">Codigo</span>
          <input className="kalo-input" value={code} maxLength={32} onChange={(event) => setCode(event.target.value)} placeholder="influencer1" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[11px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">Nombre</span>
          <input className="kalo-input" value={label} maxLength={80} onChange={(event) => setLabel(event.target.value)} placeholder="Creador de contenido" />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[11px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">Comision %</span>
          <input className="kalo-input" inputMode="numeric" value={commission} maxLength={3} onChange={(event) => setCommission(event.target.value.replace(/[^0-9]/g, ""))} />
        </label>
        <MutexButton onPress={create} busyLabel="Creando">
          Crear enlace
        </MutexButton>
      </Glass>
      {message ? <p role="status" className="break-all text-xs text-[color:var(--kalo-gold)]">{message}</p> : null}

      {rows === null ? (
        <Skeleton className="h-40 w-full" />
      ) : rows.length === 0 ? (
        <p className="text-sm text-[color:var(--kalo-muted)]">Todavia no hay afiliados.</p>
      ) : (
        <div className="kalo-glass overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-xs">
            <thead className="text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">
              <tr>
                <th className="p-3">Codigo</th>
                <th className="p-3">Clics unicos</th>
                <th className="p-3">Registrados</th>
                <th className="p-3">Compras VIP</th>
                <th className="p-3">Ingresos</th>
                <th className="p-3">Comision</th>
                <th className="p-3">Estado</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id} className="border-t border-white/[0.06]">
                  <td className="p-3">
                    <p className="font-semibold">{row.code}</p>
                    <p className="kalo-ellipsis max-w-[160px] text-[10px] text-[color:var(--kalo-muted)]">{row.label}</p>
                  </td>
                  <td className="p-3">{row.uniqueClicks}</td>
                  <td className="p-3">{row.registrations}</td>
                  <td className="p-3">{row.vipPurchases}</td>
                  <td className="p-3">{formatUsd(row.revenueCents)}</td>
                  <td className="p-3">
                    {row.commissionPct}% · {formatUsd(row.commissionCents)}
                  </td>
                  <td className="p-3">
                    <button type="button" onClick={() => toggle(row)} className="kalo-btn kalo-btn-ghost kalo-btn-sm">
                      {row.active ? "Desactivar" : "Activar"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function PurchasesPanel() {
  const [rows, setRows] = useState<PendingPurchase[] | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const load = useCallback(async () => {
    const result = await api<{ purchases: PendingPurchase[] }>("/api/owner/purchases");
    if (result.ok) setRows(result.data.purchases);
    else setMessage(result.error);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const confirm = async (reference: string) => {
    setMessage(null);
    const result = await api<{ ok: boolean; planId: string }>("/api/owner/confirm", { body: { reference } });
    if (!result.ok) {
      setMessage(result.error);
      return;
    }
    setMessage(`Pago ${reference} confirmado. VIP activado.`);
    await load();
  };

  return (
    <div className="space-y-4">
      <p className="text-xs leading-relaxed text-[color:var(--kalo-muted)]">
        Confirma las transferencias de Transfermovil (CUP) cuando recibas el pago. Cada confirmacion es idempotente y solo procesa referencias pendientes.
      </p>
      {message ? <p role="status" className="text-xs text-[color:var(--kalo-gold)]">{message}</p> : null}
      {rows === null ? (
        <Skeleton className="h-32 w-full" />
      ) : rows.length === 0 ? (
        <p className="text-sm text-[color:var(--kalo-muted)]">No hay pagos pendientes.</p>
      ) : (
        <ul className="space-y-3">
          {rows.map((row) => (
            <li key={row.reference} className="kalo-glass flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0">
                <p className="font-mono text-sm tracking-[0.1em]">{row.reference}</p>
                <p className="kalo-ellipsis text-xs text-[color:var(--kalo-muted)]">
                  {row.userEmail} · {row.planId} · {formatUsd(row.amountCents)} · {row.paymentMethod}
                </p>
              </div>
              <MutexButton className="kalo-btn-sm" onPress={() => confirm(row.reference)} busyLabel="Confirmando">
                Confirmar pago
              </MutexButton>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default function OwnerVault() {
  const [tab, setTab] = useState<Tab>("resumen");
  return (
    <div className="mx-auto min-h-[100dvh] w-full max-w-5xl px-5 py-8">
      <header className="mb-6 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="kalo-gold-text text-xs font-semibold uppercase tracking-[0.3em]">Owner Vault</p>
          <h1 className="kalo-ellipsis mt-1 text-xl font-semibold">Panel de control</h1>
        </div>
        <a href="/" className="kalo-btn kalo-btn-ghost kalo-btn-sm shrink-0">
          Volver a la app
        </a>
      </header>
      <nav className="mb-6 grid grid-cols-4 gap-1 rounded-2xl bg-white/[0.04] p-1" role="tablist" aria-label="Secciones">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={tab === item.id}
            onClick={() => setTab(item.id)}
            className={`min-h-[40px] rounded-xl text-xs font-medium ${tab === item.id ? "bg-white/[0.08] text-[color:var(--kalo-gold)]" : "text-[color:var(--kalo-muted)]"}`}
          >
            {item.label}
          </button>
        ))}
      </nav>
      <SectionTitle eyebrow="God Mode" title={TABS.find((item) => item.id === tab)?.label ?? "Resumen"} />
      {tab === "resumen" ? <OverviewPanel /> : null}
      {tab === "usuarios" ? <UsersPanel /> : null}
      {tab === "afiliados" ? <AffiliatesPanel /> : null}
      {tab === "pagos" ? <PurchasesPanel /> : null}
    </div>
  );
}
