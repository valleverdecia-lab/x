"use client";

import { type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, useEffect, useId } from "react";
import { play } from "@/lib/client/audio";
import { useMutexAction } from "@/lib/client/hooks";

export type IconName =
  | "home"
  | "scan"
  | "users"
  | "crown"
  | "flame"
  | "bolt"
  | "lock"
  | "bell"
  | "volume"
  | "volumeOff"
  | "logout"
  | "shield"
  | "fingerprint"
  | "camera"
  | "upload"
  | "leaf"
  | "gift"
  | "copy"
  | "share"
  | "close"
  | "check"
  | "alert"
  | "sparkle"
  | "layers"
  | "trophy"
  | "ticket"
  | "refresh"
  | "swords"
  | "phone"
  | "plus"
  | "minus"
  | "chevron"
  | "search"
  | "wallet"
  | "gauge";

const PATHS: Record<IconName, ReactNode> = {
  home: <path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z" />,
  scan: (
    <path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2M4 12h16" />
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3.2" />
      <path d="M3 20c.6-3.4 3-5.2 6-5.2s5.4 1.8 6 5.2M16 11.2a3 3 0 1 0-1.5-5.6M18 15.2c1.7.8 2.7 2.4 3 4.8" />
    </>
  ),
  crown: <path d="M3 8l4.5 4L12 6l4.5 6L21 8l-2 11H5z" />,
  flame: <path d="M12 3c1 3.2 4.5 4.8 4.5 9a4.5 4.5 0 0 1-9 0c0-2 .8-3.4 2-4.5.3 1.5 1 2.4 2 2.8C11.4 7.4 11.2 5.2 12 3z" />,
  bolt: <path d="M13 2 4 14h7l-1 8 9-12h-7z" />,
  lock: (
    <>
      <rect x="4.5" y="10.5" width="15" height="10" rx="2" />
      <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" />
    </>
  ),
  bell: <path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15zM10 20.5a2 2 0 0 0 4 0" />,
  volume: <path d="M4 9v6h4l5 4V5L8 9zM16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12" />,
  volumeOff: <path d="M4 9v6h4l5 4V5L8 9zM16 9l5 6M21 9l-5 6" />,
  logout: <path d="M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4M15 16l4-4-4-4M19 12H9" />,
  shield: <path d="M12 3l7 3v5c0 4.5-3 8.2-7 10-4-1.8-7-5.5-7-10V6z" />,
  fingerprint: (
    <>
      <path d="M12 11a2 2 0 0 0-2 2c0 3.5.5 5.5 1.5 7M8 14.5c-.4-1.2-.5-2-.5-3a4.5 4.5 0 0 1 9 0c0 .4 0 1-.1 1.6" />
      <path d="M5 10.5A7 7 0 0 1 19 10.5M6.5 18c.8-1.2 1-2.5 1-4.5M16.5 18.5c.5-1.6.5-3.2.5-4.5M12 7a4.5 4.5 0 0 0-4.5 4.5" />
    </>
  ),
  camera: (
    <>
      <path d="M4 8h3l2-2.5h6L17 8h3v11H4z" />
      <circle cx="12" cy="13" r="3.5" />
    </>
  ),
  upload: <path d="M12 16V4M7 9l5-5 5 5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3" />,
  leaf: <path d="M5 19c0-8 5-13 14-14 0 9-5 14-13 14M5 19l7-7" />,
  gift: (
    <>
      <rect x="3.5" y="8" width="17" height="4" rx="1" />
      <path d="M5 12v8h14v-8M12 8v12M12 8c-1.5-3-5.5-3.5-5.5-1s4 1 5.5 1zM12 8c1.5-3 5.5-3.5 5.5-1s-4 1-5.5 1z" />
    </>
  ),
  copy: (
    <>
      <rect x="8.5" y="8.5" width="11" height="11" rx="2" />
      <path d="M5.5 15.5h-1a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v1" />
    </>
  ),
  share: (
    <>
      <circle cx="18" cy="5.5" r="2.5" />
      <circle cx="6" cy="12" r="2.5" />
      <circle cx="18" cy="18.5" r="2.5" />
      <path d="M8.2 10.8l7.6-4M8.2 13.2l7.6 4" />
    </>
  ),
  close: <path d="M6 6l12 12M18 6L6 18" />,
  check: <path d="M5 12.5l4.5 4.5L19 7.5" />,
  alert: <path d="M12 4 2.8 19.5h18.4zM12 10v4.5M12 17.2v.3" />,
  sparkle: <path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18" />,
  layers: <path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5M3 17.5l9 5 9-5" />,
  trophy: <path d="M8 4h8v5a4 4 0 0 1-8 0zM8 6H5a3 3 0 0 0 3 3M16 6h3a3 3 0 0 1-3 3M12 13v4M8.5 20h7M9 17h6" />,
  ticket: (
    <>
      <path d="M3 8V6.5A1.5 1.5 0 0 1 4.5 5h15A1.5 1.5 0 0 1 21 6.5V8a2 2 0 0 0 0 4v1.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 13.5V12a2 2 0 0 0 0-4z" />
      <path d="M14.5 5v14" strokeDasharray="2 2" />
    </>
  ),
  refresh: <path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7" />,
  swords: <path d="M5 19l5-5M4 4l6.5 6.5M20 4l-6.5 6.5M19 19l-5-5" />,
  phone: (
    <>
      <rect x="7" y="2.5" width="10" height="19" rx="2.5" />
      <path d="M11 18.5h2" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  chevron: <path d="M9 6l6 6-6 6" />,
  search: (
    <>
      <circle cx="11" cy="11" r="6.5" />
      <path d="M16 16l4.5 4.5" />
    </>
  ),
  wallet: (
    <>
      <rect x="3" y="6" width="18" height="13" rx="2.5" />
      <path d="M16 12.5h2.5M3 10h18" />
    </>
  ),
  gauge: <path d="M4.5 16a8 8 0 1 1 15 0M12 13l4-4" />,
};

export function Icon({ name, size = 20, className = "" }: { name: IconName; size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.25}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {PATHS[name]}
    </svg>
  );
}

export function Glass({ className = "", children }: { className?: string; children: ReactNode }) {
  return <div className={`kalo-glass ${className}`}>{children}</div>;
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`kalo-skeleton ${className}`} aria-hidden="true" />;
}

interface MutexButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "onClick"> {
  onPress: () => unknown;
  variant?: "gold" | "ghost" | "danger";
  ready?: boolean;
  busyLabel?: string;
}

export function MutexButton({
  onPress,
  variant = "gold",
  ready = true,
  busyLabel,
  className = "",
  children,
  disabled,
  style,
  ...rest
}: MutexButtonProps) {
  const { run, pending } = useMutexAction(async () => {
    play("click");
    await onPress();
  });
  const blocked = !ready || pending || Boolean(disabled);
  return (
    <button
      type="button"
      {...rest}
      disabled={blocked}
      aria-busy={pending}
      onClick={() => {
        void run();
      }}
      className={`kalo-btn kalo-btn-${variant} ${className}`}
      style={{ pointerEvents: pending ? "none" : undefined, ...style }}
    >
      {pending && busyLabel ? busyLabel : children}
    </button>
  );
}

export function Field({
  label,
  error,
  hint,
  ...input
}: InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string | null; hint?: string }) {
  const id = useId();
  return (
    <div className="block">
      <label htmlFor={id} className="mb-1.5 block text-[11px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">
        {label}
      </label>
      <input id={id} {...input} className={`kalo-input ${input.className ?? ""}`} />
      {error ? (
        <span className="mt-1 block text-xs text-[color:var(--kalo-danger)]">{error}</span>
      ) : hint ? (
        <span className="mt-1 block text-xs text-[color:var(--kalo-muted)]">{hint}</span>
      ) : null}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[9000] flex items-end justify-center bg-black/70 p-3 backdrop-blur-sm sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={onClose}
    >
      <div
        className="kalo-glass kalo-fade-in kalo-scroll max-h-[88dvh] w-full max-w-md overflow-y-auto p-5"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="kalo-ellipsis text-base font-semibold tracking-wide">{title}</h2>
          <button type="button" onClick={onClose} className="kalo-btn kalo-btn-ghost kalo-btn-sm" aria-label="Cerrar">
            <Icon name="close" size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function SectionTitle({ eyebrow, title, right }: { eyebrow: string; title: string; right?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-[0.22em] text-[color:var(--kalo-muted)]">{eyebrow}</p>
        <h2 className="kalo-ellipsis text-xl font-semibold tracking-tight">{title}</h2>
      </div>
      {right ? <div className="shrink-0">{right}</div> : null}
    </div>
  );
}

export function ProgressBar({ value, tone = "gold" }: { value: number; tone?: "gold" | "neon" | "danger" }) {
  const color = tone === "neon" ? "var(--kalo-neon)" : tone === "danger" ? "var(--kalo-danger)" : "var(--kalo-gold)";
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]" role="progressbar" aria-valuenow={Math.round(clamped)} aria-valuemin={0} aria-valuemax={100}>
      <div
        className="h-full rounded-full transition-[width] duration-700 ease-out"
        style={{ width: `${clamped}%`, background: color, boxShadow: `0 0 12px ${color}` }}
      />
    </div>
  );
}

export function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("es", { hour: "2-digit", minute: "2-digit" });
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("es", { day: "2-digit", month: "short", year: "numeric" });
}

export function formatUsd(cents: number): string {
  return `$${(cents / 100).toFixed(2)} USD`;
}
