"use client";

const SIDE = 800;
const TARGET_BYTES = 35_000;
const QUALITY_STEPS = [0.7, 0.6, 0.5, 0.42, 0.35];

export interface CompressedImage {
  blob: Blob;
  mime: string;
  width: number;
  height: number;
  bytes: number;
}

function toBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob(resolve, type, quality));
}

export async function compressImage(source: Blob): Promise<CompressedImage> {
  const bitmap = await createImageBitmap(source);
  const canvas = document.createElement("canvas");
  canvas.width = SIDE;
  canvas.height = SIDE;
  const context = canvas.getContext("2d");
  if (!context) {
    bitmap.close();
    throw new Error("El navegador no permite procesar la imagen.");
  }

  const scale = Math.max(SIDE / bitmap.width, SIDE / bitmap.height);
  const cropWidth = SIDE / scale;
  const cropHeight = SIDE / scale;
  const sx = (bitmap.width - cropWidth) / 2;
  const sy = (bitmap.height - cropHeight) / 2;
  context.imageSmoothingQuality = "high";
  context.drawImage(bitmap, sx, sy, cropWidth, cropHeight, 0, 0, SIDE, SIDE);
  bitmap.close();

  let chosen: Blob | null = null;
  for (const quality of QUALITY_STEPS) {
    const candidate = await toBlob(canvas, "image/webp", quality);
    if (!candidate) break;
    if (candidate.type !== "image/webp") {
      chosen = await toBlob(canvas, "image/jpeg", 0.7);
      break;
    }
    chosen = candidate;
    if (candidate.size <= TARGET_BYTES) break;
  }
  if (!chosen) throw new Error("No se pudo preparar la imagen.");

  return { blob: chosen, mime: chosen.type, width: SIDE, height: SIDE, bytes: chosen.size };
}

export async function captureFrame(video: HTMLVideoElement): Promise<Blob> {
  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("El navegador no permite capturar el video.");
  context.drawImage(video, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
  if (!blob) throw new Error("No se pudo capturar la imagen.");
  return blob;
}

export function fireImpact(): void {
  const overlay = document.getElementById("kalo-impact");
  const root = document.getElementById("kalo-root");
  if (overlay) {
    overlay.classList.remove("is-firing");
    void overlay.offsetWidth;
    overlay.classList.add("is-firing");
  }
  if (root) {
    root.classList.remove("is-shaking");
    void root.offsetWidth;
    root.classList.add("is-shaking");
    window.setTimeout(() => root.classList.remove("is-shaking"), 340);
  }
}
