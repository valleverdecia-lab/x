import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db } from "@/db";
import { affiliates, globalSettings, paywallEvents, purchases, users } from "@/db/schema";
import { ensureDbSecurity } from "@/lib/server/db";
import { assertSameOrigin, getSessionUser, isOwner, readJson } from "@/lib/server/security";
import { fulfillPurchase, getFlashEnabled, grantVip } from "@/lib/server/services";
import {
  ownerAffiliateSchema,
  ownerAffiliateToggleSchema,
  ownerConfirmSchema,
  ownerFlashSchema,
  ownerSearchSchema,
  ownerVipSchema,
} from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ action: string }> };

function json(body: unknown, status = 200) {
  return Response.json(body, { status });
}

export async function GET(req: Request, ctx: Ctx) {
  await ensureDbSecurity();
  const viewer = await getSessionUser();
  if (!isOwner(viewer)) return new Response(null, { status: 404 });
  const { action } = await ctx.params;

  if (action === "overview") {
    const [totals] = await db
      .select({
        total: sql<number>`count(*)::int`,
        dau: sql<number>`(count(*) filter (where ${users.lastSeenAt} > now() - interval '24 hours'))::int`,
      })
      .from(users);
    const [revenue] = await db
      .select({ cents: sql<number>`coalesce(sum(${purchases.amountCents}), 0)::int` })
      .from(purchases)
      .where(and(eq(purchases.status, "paid"), sql`${purchases.paidAt} >= date_trunc('month', now())`));
    const [viewers] = await db
      .select({ count: sql<number>`count(distinct ${paywallEvents.userId})::int` })
      .from(paywallEvents)
      .where(eq(paywallEvents.event, "view"));
    const [buyers] = await db
      .select({ count: sql<number>`count(distinct ${purchases.userId})::int` })
      .from(purchases)
      .where(eq(purchases.status, "paid"));
    const viewerCount = viewers.count;
    const buyerCount = buyers.count;
    return json({
      totalUsers: totals.total,
      activeToday: totals.dau,
      revenueMonthCents: revenue.cents,
      paywallViewers: viewerCount,
      paywallBuyers: buyerCount,
      conversionPct: viewerCount > 0 ? Math.round((buyerCount / viewerCount) * 1000) / 10 : 0,
      flashEnabled: await getFlashEnabled(),
    });
  }

  if (action === "users") {
    const parsedQ = ownerSearchSchema.safeParse(new URL(req.url).searchParams.get("q") ?? "");
    if (!parsedQ.success) return json({ error: "Busqueda no valida" }, 400);
    const inviter = alias(users, "inviter");
    const term = parsedQ.data;
    const pattern = `%${term}%`;
    const rows = await db
      .select({
        id: users.id,
        email: users.email,
        name: users.name,
        createdAt: users.createdAt,
        role: users.role,
        vipTier: users.vipTier,
        vipActive: sql<boolean>`(${users.vipPermanent} or ${users.vipUntil} > now())`,
        vipUntil: users.vipUntil,
        vipPermanent: users.vipPermanent,
        streakDays: users.streakDays,
        xp: users.xp,
        inviterEmail: inviter.email,
        affiliateCode: affiliates.code,
        lastPaymentStatus: sql<string | null>`(select p.status from purchases p where p.user_id = users.id order by p.created_at desc limit 1)`,
      })
      .from(users)
      .leftJoin(inviter, eq(inviter.id, users.invitedByUserId))
      .leftJoin(affiliates, eq(affiliates.id, users.affiliateId))
      .where(term ? or(ilike(users.email, pattern), ilike(users.name, pattern)) : undefined)
      .orderBy(desc(users.createdAt))
      .limit(60);
    return json({
      users: rows.map((row) => ({
        ...row,
        createdAt: row.createdAt.toISOString(),
        vipUntil: row.vipUntil ? row.vipUntil.toISOString() : null,
        vipActive: Boolean(row.vipActive),
      })),
    });
  }

  if (action === "affiliates") {
    const rows = await db
      .select({
        id: affiliates.id,
        code: affiliates.code,
        label: affiliates.label,
        commissionPct: affiliates.commissionPct,
        active: affiliates.active,
        createdAt: affiliates.createdAt,
        uniqueClicks: sql<number>`(select count(*)::int from affiliate_clicks c where c.affiliate_id = affiliates.id)`,
        registrations: sql<number>`(select count(*)::int from users u where u.affiliate_id = affiliates.id)`,
        vipPurchases: sql<number>`(select count(*)::int from purchases p where p.affiliate_id = affiliates.id and p.status = 'paid')`,
        revenueCents: sql<number>`(select coalesce(sum(p.amount_cents), 0)::int from purchases p where p.affiliate_id = affiliates.id and p.status = 'paid')`,
      })
      .from(affiliates)
      .orderBy(desc(affiliates.createdAt))
      .limit(200);
    return json({
      affiliates: rows.map((row) => ({
        ...row,
        createdAt: row.createdAt.toISOString(),
        commissionCents: Math.round((row.revenueCents * row.commissionPct) / 100),
      })),
    });
  }

  if (action === "purchases") {
    const rows = await db
      .select({
        reference: purchases.reference,
        planId: purchases.planId,
        amountCents: purchases.amountCents,
        paymentMethod: purchases.paymentMethod,
        createdAt: purchases.createdAt,
        userEmail: users.email,
      })
      .from(purchases)
      .innerJoin(users, eq(users.id, purchases.userId))
      .where(eq(purchases.status, "pending"))
      .orderBy(desc(purchases.createdAt))
      .limit(100);
    return json({
      purchases: rows.map((row) => ({ ...row, createdAt: row.createdAt.toISOString() })),
    });
  }

  return json({ error: "No encontrado" }, 404);
}

export async function POST(req: Request, ctx: Ctx) {
  await ensureDbSecurity();
  if (!assertSameOrigin(req)) return new Response(null, { status: 404 });
  const viewer = await getSessionUser();
  if (!isOwner(viewer)) return new Response(null, { status: 404 });
  const { action } = await ctx.params;

  if (action === "vip") {
    const parsed = await readJson(req, ownerVipSchema);
    if (!parsed.ok) return parsed.response;
    const [target] = await db.select({ id: users.id }).from(users).where(eq(users.id, parsed.data.userId)).limit(1);
    if (!target) return json({ error: "Usuario no encontrado" }, 404);
    await grantVip(target.id, parsed.data.duration);
    return json({ ok: true });
  }

  if (action === "affiliate") {
    const parsed = await readJson(req, ownerAffiliateSchema);
    if (!parsed.ok) return parsed.response;
    try {
      const [row] = await db
        .insert(affiliates)
        .values({
          code: parsed.data.code,
          label: parsed.data.label,
          commissionPct: parsed.data.commissionPct,
        })
        .returning({ id: affiliates.id, code: affiliates.code });
      return json({ affiliate: row }, 201);
    } catch (error) {
      if ((error as { code?: string }).code === "23505") return json({ error: "Ese codigo ya existe" }, 409);
      throw error;
    }
  }

  if (action === "affiliate-toggle") {
    const parsed = await readJson(req, ownerAffiliateToggleSchema);
    if (!parsed.ok) return parsed.response;
    await db.update(affiliates).set({ active: parsed.data.active }).where(eq(affiliates.id, parsed.data.id));
    return json({ ok: true });
  }

  if (action === "flash") {
    const parsed = await readJson(req, ownerFlashSchema);
    if (!parsed.ok) return parsed.response;
    await db
      .insert(globalSettings)
      .values({ key: "flash_sale", value: { enabled: parsed.data.enabled } })
      .onConflictDoUpdate({
        target: globalSettings.key,
        set: { value: { enabled: parsed.data.enabled }, updatedAt: sql`now()` },
      });
    return json({ ok: true, flashEnabled: parsed.data.enabled });
  }

  if (action === "confirm") {
    const parsed = await readJson(req, ownerConfirmSchema);
    if (!parsed.ok) return parsed.response;
    const settled = await fulfillPurchase(parsed.data.reference, "manual:owner-vault");
    if (!settled) return json({ error: "Referencia no encontrada o ya procesada" }, 404);
    return json({ ok: true, planId: settled.planId });
  }

  return json({ error: "No encontrado" }, 404);
}
