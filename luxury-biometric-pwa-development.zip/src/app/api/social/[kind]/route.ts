import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { guildMembers, guilds, meals, posts, rewardRolls, users } from "@/db/schema";
import { dbClock, withUser } from "@/lib/server/db";
import { assertSameOrigin, getSessionUser, readJson } from "@/lib/server/security";
import { guildCreateSchema, guildJoinSchema, postSchema } from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ kind: string }> };

const RAFFLE_PRIZE = "Premio del Mes para el Top #1 en Invitaciones Verificadas";
const SHARE_WINDOW_MS = 6 * 60 * 60 * 1000;

function fail(status: number, error: string) {
  return Response.json({ error }, { status });
}

function firstName(name: string): string {
  return name.trim().split(/\s+/)[0] ?? name;
}

export async function GET(_req: Request, ctx: Ctx) {
  const { kind } = await ctx.params;
  const user = await getSessionUser();
  if (!user) return fail(401, "Inicia sesion para continuar");

  if (kind === "posts") {
    const rows = await db
      .select({
        id: posts.id,
        ownerId: posts.userId,
        title: posts.title,
        kcal: posts.kcal,
        purity: posts.purityScore,
        verifiedAi: posts.verifiedAi,
        createdAt: posts.createdAt,
        authorName: users.name,
      })
      .from(posts)
      .innerJoin(users, eq(users.id, posts.userId))
      .orderBy(desc(posts.createdAt))
      .limit(40);
    return Response.json({
      posts: rows.map((row) => ({
        id: row.id,
        title: row.title,
        kcal: row.kcal,
        purity: row.purity,
        verifiedAi: row.verifiedAi,
        createdAt: row.createdAt.toISOString(),
        authorName: row.authorName,
        isMine: row.ownerId === user.id,
      })),
    });
  }

  if (kind === "guilds") {
    const list = await db
      .select({
        id: guilds.id,
        name: guilds.name,
        motto: guilds.motto,
        emblem: guilds.emblem,
        members: sql<number>`(select count(*)::int from guild_members gm where gm.guild_id = guilds.id)`,
        weeklyPoints: sql<number>`(select coalesce(sum(m.discipline_points), 0)::int from meals m join guild_members gm on gm.user_id = m.user_id where gm.guild_id = guilds.id and m.meal_at > now() - interval '7 days')`,
      })
      .from(guilds)
      .limit(100);
    const [mine] = await db
      .select({ guildId: guildMembers.guildId })
      .from(guildMembers)
      .where(eq(guildMembers.userId, user.id))
      .limit(1);
    const ranked = [...list].sort((a, b) => b.weeklyPoints - a.weeklyPoints);
    return Response.json({
      myGuildId: mine?.guildId ?? null,
      guilds: ranked.map((guild, index) => ({
        ...guild,
        rank: index + 1,
        isMine: guild.id === mine?.guildId,
      })),
    });
  }

  if (kind === "raffle") {
    const clock = await dbClock(db);
    const top = (
      await db.execute<{ id: string; name: string; verified: number }>(
        sql`select u.id, u.name, count(r.id)::int as verified from users u join users r on r.invited_by_user_id = u.id where exists (select 1 from meals m where m.user_id = r.id) group by u.id, u.name order by verified desc, min(r.created_at) asc limit 10`,
      )
    ).rows;
    const mine = (
      await db.execute<{ verified: number }>(
        sql`select count(r.id)::int as verified from users r where r.invited_by_user_id = ${user.id} and exists (select 1 from meals m where m.user_id = r.id)`,
      )
    ).rows[0];
    return Response.json({
      prize: RAFFLE_PRIZE,
      period: clock.today.slice(0, 7),
      top: top.map((row, index) => ({
        rank: index + 1,
        name: firstName(row.name),
        verified: row.verified,
        isMe: row.id === user.id,
      })),
      mine: { verified: mine?.verified ?? 0 },
      serverNow: clock.now.toISOString(),
    });
  }

  return fail(404, "No encontrado");
}

export async function POST(req: Request, ctx: Ctx) {
  const { kind } = await ctx.params;
  if (!assertSameOrigin(req)) return fail(403, "Origen no permitido");
  const user = await getSessionUser();
  if (!user) return fail(401, "Inicia sesion para continuar");

  if (kind === "post") {
    const parsed = await readJson(req, postSchema);
    if (!parsed.ok) return parsed.response;
    const mealId = parsed.data.mealId;
    const created = await withUser(user.id, async (tx) => {
      const [meal] = await tx.select().from(meals).where(eq(meals.id, mealId)).limit(1);
      if (!meal) return { status: 404, body: { error: "Comida no encontrada" } };
      const [existing] = await tx
        .select({ id: posts.id })
        .from(posts)
        .where(and(eq(posts.mealId, mealId), eq(posts.userId, user.id)))
        .limit(1);
      if (existing) return { status: 409, body: { error: "Esta comida ya esta publicada" } };
      const [row] = await tx
        .insert(posts)
        .values({
          userId: user.id,
          mealId,
          title: meal.name.slice(0, 80),
          kcal: meal.kcal,
          purityScore: meal.purityScore,
          verifiedAi: meal.verifiedAi,
        })
        .returning();
      return { status: 201, body: { id: row.id, createdAt: row.createdAt.toISOString() } };
    });
    return Response.json(created.body, { status: created.status });
  }

  if (kind === "guild-create") {
    const parsed = await readJson(req, guildCreateSchema);
    if (!parsed.ok) return parsed.response;
    const input = parsed.data;
    try {
      const created = await withUser(user.id, async (tx) => {
        const [existing] = await tx
          .select({ guildId: guildMembers.guildId })
          .from(guildMembers)
          .where(eq(guildMembers.userId, user.id))
          .limit(1);
        if (existing) return { kind: "error" as const, message: "Ya perteneces a un gremio" };
        const [guild] = await tx
          .insert(guilds)
          .values({ name: input.name, motto: input.motto ?? "", createdByUserId: user.id })
          .returning({ id: guilds.id });
        await tx.insert(guildMembers).values({ userId: user.id, guildId: guild.id });
        return { kind: "ok" as const, id: guild.id };
      });
      if (created.kind === "error") return fail(409, created.message);
      return Response.json({ id: created.id }, { status: 201 });
    } catch (error) {
      if ((error as { code?: string }).code === "23505") return fail(409, "Ese nombre de gremio ya existe");
      throw error;
    }
  }

  if (kind === "guild-join") {
    const parsed = await readJson(req, guildJoinSchema);
    if (!parsed.ok) return parsed.response;
    const guildId = parsed.data.guildId;
    const result = await withUser(user.id, async (tx) => {
      const [existing] = await tx
        .select({ guildId: guildMembers.guildId })
        .from(guildMembers)
        .where(eq(guildMembers.userId, user.id))
        .limit(1);
      if (existing) return { status: 409, body: { error: "Ya perteneces a un gremio. Sal primero." } };
      const [guild] = await tx.select({ id: guilds.id }).from(guilds).where(eq(guilds.id, guildId)).limit(1);
      if (!guild) return { status: 404, body: { error: "Gremio no encontrado" } };
      await tx.insert(guildMembers).values({ userId: user.id, guildId: guild.id });
      return { status: 200, body: { guildId: guild.id } };
    });
    return Response.json(result.body, { status: result.status });
  }

  if (kind === "guild-leave") {
    await withUser(user.id, async (tx) => {
      await tx.delete(guildMembers).where(eq(guildMembers.userId, user.id));
    });
    return Response.json({ ok: true });
  }

  if (kind === "share") {
    const bucket = Math.floor(Date.now() / SHARE_WINDOW_MS);
    const clock = await dbClock(db);
    const inserted = await db
      .insert(rewardRolls)
      .values({ userId: user.id, sourceKind: "share", sourceRef: `share:${bucket}` })
      .onConflictDoNothing()
      .returning({ id: rewardRolls.id });
    if (inserted.length === 0) {
      return Response.json({
        fed: false,
        message: "Tu Bio-Pou ya recibio energia en esta ventana de 6 horas.",
      });
    }
    await db
      .update(users)
      .set({ lastActivityAt: clock.now, updatedAt: clock.now })
      .where(eq(users.id, user.id));
    return Response.json({ fed: true, rollId: inserted[0].id });
  }

  return fail(404, "No encontrado");
}
