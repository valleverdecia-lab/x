import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { paywallEvents, purchases, users } from "@/db/schema";
import { dbClock, withUser } from "@/lib/server/db";
import { generateReference } from "@/lib/server/crypto";
import {
  assertSameOrigin,
  getSessionUser,
  loadPublicUser,
  readIdempotencyKey,
  readJson,
  withIdempotency,
} from "@/lib/server/security";
import { getFlashEnabled } from "@/lib/server/services";
import { FLASH_WINDOW_MINUTES, PLAN_IDS, PLANS, type PublicUser } from "@/lib/shared/domain";
import { checkoutSchema } from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ kind: string }> };

async function buildState(user: PublicUser) {
  const clock = await dbClock(db);
  const flashEnabled = await getFlashEnabled();
  const flashActive = Boolean(user.flashOfferUntil && new Date(user.flashOfferUntil).getTime() > clock.now.getTime());
  return {
    serverNow: clock.now.toISOString(),
    flashEnabled,
    flashActive,
    flashEndsAt: user.flashOfferUntil,
    vipActive: user.vipActive,
    vipTier: user.vipTier,
    vipUntil: user.vipUntil,
    vipPermanent: user.vipPermanent,
    plans: PLAN_IDS.map((id) => {
      const plan = PLANS[id];
      return {
        id: plan.id,
        label: plan.label,
        priceCents: plan.priceCents,
        days: plan.days,
        tier: plan.tier,
        flash: plan.flash,
        features: plan.features,
        available: !plan.flash || (flashEnabled && flashActive),
      };
    }),
  };
}

function fail(status: number, error: string) {
  return Response.json({ error }, { status });
}

export async function GET(_req: Request, ctx: Ctx) {
  const { kind } = await ctx.params;
  if (kind !== "state") return fail(404, "No encontrado");
  const user = await getSessionUser();
  if (!user) return fail(401, "Inicia sesion para continuar");
  return Response.json(await buildState(user));
}

export async function POST(req: Request, ctx: Ctx) {
  const { kind } = await ctx.params;
  if (!assertSameOrigin(req)) return fail(403, "Origen no permitido");
  const user = await getSessionUser();
  if (!user) return fail(401, "Inicia sesion para continuar");

  if (kind === "view") {
    await withUser(user.id, async (tx) => {
      await tx.insert(paywallEvents).values({ userId: user.id, event: "view" });
      if (!user.flashOfferUntil) {
        await tx
          .update(users)
          .set({
            flashOfferUntil: sql`now() + make_interval(mins => ${FLASH_WINDOW_MINUTES})`,
            updatedAt: sql`now()`,
          })
          .where(eq(users.id, user.id));
      }
    });
    const refreshed = (await loadPublicUser(user.id)) ?? user;
    return Response.json(await buildState(refreshed));
  }

  if (kind === "checkout") {
    const key = readIdempotencyKey(req);
    if (!key) return fail(400, "Falta la cabecera Idempotency-Key");
    const parsed = await readJson(req, checkoutSchema);
    if (!parsed.ok) return parsed.response;
    const plan = PLANS[parsed.data.planId];

    if (plan.flash) {
      const clock = await dbClock(db);
      const enabled = await getFlashEnabled();
      const active = Boolean(user.flashOfferUntil && new Date(user.flashOfferUntil).getTime() > clock.now.getTime());
      if (!(enabled && active)) return fail(403, "La oferta relampago ya no esta disponible.");
    }

    const method = parsed.data.method;
    const result = await withIdempotency(`checkout:${user.id}`, key, async () => {
      const rows = await withUser(user.id, (tx) =>
        tx
          .insert(purchases)
          .values({
            userId: user.id,
            planId: plan.id,
            amountCents: plan.priceCents,
            currency: "USD",
            paymentMethod: method,
            reference: generateReference(),
            idempotencyKey: key,
            affiliateId: user.affiliateId,
            flashOffer: plan.flash,
          })
          .returning({
            reference: purchases.reference,
            planId: purchases.planId,
            amountCents: purchases.amountCents,
            status: purchases.status,
            paymentMethod: purchases.paymentMethod,
          }),
      );
      const purchase = rows[0];
      const instructions =
        method === "transfermovil_cup"
          ? "Realiza la transferencia por Transfermovil citando la referencia. La activacion se confirma al validar el pago."
          : "El pago con tarjeta se confirma mediante el proveedor. La activacion ocurre al recibir la confirmacion firmada.";
      return { status: 201, body: { purchase, instructions } };
    });
    return Response.json(result.body, { status: result.status });
  }

  return fail(404, "No encontrado");
}
