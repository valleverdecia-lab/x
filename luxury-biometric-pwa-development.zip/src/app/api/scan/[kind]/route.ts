import { rateLimitCheck, rateLimitFail, assertSameOrigin, getSessionUser } from "@/lib/server/security";
import { analyzeBody, analyzeFood, recordMeal, saveBodyScan, VisionError } from "@/lib/server/services";
import { hasGodTier } from "@/lib/shared/domain";

export const dynamic = "force-dynamic";

const ALLOWED_MIME = ["image/webp", "image/jpeg", "image/png"];
const MIN_BYTES = 1_000;
const MAX_BYTES = 200_000;
const HOUR_MS = 60 * 60 * 1000;

type Ctx = { params: Promise<{ kind: string }> };

function fail(status: number, error: string, extra: Record<string, unknown> = {}) {
  return Response.json({ error, ...extra }, { status });
}

export async function POST(req: Request, ctx: Ctx) {
  const { kind } = await ctx.params;
  if (!assertSameOrigin(req)) return fail(403, "Origen no permitido");
  const user = await getSessionUser();
  if (!user) return fail(401, "Inicia sesion para continuar");
  if (kind !== "food" && kind !== "body") return fail(404, "No encontrado");
  if (kind === "body" && !hasGodTier(user)) {
    return fail(402, "El escaner de fisico es exclusivo de MODO DIOS.", { locked: true });
  }

  const limitKey = `scan:${user.id}`;
  const wait = await rateLimitCheck(limitKey);
  if (wait > 0) return fail(429, "Limite de escaneos alcanzado. Espera antes de continuar.", { retryAfter: wait });

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail(400, "Formulario no valido");
  }
  const image = form.get("image");
  if (!(image instanceof File)) return fail(400, "Falta la imagen");
  if (image.size < MIN_BYTES || image.size > MAX_BYTES) {
    return fail(400, "La imagen debe pesar entre 1 KB y 200 KB");
  }
  if (!ALLOWED_MIME.includes(image.type)) return fail(415, "Formato de imagen no permitido");

  const bytes = Buffer.from(await image.arrayBuffer());
  await rateLimitFail(limitKey, 40, HOUR_MS);

  try {
    if (kind === "food") {
      const analysis = await analyzeFood(bytes, image.type);
      if (!analysis.isFood) return fail(422, "No detectamos comida en la imagen.");
      const result = await recordMeal(
        user,
        {
          name: analysis.name.slice(0, 80),
          source: "vision",
          catalogId: null,
          grams: analysis.grams,
          kcal: analysis.kcal,
          protein: analysis.protein,
          carbs: analysis.carbs,
          fat: analysis.fat,
          inflammation: analysis.inflammation,
          purity: analysis.purity,
          verifiedAi: true,
        },
        { offline: false },
      );
      return Response.json({ ...result, confidence: analysis.confidence });
    }

    const analysis = await analyzeBody(bytes, image.type);
    if (!analysis.isHuman) return fail(422, "No detectamos una persona en la imagen.");
    const row = await saveBodyScan(user, analysis);
    return Response.json({
      scan: {
        id: row.id,
        bodyFatPct: row.bodyFatPct,
        symmetryScore: row.symmetryScore,
        auraPoints: row.auraPoints,
        verdict: row.verdict,
        createdAt: row.createdAt.toISOString(),
      },
    });
  } catch (error) {
    if (error instanceof VisionError) {
      return fail(error.status, error.message, { fallback: "catalog" });
    }
    throw error;
  }
}
