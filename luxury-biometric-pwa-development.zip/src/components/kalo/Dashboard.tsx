"use client";

import { useCallback, useEffect, useState } from "react";
import { play } from "@/lib/client/audio";
import { api } from "@/lib/client/hooks";
import { fireImpact } from "@/lib/client/media";
import { queueList, type QueuedMeal } from "@/lib/client/offline";
import { evolutionFor, type MealView, type PublicUser, THEMES } from "@/lib/shared/domain";
import { BioAlert, BioPou, BioWidget } from "./BioPou";
import { PaperTear } from "./vfx";
import { Glass, Icon, Modal, MutexButton, ProgressBar, SectionTitle, Skeleton, formatDate, formatTime } from "./ui";

interface MealsPayload {
  meals: MealView[];
  totals: { kcal: number; protein: number; carbs: number; fat: number };
  goals: { kcal: number; protein: number };
  pendingRolls: Array<{ id: string; sourceKind: string; createdAt: string }>;
  streak: { days: number; broken: boolean; brokenDays: number; promiseSignedAt: string | null };
  energy: number;
  today: string;
  serverNow: string;
}

interface Reward {
  type: "xp" | "theme" | "vip_24h";
  value: string;
}

function describeReward(reward: Reward): string {
  if (reward.type === "xp") return "+10 XP aplicados a tu Bio-Pou.";
  if (reward.type === "theme") return `Tema desbloqueado: ${reward.value}.`;
  return "24 horas de VIP activadas.";
}

function rollLabel(kind: string): string {
  if (kind === "meal") return "Comida verificada";
  if (kind === "invite") return "Amigo verificado";
  return "Bio-Pou alimentado";
}

export function Dashboard({
  user,
  energy,
  onChanged,
  onGoScan,
}: {
  user: PublicUser;
  energy: number;
  onChanged: () => Promise<void> | void;
  onGoScan: () => void;
}) {
  const [payload, setPayload] = useState<MealsPayload | null>(null);
  const [queued, setQueued] = useState<QueuedMeal[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [brokenOpen, setBrokenOpen] = useState(false);
  const [themeError, setThemeError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const result = await api<MealsPayload>("/api/meals");
    if (result.ok) {
      setPayload(result.data);
      if (result.data.streak.broken) setBrokenOpen(true);
    }
  }, []);

  const loadQueue = useCallback(async () => {
    try {
      setQueued(await queueList());
    } catch {
      setQueued([]);
    }
  }, []);

  useEffect(() => {
    void load();
    void loadQueue();
    const id = window.setInterval(() => void loadQueue(), 8000);
    return () => window.clearInterval(id);
  }, [load, loadQueue]);

  const openRoll = async (rollId: string) => {
    setMessage(null);
    const result = await api<{ reward: Reward }>("/api/game/open", { body: { rollId } });
    if (!result.ok) {
      setMessage(result.error);
      return;
    }
    play("levelup");
    if (result.data.reward.type === "vip_24h") fireImpact();
    setMessage(describeReward(result.data.reward));
    await load();
    await onChanged();
  };

  const share = async () => {
    setMessage(null);
    const url = `${window.location.origin}/?ref=${user.inviteCode}`;
    try {
      if (typeof navigator.share === "function") {
        await navigator.share({ title: "KALO // AURA AI", text: "Entrena tu Bio-Pou conmigo", url });
      } else {
        await navigator.clipboard.writeText(url);
      }
    } catch {
      // The user cancelled the share sheet; the feed action below is still evaluated.
    }
    const result = await api<{ fed: boolean; message?: string; rollId?: string }>("/api/social/share", {
      body: {},
    });
    if (!result.ok) {
      setMessage(result.error);
      return;
    }
    if (result.data.fed) {
      play("success");
      setMessage("Tu Bio-Pou recibio energia. Abre la caja de suministros cuando quieras.");
    } else {
      setMessage(result.data.message ?? "Tu Bio-Pou ya recibio energia recientemente.");
    }
    await load();
    await onChanged();
  };

  const saveTheme = async (theme: string) => {
    setThemeError(null);
    const result = await api("/api/auth/profile", {
      body: { goalKcal: user.goalKcal, goalProtein: user.goalProtein, dietPlan: user.dietPlan, theme },
    });
    if (!result.ok) {
      setThemeError(result.error);
      return;
    }
    play("click");
    await onChanged();
  };

  const stage = evolutionFor(user.xp).stage;
  const streakDays = payload?.streak.days ?? user.streakDays;
  const totals = payload?.totals ?? { kcal: 0, protein: 0, carbs: 0, fat: 0 };
  const goals = payload?.goals ?? { kcal: user.goalKcal, protein: user.goalProtein };
  const kcalPct = goals.kcal > 0 ? (totals.kcal / goals.kcal) * 100 : 0;
  const todayLabel = payload
    ? new Date(`${payload.today}T00:00:00Z`).toLocaleDateString("es", { day: "2-digit", month: "short", timeZone: "UTC" })
    : "";

  return (
    <div className="kalo-fade-in space-y-8 pt-2">
      <section aria-label="Bio-Pou">
        <SectionTitle eyebrow="Simbionte biometrico" title={`Hola, ${user.name}`} />
        <Glass className="flex flex-col items-center gap-5 p-6">
          <BioPou energy={energy} stage={stage} size={210} />
          <div className="w-full space-y-3">
            <div className="flex items-center justify-between text-xs text-[color:var(--kalo-muted)]">
              <span>Bio-Core</span>
              <span className="font-semibold text-[color:var(--kalo-titanium)]">{energy}%</span>
            </div>
            <ProgressBar value={energy} tone={energy < 30 ? "danger" : "gold"} />
            <BioAlert energy={energy} />
          </div>
          <div className="flex w-full items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs text-[color:var(--kalo-muted)]">Racha actual</p>
              <p className="text-lg font-semibold">{streakDays} dias</p>
            </div>
            <MutexButton variant="ghost" onPress={share} className="kalo-btn-sm">
              <Icon name="share" size={15} />
              Alimentar con un amigo
            </MutexButton>
          </div>
          {message ? (
            <p role="status" className="kalo-fade-in w-full text-center text-xs text-[color:var(--kalo-gold)]">
              {message}
            </p>
          ) : null}
        </Glass>
        <div className="mt-3">
          <BioWidget energy={energy} stage={stage} streak={streakDays} />
        </div>
      </section>

      <section aria-label="Resumen diario">
        <SectionTitle
          eyebrow="Ticket diario"
          title="Resumen nutricional"
          right={
            <button type="button" onClick={onGoScan} className="kalo-btn kalo-btn-ghost kalo-btn-sm">
              <Icon name="scan" size={14} />
              Escanear
            </button>
          }
        />
        {payload ? (
          <PaperTear title="Resumen de hoy" dateLabel={todayLabel}>
            <div className="space-y-4">
              <div>
                <div className="flex items-end justify-between">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#070709]/60">Calorias</span>
                  <span className="text-sm font-semibold">
                    {totals.kcal} / {goals.kcal} kcal
                  </span>
                </div>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-[#070709]/10">
                  <div className="h-full rounded-full bg-[#070709]" style={{ width: `${Math.min(100, kcalPct)}%` }} />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <Macro label="Proteina" value={`${totals.protein} g`} />
                <Macro label="Carbos" value={`${totals.carbs} g`} />
                <Macro label="Grasas" value={`${totals.fat} g`} />
              </div>
              <p className="text-xs text-[#070709]/70">
                {payload.meals.filter((meal) => meal.mealAt.slice(0, 10) === payload.today).length} registros verificados · Proteina objetivo {goals.protein} g
              </p>
            </div>
          </PaperTear>
        ) : (
          <Skeleton className="h-[360px] w-full" />
        )}
      </section>

      <section aria-label="Cajas de suministros">
        <SectionTitle eyebrow="Recompensa variable" title="Cajas de suministros" />
        <Glass className="space-y-3 p-5">
          {payload && payload.pendingRolls.length > 0 ? (
            payload.pendingRolls.map((roll) => (
              <div key={roll.id} className="flex items-center justify-between gap-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{rollLabel(roll.sourceKind)}</p>
                  <p className="text-xs text-[color:var(--kalo-muted)]">{formatTime(roll.createdAt)}</p>
                </div>
                <MutexButton className="kalo-btn-sm shrink-0" onPress={() => openRoll(roll.id)} busyLabel="Abriendo">
                  <Icon name="gift" size={15} />
                  Abrir
                </MutexButton>
              </div>
            ))
          ) : (
            <p className="text-sm text-[color:var(--kalo-muted)]">
              Cada comida verificada y cada amigo que llega con tu enlace genera una caja con recompensas variables.
            </p>
          )}
        </Glass>
      </section>

      <section aria-label="Temas">
        <SectionTitle eyebrow="Personalizacion" title="Temas de la app" />
        <Glass className="space-y-3 p-5">
          <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Tema visual">
            {THEMES.map((theme) => {
              const unlocked = theme === "obsidian" || user.unlockedThemes.includes(theme);
              const active = user.theme === theme;
              return (
                <button
                  key={theme}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  disabled={!unlocked}
                  onClick={() => void saveTheme(theme)}
                  className={`kalo-btn kalo-btn-ghost kalo-btn-sm justify-between ${active ? "border-[rgba(229,193,88,0.6)] text-[color:var(--kalo-gold)]" : ""}`}
                >
                  <span className="capitalize">{theme}</span>
                  {unlocked ? <Icon name="check" size={14} /> : <Icon name="lock" size={14} />}
                </button>
              );
            })}
          </div>
          {themeError ? <p role="alert" className="text-xs text-[color:var(--kalo-danger)]">{themeError}</p> : null}
        </Glass>
      </section>

      <section aria-label="Historial">
        <SectionTitle eyebrow="Historial" title="Ultimos registros" />
        {queued.length > 0 ? (
          <Glass className="mb-3 p-4">
            <p className="text-xs text-[color:var(--kalo-gold)]">Guardado en este dispositivo. Se sincroniza al recuperar la red.</p>
            <ul className="mt-2 space-y-1">
              {queued.map((item) => (
                <li key={item.clientId} className="kalo-ellipsis text-xs text-[color:var(--kalo-muted)]">
                  {item.name} · {item.grams} g · {item.kcal} kcal
                </li>
              ))}
            </ul>
          </Glass>
        ) : null}
        {payload === null ? (
          <div className="space-y-2">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        ) : payload.meals.length === 0 ? (
          <Glass className="p-5 text-sm text-[color:var(--kalo-muted)]">Aun no hay comidas registradas. Escanea tu primer plato.</Glass>
        ) : (
          <ul className="space-y-2">
            {payload.meals.slice(0, 12).map((meal) => (
              <li key={meal.id} className="kalo-glass flex items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  <p className="kalo-ellipsis text-sm font-semibold">{meal.name}</p>
                  <p className="text-xs text-[color:var(--kalo-muted)]">
                    {formatDate(meal.mealAt)} · {formatTime(meal.mealAt)} · P {meal.protein} · C {meal.carbs} · G {meal.fat}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-sm font-semibold">{meal.kcal} kcal</p>
                  <p className="text-[10px] uppercase tracking-[0.12em] text-[color:var(--kalo-neon)]">
                    {meal.verifiedAi ? "IA verificada" : meal.source === "catalog" ? "Catalogo" : "Registro"}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <Modal open={brokenOpen} onClose={() => setBrokenOpen(false)} title="Racha interrumpida">
        <div className="space-y-4 text-sm leading-relaxed text-[color:var(--kalo-muted)]">
          <p>
            Perdiste una racha de <span className="font-semibold text-[color:var(--kalo-titanium)]">{payload?.streak.brokenDays ?? 0} dias</span>. Tu Bio-Pou
            perdio brillo mientras no hubo registros.
          </p>
          {payload?.streak.promiseSignedAt ? (
            <Glass className="p-4 text-center">
              <p className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-gold)]">Compromiso firmado</p>
              <p className="mt-2 text-sm font-semibold text-[color:var(--kalo-titanium)]">&ldquo;Me comprometo a no fallarme a mi mismo&rdquo;</p>
              <p className="mt-2 text-xs">
                {formatDate(payload.streak.promiseSignedAt)} · {formatTime(payload.streak.promiseSignedAt)} (hora del servidor)
              </p>
            </Glass>
          ) : null}
          <button type="button" onClick={() => setBrokenOpen(false)} className="kalo-btn kalo-btn-gold w-full">
            Volver a empezar hoy
          </button>
        </div>
      </Modal>
    </div>
  );
}

function Macro({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-[#070709]/15 p-3">
      <p className="text-[10px] uppercase tracking-[0.16em] text-[#070709]/60">{label}</p>
      <p className="mt-1 text-base font-semibold">{value}</p>
    </div>
  );
}
