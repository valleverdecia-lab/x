export const OWNER_EMAIL = "valleverdecia@gmail.com";

export type FoodGroup = "cubana" | "latina" | "global" | "saludable" | "bebida";

export interface FoodItem {
  id: string;
  name: string;
  group: FoodGroup;
  baseGrams: number;
  per100: { kcal: number; protein: number; carbs: number; fat: number };
  inflammation: number;
  purity: number;
}

export const FOOD_CATALOG: readonly FoodItem[] = [
  { id: "arroz-congri", name: "Arroz congri", group: "cubana", baseGrams: 250, per100: { kcal: 150, protein: 4, carbs: 25, fat: 4 }, inflammation: 35, purity: 62 },
  { id: "arroz-blanco", name: "Arroz blanco", group: "cubana", baseGrams: 200, per100: { kcal: 130, protein: 2.7, carbs: 28, fat: 0.3 }, inflammation: 20, purity: 70 },
  { id: "picadillo", name: "Picadillo de res", group: "cubana", baseGrams: 200, per100: { kcal: 165, protein: 14, carbs: 6, fat: 9 }, inflammation: 40, purity: 60 },
  { id: "ropa-vieja", name: "Ropa vieja", group: "cubana", baseGrams: 200, per100: { kcal: 170, protein: 15, carbs: 7, fat: 9 }, inflammation: 38, purity: 62 },
  { id: "lechon", name: "Lechon asado", group: "cubana", baseGrams: 150, per100: { kcal: 280, protein: 20, carbs: 0, fat: 22 }, inflammation: 70, purity: 30 },
  { id: "tostones", name: "Tostones", group: "cubana", baseGrams: 120, per100: { kcal: 240, protein: 1.2, carbs: 35, fat: 11 }, inflammation: 55, purity: 35 },
  { id: "maduros", name: "Platano maduro frito", group: "cubana", baseGrams: 120, per100: { kcal: 190, protein: 1, carbs: 40, fat: 4 }, inflammation: 50, purity: 40 },
  { id: "yuca-hervida", name: "Yuca hervida", group: "cubana", baseGrams: 200, per100: { kcal: 160, protein: 1.4, carbs: 38, fat: 0.3 }, inflammation: 15, purity: 80 },
  { id: "croqueta", name: "Croqueta de jamon", group: "cubana", baseGrams: 60, per100: { kcal: 260, protein: 8, carbs: 22, fat: 16 }, inflammation: 65, purity: 28 },
  { id: "empanada", name: "Empanada de carne", group: "cubana", baseGrams: 110, per100: { kcal: 290, protein: 10, carbs: 28, fat: 16 }, inflammation: 68, purity: 26 },
  { id: "tamal", name: "Tamal en cazuela", group: "cubana", baseGrams: 180, per100: { kcal: 180, protein: 4, carbs: 27, fat: 6 }, inflammation: 40, purity: 55 },
  { id: "pan-cubano", name: "Pan cubano", group: "cubana", baseGrams: 90, per100: { kcal: 270, protein: 9, carbs: 52, fat: 3 }, inflammation: 35, purity: 45 },
  { id: "sandwich-cubano", name: "Sandwich cubano", group: "cubana", baseGrams: 250, per100: { kcal: 300, protein: 16, carbs: 30, fat: 12 }, inflammation: 50, purity: 40 },
  { id: "frijoles-negros", name: "Frijoles negros", group: "latina", baseGrams: 200, per100: { kcal: 132, protein: 8.9, carbs: 24, fat: 0.5 }, inflammation: 18, purity: 85 },
  { id: "pollo-asado", name: "Pollo asado sin piel", group: "latina", baseGrams: 180, per100: { kcal: 190, protein: 22, carbs: 0, fat: 11 }, inflammation: 25, purity: 78 },
  { id: "batido-mango", name: "Batido de mango con leche", group: "latina", baseGrams: 300, per100: { kcal: 110, protein: 3.5, carbs: 18, fat: 2.8 }, inflammation: 25, purity: 60 },
  { id: "jugo-naranja", name: "Jugo de naranja natural", group: "latina", baseGrams: 250, per100: { kcal: 45, protein: 0.7, carbs: 10, fat: 0.2 }, inflammation: 10, purity: 80 },
  { id: "cafe-leche", name: "Cafe con leche", group: "latina", baseGrams: 250, per100: { kcal: 45, protein: 2.5, carbs: 4, fat: 2 }, inflammation: 10, purity: 50 },
  { id: "huevos-revueltos", name: "Huevos revueltos", group: "global", baseGrams: 120, per100: { kcal: 155, protein: 12, carbs: 1.5, fat: 11 }, inflammation: 25, purity: 85 },
  { id: "pescado-plancha", name: "Pescado a la plancha", group: "saludable", baseGrams: 180, per100: { kcal: 120, protein: 22, carbs: 0, fat: 3 }, inflammation: 12, purity: 95 },
  { id: "pechuga-pollo", name: "Pechuga de pollo a la plancha", group: "saludable", baseGrams: 170, per100: { kcal: 165, protein: 31, carbs: 0, fat: 3.6 }, inflammation: 10, purity: 96 },
  { id: "avena-cocida", name: "Avena cocida con agua", group: "saludable", baseGrams: 250, per100: { kcal: 71, protein: 2.5, carbs: 12, fat: 1.5 }, inflammation: 8, purity: 92 },
  { id: "arroz-integral", name: "Arroz integral cocido", group: "saludable", baseGrams: 200, per100: { kcal: 123, protein: 2.7, carbs: 25, fat: 1 }, inflammation: 12, purity: 92 },
  { id: "ensalada-verde", name: "Ensalada verde mixta", group: "saludable", baseGrams: 150, per100: { kcal: 25, protein: 1.5, carbs: 4, fat: 0.3 }, inflammation: 5, purity: 98 },
  { id: "batido-proteina", name: "Batido de proteina whey", group: "saludable", baseGrams: 300, per100: { kcal: 70, protein: 12, carbs: 4, fat: 1 }, inflammation: 5, purity: 88 },
  { id: "sushi-roll", name: "Sushi roll (8 piezas)", group: "global", baseGrams: 220, per100: { kcal: 150, protein: 6, carbs: 25, fat: 3 }, inflammation: 30, purity: 60 },
  { id: "pizza-queso", name: "Pizza de queso (porcion)", group: "global", baseGrams: 110, per100: { kcal: 265, protein: 11, carbs: 33, fat: 10 }, inflammation: 55, purity: 30 },
  { id: "hamburguesa", name: "Hamburguesa con queso", group: "global", baseGrams: 200, per100: { kcal: 250, protein: 13, carbs: 24, fat: 12 }, inflammation: 55, purity: 35 },
  { id: "pasta-bolonesa", name: "Pasta a la bolonesa", group: "global", baseGrams: 350, per100: { kcal: 150, protein: 6, carbs: 20, fat: 5 }, inflammation: 40, purity: 60 },
  { id: "cerveza", name: "Cerveza", group: "bebida", baseGrams: 330, per100: { kcal: 43, protein: 0.5, carbs: 3.6, fat: 0 }, inflammation: 40, purity: 15 },
];

export interface MacroSet {
  grams: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  inflammation: number;
  purity: number;
  disciplinePoints: number;
}

export function findFood(id: string): FoodItem | undefined {
  return FOOD_CATALOG.find((item) => item.id === id);
}

export function macrosFor(item: FoodItem, grams: number): MacroSet {
  const factor = grams / 100;
  return {
    grams,
    kcal: Math.round(item.per100.kcal * factor),
    protein: Math.round(item.per100.protein * factor),
    carbs: Math.round(item.per100.carbs * factor),
    fat: Math.round(item.per100.fat * factor),
    inflammation: item.inflammation,
    purity: item.purity,
    disciplinePoints: Math.round(item.purity / 10),
  };
}

export const PLAN_IDS = ["basic_monthly", "decoy_quarterly", "god_mode"] as const;
export type PlanId = (typeof PLAN_IDS)[number];

export interface Plan {
  id: PlanId;
  label: string;
  priceCents: number;
  days: number;
  tier: "basic" | "god";
  flash: boolean;
  features: string[];
}

export const PLANS: Record<PlanId, Plan> = {
  basic_monthly: {
    id: "basic_monthly",
    label: "Basico mensual",
    priceCents: 499,
    days: 30,
    tier: "basic",
    flash: false,
    features: ["Escaner de comida sin limite diario", "Bio-Pou con evolucion estandar"],
  },
  decoy_quarterly: {
    id: "decoy_quarterly",
    label: "Trimestral estandar",
    priceCents: 1399,
    days: 90,
    tier: "basic",
    flash: false,
    features: ["Escaner de comida sin limite diario", "Bio-Pou con evolucion estandar"],
  },
  god_mode: {
    id: "god_mode",
    label: "Modo Dios",
    priceCents: 399,
    days: 30,
    tier: "god",
    flash: true,
    features: [
      "Escaner de comida y fisico ilimitados",
      "Analisis profundo sin bloqueos",
      "Evolucion maxima del Bio-Pou",
      "Nombre dorado en el muro y en Gremios",
    ],
  },
};

export const FLASH_WINDOW_MINUTES = 14;

export const THEMES = ["obsidian", "aurora", "magma", "carbono"] as const;
export type ThemeId = (typeof THEMES)[number];

export const DIET_PLANS = ["equilibrio", "definicion", "masa", "salud-latina"] as const;

export const EVOLUTION_STAGES = [
  { min: 0, name: "Germen" },
  { min: 200, name: "Cria" },
  { min: 700, name: "Ascendido" },
  { min: 1500, name: "Aureo" },
] as const;

export function evolutionFor(xp: number): { stage: string; min: number; next: number | null } {
  let current: (typeof EVOLUTION_STAGES)[number] = EVOLUTION_STAGES[0];
  let next: number | null = null;
  for (let index = 0; index < EVOLUTION_STAGES.length; index++) {
    const stage = EVOLUTION_STAGES[index];
    if (xp >= stage.min) {
      current = stage;
      next = EVOLUTION_STAGES[index + 1]?.min ?? null;
    }
  }
  return { stage: current.name, min: current.min, next };
}

export function energyFromIdle(hoursIdle: number): number {
  const safe = Number.isFinite(hoursIdle) ? Math.max(0, hoursIdle) : 0;
  return Math.max(0, Math.min(100, Math.round(100 - safe * (88 / 24))));
}

export function shiftDay(day: string, delta: number): string {
  const date = new Date(`${day}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + delta);
  return date.toISOString().slice(0, 10);
}

export interface PublicUser {
  id: string;
  email: string;
  name: string;
  age: number;
  role: "user" | "owner";
  vipActive: boolean;
  vipTier: "none" | "basic" | "god";
  vipUntil: string | null;
  vipPermanent: boolean;
  inviteCode: string;
  affiliateId: string | null;
  invitedByUserId: string | null;
  streakDays: number;
  streakLastDay: string | null;
  xp: number;
  goalKcal: number;
  goalProtein: number;
  dietPlan: string;
  theme: string;
  unlockedThemes: string[];
  promiseSignedAt: string | null;
  flashOfferUntil: string | null;
  lastActivityAt: string;
  createdAt: string;
}

export function hasGodTier(user: Pick<PublicUser, "role" | "vipActive" | "vipTier">): boolean {
  return user.role === "owner" || (user.vipActive && user.vipTier === "god");
}

export function hasVip(user: Pick<PublicUser, "role" | "vipActive">): boolean {
  return user.role === "owner" || user.vipActive;
}

export interface MealView {
  id: string;
  name: string;
  source: string;
  catalogId: string | null;
  grams: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  inflammation: number;
  purity: number;
  verifiedAi: boolean;
  offlineQueued: boolean;
  mealAt: string;
}

export interface PostView {
  id: string;
  title: string;
  kcal: number;
  purity: number;
  verifiedAi: boolean;
  createdAt: string;
  authorName: string;
  isMine: boolean;
}
