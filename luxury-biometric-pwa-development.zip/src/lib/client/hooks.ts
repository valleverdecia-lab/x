"use client";

import { useCallback, useEffect, useReducer, useRef, useState, useSyncExternalStore } from "react";

export type ApiResult<T> =
  | { ok: true; status: number; data: T }
  | { ok: false; status: number; error: string; retryAfter?: number };

let serverOffsetMs = 0;

export function syncServerClock(serverNowIso: string | undefined): void {
  if (!serverNowIso) return;
  const parsed = Date.parse(serverNowIso);
  if (!Number.isNaN(parsed)) serverOffsetMs = parsed - Date.now();
}

export function serverNow(): number {
  return Date.now() + serverOffsetMs;
}

export function newKey(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export async function api<T>(
  path: string,
  options: {
    method?: "GET" | "POST";
    body?: unknown;
    form?: FormData;
    idempotencyKey?: string;
  } = {},
): Promise<ApiResult<T>> {
  const headers: Record<string, string> = {};
  let body: BodyInit | undefined;
  if (options.form) {
    body = options.form;
  } else if (options.body !== undefined) {
    headers["content-type"] = "application/json";
    body = JSON.stringify(options.body);
  }
  if (options.idempotencyKey) headers["idempotency-key"] = options.idempotencyKey;

  let response: Response;
  try {
    response = await fetch(path, {
      method: options.method ?? (body ? "POST" : "GET"),
      headers,
      body,
      credentials: "same-origin",
      cache: "no-store",
    });
  } catch {
    return { ok: false, status: 0, error: "Sin conexion con el servidor." };
  }

  let payload: unknown = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }
  const record = (payload ?? {}) as Record<string, unknown>;
  if (typeof record.serverNow === "string") syncServerClock(record.serverNow);

  if (!response.ok) {
    return {
      ok: false,
      status: response.status,
      error: typeof record.error === "string" ? record.error : "Ocurrio un error inesperado.",
      retryAfter: typeof record.retryAfter === "number" ? record.retryAfter : undefined,
    };
  }
  return { ok: true, status: response.status, data: payload as T };
}

const subscribeNothing = () => () => undefined;

export function useHydrated(): boolean {
  return useSyncExternalStore(
    subscribeNothing,
    () => true,
    () => false,
  );
}

export function useMutexAction<A extends unknown[], R>(action: (...args: A) => Promise<R>) {
  const actionRef = useRef(action);
  const lockRef = useRef(false);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    actionRef.current = action;
  });

  const run = useCallback(async (...args: A): Promise<R | undefined> => {
    if (lockRef.current) return undefined;
    lockRef.current = true;
    setPending(true);
    try {
      return await actionRef.current(...args);
    } finally {
      lockRef.current = false;
      setPending(false);
    }
  }, []);

  return { run, pending };
}

export function useCountdown(endIso: string | null | undefined): number {
  const [, tick] = useReducer((value: number) => value + 1, 0);
  useEffect(() => {
    if (!endIso) return;
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [endIso]);
  if (!endIso) return 0;
  return Math.max(0, Date.parse(endIso) - serverNow());
}

type TabRole = "probing" | "primary" | "secondary";

interface TabMessage {
  type: "hello" | "present" | "takeover";
  from: string;
  startedAt: number;
}

export function useTabLock(): { locked: boolean; takeOver: () => void } {
  const [locked, setLocked] = useState(false);
  const takeOverRef = useRef<() => void>(() => undefined);

  useEffect(() => {
    if (typeof window === "undefined" || typeof BroadcastChannel === "undefined") return;

    const id = newKey();
    const startedAt = Date.now();
    const channel = new BroadcastChannel("kalo_sync");
    let role: TabRole = "probing";

    const apply = (next: TabRole) => {
      role = next;
      setLocked(next === "secondary");
    };

    channel.onmessage = (event: MessageEvent<TabMessage>) => {
      const message = event.data;
      if (!message || typeof message !== "object" || message.from === id) return;

      if (message.type === "hello") {
        if (role !== "secondary") {
          channel.postMessage({ type: "present", from: id, startedAt } satisfies TabMessage);
        }
        return;
      }
      if (message.type === "present") {
        const older =
          message.startedAt < startedAt || (message.startedAt === startedAt && message.from < id);
        if (role === "probing" && older) apply("secondary");
        return;
      }
      if (message.type === "takeover") {
        if (role !== "secondary") apply("secondary");
      }
    };

    const probe = window.setTimeout(() => {
      if (role === "probing") apply("primary");
    }, 350);

    takeOverRef.current = () => {
      apply("primary");
      channel.postMessage({ type: "takeover", from: id, startedAt } satisfies TabMessage);
    };

    channel.postMessage({ type: "hello", from: id, startedAt } satisfies TabMessage);

    return () => {
      window.clearTimeout(probe);
      channel.close();
    };
  }, []);

  const takeOver = useCallback(() => takeOverRef.current(), []);
  return { locked, takeOver };
}
