import { and, desc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { meals, rewardRolls, users } from "@/db/schema";
import { dbClock, withUser } from "@/lib/server/db";
import { catalogMealInput, recordMeal, toMealView } from "@/lib/server/services";
import { assertSameOrigin, getSessionUser, readJson } from "@/lib/server/security";
import { energyFromIdle, FOOD_CATALOG, findFood, macrosFor, shiftDay } from "@/lib/shared/domain";
import { mealSchema } from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Inicia sesion para continuar" }, { status: 401 });

  const clock = await dbClock(db);
  const { mealRows, rolls } = await withUser(user.id, async (tx) => {
    const mealRows = await tx
      .select()
      .from(meals)
      .where(eq(meals.userId, user.id))
      .orderBy(desc(meals.mealAt))
      .limit(80);
    const rolls = await tx
      .select({
        id: rewardRolls.id,
        sourceKind: rewardRolls.sourceKind,
        createdAt: rewardRolls.createdAt,
      })
      .from(rewardRolls)
      .where(and(eq(rewardRolls.userId, user.id), isNull(rewardRolls.rewardType)))
      .orderBy(desc(rewardRolls.createdAt))
      .limit(20);
    return { mealRows, rolls };
  });

  let streak = {
    days: user.streakDays,
    broken: false,
    brokenDays: 0,
    promiseSignedAt: user.promiseSignedAt,
  };
  const yesterday = shiftDay(clock.today, -1);
  if (user.streakDays > 0 && user.streakLastDay && user.streakLastDay < yesterday) {
    await db
      .update(users)
      .set({ streakDays: 0, updatedAt: clock.now })
      .where(eq(users.id, user.id));
    streak = {
      days: 0,
      broken: true,
      brokenDays: user.streakDays,
      promiseSignedAt: user.promiseSignedAt,
    };
  }

  const todayMeals = mealRows.filter((meal) => meal.mealAt.toISOString().slice(0, 10) === clock.today);
  const totals = todayMeals.reduce(
    (acc, meal) => ({
      kcal: acc.kcal + meal.kcal,
      protein: acc.protein + meal.proteinG,
      carbs: acc.carbs + meal.carbsG,
      fat: acc.fat + meal.fatG,
    }),
    { kcal: 0, protein: 0, carbs: 0, fat: 0 },
  );

  return Response.json({
    meals: mealRows.map(toMealView),
    totals,
    goals: { kcal: user.goalKcal, protein: user.goalProtein },
    pendingRolls: rolls.map((roll) => ({
      id: roll.id,
      sourceKind: roll.sourceKind,
      createdAt: roll.createdAt.toISOString(),
    })),
    streak,
    energy: energyFromIdle((clock.now.getTime() - new Date(user.lastActivityAt).getTime()) / 3_600_000),
    catalog: FOOD_CATALOG,
    serverNow: clock.now.toISOString(),
    today: clock.today,
  });
}

export async function POST(req: Request) {
  if (!assertSameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Inicia sesion para continuar" }, { status: 401 });

  const parsed = await readJson(req, mealSchema);
  if (!parsed.ok) return parsed.response;
  const item = findFood(parsed.data.catalogId);
  if (!item) return Response.json({ error: "Alimento no encontrado en el catalogo" }, { status: 404 });

  const macros = macrosFor(item, parsed.data.grams);
  const result = await recordMeal(user, catalogMealInput(item, macros), {
    clientId: parsed.data.clientId,
    offline: false,
  });
  return Response.json(result);
}
