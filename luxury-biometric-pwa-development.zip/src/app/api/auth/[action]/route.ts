import { and, eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { affiliates, users } from "@/db/schema";
import { energyFromIdle, evolutionFor, OWNER_EMAIL } from "@/lib/shared/domain";
import { loginSchema, profileSchema, promiseSchema, registerSchema } from "@/lib/shared/schemas";
import { generateInviteCode, hashPassword, sha256Hex, verifyPassword } from "@/lib/server/crypto";
import { dbClock, ensureDbSecurity, withUser } from "@/lib/server/db";
import {
  assertSameOrigin,
  clientIp,
  createSession,
  destroySession,
  getSessionUser,
  loadPublicUser,
  rateLimitCheck,
  rateLimitFail,
  rateLimitReset,
  readIdempotencyKey,
  readJson,
  withIdempotency,
} from "@/lib/server/security";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ action: string }> };

function fail(status: number, error: string, extra: Record<string, unknown> = {}) {
  return Response.json({ error, ...extra }, { status });
}

export async function GET(_req: Request, ctx: Ctx) {
  const { action } = await ctx.params;
  if (action !== "me") return fail(404, "No encontrado");
  await ensureDbSecurity();
  const clock = await dbClock(db);
  const user = await getSessionUser();
  if (!user) return Response.json({ user: null, serverNow: clock.now.toISOString() });

  await db
    .update(users)
    .set({ lastSeenAt: sql`now()` })
    .where(and(eq(users.id, user.id), lt(users.lastSeenAt, sql`now() - interval '5 minutes'`)));

  const idleHours = (clock.now.getTime() - new Date(user.lastActivityAt).getTime()) / 3_600_000;
  return Response.json({
    user,
    serverNow: clock.now.toISOString(),
    energy: energyFromIdle(idleHours),
    evolution: evolutionFor(user.xp),
  });
}

export async function POST(req: Request, ctx: Ctx) {
  const { action } = await ctx.params;
  if (!assertSameOrigin(req)) return fail(403, "Origen no permitido");
  await ensureDbSecurity();
  switch (action) {
    case "register":
      return register(req);
    case "login":
      return login(req);
    case "logout":
      await destroySession();
      return Response.json({ ok: true });
    case "promise":
      return promise(req);
    case "profile":
      return profile(req);
    default:
      return fail(404, "No encontrado");
  }
}

async function register(req: Request) {
  const parsed = await readJson(req, registerSchema);
  if (!parsed.ok) return parsed.response;
  const key = readIdempotencyKey(req);
  if (!key) return fail(400, "Falta la cabecera Idempotency-Key");
  const input = parsed.data;

  const result = await withIdempotency("register", key, async () => {
    if (input.email === OWNER_EMAIL) {
      return { status: 403, body: { error: "Correo no disponible" } };
    }
    const [taken] = await db.select({ id: users.id }).from(users).where(eq(users.email, input.email)).limit(1);
    if (taken) {
      return { status: 409, body: { error: "No se pudo completar el registro. Revisa tus datos." } };
    }

    let affiliateId: string | null = null;
    let invitedByUserId: string | null = null;
    if (input.ref) {
      const [affiliate] = await db
        .select({ id: affiliates.id })
        .from(affiliates)
        .where(and(eq(affiliates.code, input.ref), eq(affiliates.active, true)))
        .limit(1);
      if (affiliate) {
        affiliateId = affiliate.id;
      } else {
        const [inviter] = await db
          .select({ id: users.id })
          .from(users)
          .where(eq(users.inviteCode, input.ref))
          .limit(1);
        invitedByUserId = inviter?.id ?? null;
      }
    }

    const [created] = await db
      .insert(users)
      .values({
        email: input.email,
        passwordHash: await hashPassword(input.password),
        name: input.name,
        age: input.age,
        inviteCode: generateInviteCode(),
        affiliateId,
        invitedByUserId,
      })
      .returning({ id: users.id });
    if (!created) return { status: 500, body: { error: "No se pudo crear la cuenta" } };

    await createSession(created.id);
    return { status: 201, body: { user: await loadPublicUser(created.id) } };
  });
  return Response.json(result.body, { status: result.status });
}

async function login(req: Request) {
  const parsed = await readJson(req, loginSchema);
  if (!parsed.ok) return parsed.response;
  const key = readIdempotencyKey(req);
  if (!key) return fail(400, "Falta la cabecera Idempotency-Key");
  const { email, password } = parsed.data;

  const ip = await clientIp();
  const ipKey = `login:ip:${ip}`;
  const emailKey = `login:email:${sha256Hex(email).slice(0, 32)}`;
  const wait = Math.max(await rateLimitCheck(ipKey), await rateLimitCheck(emailKey));
  if (wait > 0) {
    return fail(429, "Demasiados intentos. Espera antes de volver a intentarlo.", { retryAfter: wait });
  }

  const result = await withIdempotency("login", key, async () => {
    const [row] = await db
      .select({ id: users.id, passwordHash: users.passwordHash })
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    let valid = false;
    if (row) {
      valid = await verifyPassword(password, row.passwordHash);
    } else {
      await hashPassword(password);
    }

    if (!row || !valid) {
      const retry = Math.max(await rateLimitFail(ipKey), await rateLimitFail(emailKey));
      return { status: 401, body: { error: "Credenciales no validas.", retryAfter: retry } };
    }

    await rateLimitReset(emailKey);
    await createSession(row.id);
    return { status: 200, body: { user: await loadPublicUser(row.id) } };
  });
  return Response.json(result.body, { status: result.status });
}

async function promise(req: Request) {
  const user = await getSessionUser();
  if (!user) return fail(401, "Inicia sesion para continuar");
  const parsed = await readJson(req, promiseSchema);
  if (!parsed.ok) return parsed.response;
  if (user.promiseSignedAt) {
    return Response.json({ promiseSignedAt: user.promiseSignedAt, alreadySigned: true });
  }

  const signedAt = await withUser(user.id, async (tx) => {
    const clock = await dbClock(tx);
    const digest = sha256Hex(`${user.id}|${clock.now.toISOString()}|Me comprometo a no fallarme a mi mismo`);
    await tx
      .update(users)
      .set({ promiseSignedAt: clock.now, promiseHash: digest, updatedAt: clock.now })
      .where(eq(users.id, user.id));
    return clock.now.toISOString();
  });
  return Response.json({ promiseSignedAt: signedAt, alreadySigned: false });
}

async function profile(req: Request) {
  const user = await getSessionUser();
  if (!user) return fail(401, "Inicia sesion para continuar");
  const parsed = await readJson(req, profileSchema);
  if (!parsed.ok) return parsed.response;
  const input = parsed.data;
  if (input.theme !== "obsidian" && !user.unlockedThemes.includes(input.theme)) {
    return fail(403, "Tema bloqueado. Desbloquealo con una caja de suministros.");
  }

  await withUser(user.id, async (tx) => {
    const clock = await dbClock(tx);
    await tx
      .update(users)
      .set({
        goalKcal: input.goalKcal,
        goalProtein: input.goalProtein,
        dietPlan: input.dietPlan,
        theme: input.theme,
        updatedAt: clock.now,
      })
      .where(eq(users.id, user.id));
  });
  return Response.json({ user: await loadPublicUser(user.id) });
}
