import { readFileSync } from "node:fs";
import path from "node:path";
import { eq, sql } from "drizzle-orm";
import { db, pool } from "@/db";
import { users } from "@/db/schema";
import { OWNER_EMAIL } from "@/lib/shared/domain";
import { generateInviteCode, hashPassword, verifyPassword } from "./crypto";

export type DbTx = Parameters<Parameters<typeof db.transaction>[0]>[0];

type SecurityGlobal = typeof globalThis & { __kaloSecurityReady?: Promise<void> };
const securityGlobal = globalThis as SecurityGlobal;

async function seedOwner(): Promise<void> {
  const password = process.env.OWNER_PASSWORD?.trim();
  const [existing] = await db
    .select({ id: users.id, role: users.role, passwordHash: users.passwordHash })
    .from(users)
    .where(eq(users.email, OWNER_EMAIL))
    .limit(1);

  if (!existing) {
    if (!password) return;
    const [created] = await db
      .insert(users)
      .values({
        email: OWNER_EMAIL,
        passwordHash: await hashPassword(password),
        name: "Owner",
        age: 35,
        inviteCode: generateInviteCode(),
      })
      .returning({ id: users.id });
    if (created) {
      await db.update(users).set({ role: "owner" }).where(eq(users.id, created.id));
    }
    return;
  }

  const patch: { role?: string; passwordHash?: string } = {};
  if (existing.role !== "owner") patch.role = "owner";
  if (password && !(await verifyPassword(password, existing.passwordHash))) {
    patch.passwordHash = await hashPassword(password);
  }
  if (Object.keys(patch).length > 0) {
    await db.update(users).set(patch).where(eq(users.id, existing.id));
  }
}

export function ensureDbSecurity(): Promise<void> {
  if (!securityGlobal.__kaloSecurityReady) {
    securityGlobal.__kaloSecurityReady = (async () => {
      const script = readFileSync(path.join(process.cwd(), "sql", "security.sql"), "utf8");
      await pool.query(script);
      await seedOwner();
    })().catch((error: unknown) => {
      securityGlobal.__kaloSecurityReady = undefined;
      throw error;
    });
  }
  return securityGlobal.__kaloSecurityReady;
}

export async function withUser<T>(userId: string, run: (tx: DbTx) => Promise<T>): Promise<T> {
  await ensureDbSecurity();
  return db.transaction(async (tx) => {
    await tx.execute(sql`select set_config('app.user_id', ${userId}, true)`);
    await tx.execute(sql`set local role kalo_app`);
    return run(tx);
  });
}

export async function dbClock(runner: Pick<typeof db, "execute">): Promise<{ now: Date; today: string }> {
  const result = await runner.execute<{ now: Date; today: string }>(
    sql`select now() as now, to_char(now() at time zone 'UTC', 'YYYY-MM-DD') as today`,
  );
  const row = result.rows[0];
  return { now: new Date(row.now), today: row.today };
}
