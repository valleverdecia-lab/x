"use client";

import { type KeyboardEvent as ReactKeyboardEvent, type PointerEvent as ReactPointerEvent, useEffect, useRef, useState } from "react";
import { play } from "@/lib/client/audio";
import { type ApiResult, api, newKey } from "@/lib/client/hooks";
import type { PublicUser } from "@/lib/shared/domain";
import { loginSchema, registerSchema } from "@/lib/shared/schemas";
import { Field, Glass, Icon, Modal, MutexButton } from "./ui";

const HOLD_MS = 3000;
const PLAN_PRESETS = [
  { id: "equilibrio", label: "Equilibrio latino", detail: "Arroz, frijoles y viandas con medida", kcal: 2000, protein: 120 },
  { id: "definicion", label: "Definicion", detail: "Deficit moderado con alta proteina", kcal: 1650, protein: 150 },
  { id: "masa", label: "Masa muscular", detail: "Superavit controlado para ganancia magra", kcal: 2800, protein: 170 },
  { id: "salud-latina", label: "Salud latina", detail: "Menos fritura, mas vegetales y pescado", kcal: 2100, protein: 110 },
] as const;

type PresetId = (typeof PLAN_PRESETS)[number]["id"];

export function AuthScreen({
  refCode,
  onAuthed,
  onOpenLegal,
}: {
  refCode: string;
  onAuthed: () => Promise<void> | void;
  onOpenLegal: () => void;
}) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [accepted, setAccepted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const id = window.setTimeout(() => setCooldown((value) => value - 1), 1000);
    return () => window.clearTimeout(id);
  }, [cooldown]);

  const fail = (result: ApiResult<unknown>) => {
    if (result.ok) return;
    setError(result.error);
    if (result.retryAfter && result.retryAfter > 0) setCooldown(result.retryAfter);
  };

  const submit = async () => {
    setError(null);
    if (cooldown > 0) return;
    const idempotencyKey = newKey();

    if (mode === "register") {
      const candidate = {
        email: email.trim().toLowerCase(),
        password,
        name: name.trim(),
        age: Number(age),
        ref: refCode || undefined,
        acceptedLegal: accepted,
      };
      const checked = registerSchema.safeParse(candidate);
      if (!checked.success) {
        setError(checked.error.issues[0]?.message ?? "Revisa los datos del formulario.");
        return;
      }
      const result = await api<{ user: PublicUser | null }>("/api/auth/register", {
        body: candidate,
        idempotencyKey,
      });
      if (!result.ok) return fail(result);
      play("success");
      await onAuthed();
      return;
    }

    const candidate = { email: email.trim().toLowerCase(), password };
    const checked = loginSchema.safeParse(candidate);
    if (!checked.success) {
      setError("Ingresa tu correo y contrasena.");
      return;
    }
    const result = await api<{ user: PublicUser | null }>("/api/auth/login", { body: candidate, idempotencyKey });
    if (!result.ok) return fail(result);
    play("success");
    await onAuthed();
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center px-5 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <p className="kalo-gold-text text-xs font-semibold uppercase tracking-[0.36em]">KALO // AURA AI</p>
          <h1 className="mt-3 text-2xl font-semibold tracking-tight">Nutricion biometrica para la mesa latina y global</h1>
        </div>
        <Glass className="p-6">
          <div role="tablist" className="mb-6 grid grid-cols-2 gap-1 rounded-2xl bg-white/[0.04] p-1">
            {(["login", "register"] as const).map((option) => (
              <button
                key={option}
                type="button"
                role="tab"
                aria-selected={mode === option}
                onClick={() => {
                  setMode(option);
                  setError(null);
                }}
                className={`min-h-[40px] rounded-xl text-sm font-medium transition-colors ${mode === option ? "bg-white/[0.08] text-[color:var(--kalo-gold)]" : "text-[color:var(--kalo-muted)]"}`}
              >
                {option === "login" ? "Iniciar sesion" : "Crear cuenta"}
              </button>
            ))}
          </div>

          <form className="space-y-4" onSubmit={(event) => event.preventDefault()} noValidate>
            <Field
              label="Correo"
              type="email"
              autoComplete="email"
              inputMode="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
            <Field
              label="Contrasena"
              type="password"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              hint={mode === "register" ? "Minimo 10 caracteres con letras y numeros" : undefined}
            />
            {mode === "register" ? (
              <>
                <Field
                  label="Nombre"
                  maxLength={24}
                  autoComplete="given-name"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  hint="Maximo 24 caracteres"
                />
                <Field
                  label="Edad"
                  inputMode="numeric"
                  maxLength={2}
                  value={age}
                  onChange={(event) => setAge(event.target.value.replace(/[^0-9]/g, ""))}
                  hint="Entre 13 y 99 anos"
                />
                <label className="flex items-start gap-3 text-xs leading-relaxed text-[color:var(--kalo-muted)]">
                  <input
                    type="checkbox"
                    checked={accepted}
                    onChange={(event) => setAccepted(event.target.checked)}
                    className="mt-0.5 h-4 w-4 accent-[#E5C158]"
                  />
                  <span>
                    Acepto la{" "}
                    <button type="button" onClick={onOpenLegal} className="text-[color:var(--kalo-gold)] underline underline-offset-2">
                      Politica de privacidad
                    </button>
                    , el descargo medico y la clausula de arbitraje.
                  </span>
                </label>
              </>
            ) : null}

            {error ? (
              <p role="alert" className="text-sm text-[color:var(--kalo-danger)]">
                {error}
                {cooldown > 0 ? ` Reintenta en ${cooldown} s.` : ""}
              </p>
            ) : null}

            <MutexButton className="w-full" onPress={submit} busyLabel="Verificando" ready={cooldown === 0}>
              {mode === "login" ? "Entrar" : "Crear cuenta"}
            </MutexButton>
          </form>

          {refCode ? (
            <p className="kalo-ellipsis mt-5 text-center text-[11px] text-[color:var(--kalo-muted)]">Invitacion activa: {refCode}</p>
          ) : null}
        </Glass>
      </div>
    </div>
  );
}

export function Onboarding({ user, onDone }: { user: PublicUser; onDone: () => Promise<void> | void }) {
  const [step, setStep] = useState<"plan" | "promise">("plan");
  const [preset, setPreset] = useState<PresetId>("equilibrio");
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [signing, setSigning] = useState(false);
  const holdStart = useRef<number | null>(null);
  const frame = useRef<number | null>(null);
  const signed = useRef(false);

  const savePlan = async () => {
    setError(null);
    const choice = PLAN_PRESETS.find((item) => item.id === preset) ?? PLAN_PRESETS[0];
    const result = await api("/api/auth/profile", {
      body: { goalKcal: choice.kcal, goalProtein: choice.protein, dietPlan: choice.id, theme: "obsidian" },
    });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    play("menu");
    setStep("promise");
  };

  const finish = async () => {
    holdStart.current = null;
    signed.current = true;
    setSigning(true);
    setProgress(1);
    const result = await api("/api/auth/promise", {
      body: { confirmed: true, holdMs: HOLD_MS },
      idempotencyKey: newKey(),
    });
    if (!result.ok) {
      signed.current = false;
      setSigning(false);
      setProgress(0);
      setError(result.error);
      return;
    }
    play("levelup");
    await onDone();
  };

  const tick = () => {
    if (holdStart.current === null) return;
    const ratio = Math.min(1, (performance.now() - holdStart.current) / HOLD_MS);
    setProgress(ratio);
    if (ratio >= 1) {
      void finish();
      return;
    }
    frame.current = window.requestAnimationFrame(tick);
  };

  const press = () => {
    if (signed.current || signing) return;
    holdStart.current = performance.now();
    play("scan");
    frame.current = window.requestAnimationFrame(tick);
  };

  const release = () => {
    if (holdStart.current === null || signed.current) return;
    holdStart.current = null;
    if (frame.current !== null) window.cancelAnimationFrame(frame.current);
    setProgress(0);
  };

  useEffect(() => {
    return () => {
      if (frame.current !== null) window.cancelAnimationFrame(frame.current);
    };
  }, []);

  const onPointerDown = (event: ReactPointerEvent<HTMLButtonElement>) => {
    event.preventDefault();
    press();
  };

  const onKeyDown = (event: ReactKeyboardEvent<HTMLButtonElement>) => {
    if ((event.key === " " || event.key === "Enter") && !event.repeat) press();
  };

  const onKeyUp = (event: ReactKeyboardEvent<HTMLButtonElement>) => {
    if (event.key === " " || event.key === "Enter") release();
  };

  const circumference = 2 * Math.PI * 58;

  return (
    <div className="mx-auto flex min-h-[100dvh] w-full max-w-[520px] flex-col justify-center px-5 py-10">
      <p className="kalo-gold-text text-xs font-semibold uppercase tracking-[0.3em]">Bienvenido, {user.name}</p>
      {step === "plan" ? (
        <div className="kalo-fade-in mt-4 space-y-5">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Diseña tu plan</h1>
            <p className="mt-2 text-sm leading-relaxed text-[color:var(--kalo-muted)]">
              Elige la estrategia que mejor encaja con tu rutina. Tu Bio-Pou y tus metas diarias se ajustan a esta eleccion.
            </p>
          </div>
          <div className="grid gap-3" role="radiogroup" aria-label="Plan nutricional">
            {PLAN_PRESETS.map((item) => {
              const active = preset === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => {
                    setPreset(item.id);
                    play("click");
                  }}
                  className={`kalo-glass flex items-center justify-between gap-4 p-4 text-left transition-colors ${active ? "border-[rgba(229,193,88,0.55)]" : ""}`}
                >
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold">{item.label}</span>
                    <span className="kalo-ellipsis mt-1 block text-xs text-[color:var(--kalo-muted)]">{item.detail}</span>
                  </span>
                  <span className="shrink-0 text-right text-xs text-[color:var(--kalo-muted)]">
                    <span className="block font-semibold text-[color:var(--kalo-titanium)]">{item.kcal} kcal</span>
                    {item.protein} g proteina
                  </span>
                </button>
              );
            })}
          </div>
          {error ? (
            <p role="alert" className="text-sm text-[color:var(--kalo-danger)]">
              {error}
            </p>
          ) : null}
          <MutexButton className="w-full" onPress={savePlan} busyLabel="Guardando">
            Continuar al contrato
          </MutexButton>
        </div>
      ) : (
        <div className="kalo-fade-in mt-4 space-y-6">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Contrato de compromiso</h1>
            <p className="mt-2 text-sm leading-relaxed text-[color:var(--kalo-muted)]">
              Manten presionada la huella durante tres segundos para firmar. La fecha y la hora de la firma quedan registradas con la hora del servidor.
            </p>
          </div>
          <Glass className="p-6 text-center">
            <p className="text-lg font-semibold leading-snug">&ldquo;Me comprometo a no fallarme a mi mismo&rdquo;</p>
            <div className="relative mx-auto mt-6 flex h-[150px] w-[150px] items-center justify-center">
              <svg width="150" height="150" viewBox="0 0 150 150" className="absolute inset-0 -rotate-90" aria-hidden="true">
                <circle cx="75" cy="75" r="58" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="3" />
                <circle
                  cx="75"
                  cy="75"
                  r="58"
                  fill="none"
                  stroke="#E5C158"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={circumference * (1 - progress)}
                  style={{ filter: "drop-shadow(0 0 6px rgba(229,193,88,0.7))" }}
                />
              </svg>
              <button
                type="button"
                disabled={signing || signed.current}
                onPointerDown={onPointerDown}
                onPointerUp={release}
                onPointerLeave={release}
                onPointerCancel={release}
                onKeyDown={onKeyDown}
                onKeyUp={onKeyUp}
                onContextMenu={(event) => event.preventDefault()}
                className="flex h-[112px] w-[112px] select-none items-center justify-center rounded-full border border-[rgba(229,193,88,0.35)] bg-[rgba(229,193,88,0.05)] text-[color:var(--kalo-gold)] touch-none"
                aria-label="Mantener presionado para firmar el compromiso durante tres segundos"
              >
                <Icon name="fingerprint" size={56} />
              </button>
            </div>
            <p className="mt-5 text-[11px] uppercase tracking-[0.2em] text-[color:var(--kalo-muted)]">
              {signing ? "Firmando" : progress > 0 ? "Manten presionado" : "Pendiente de firma"}
            </p>
          </Glass>
          {error ? (
            <p role="alert" className="text-sm text-[color:var(--kalo-danger)]">
              {error}
            </p>
          ) : null}
        </div>
      )}
    </div>
  );
}

const LEGAL_SECTIONS = {
  privacidad: {
    title: "Privacidad y tratamiento de datos",
    body: [
      "KALO trata datos biometricos aproximados (peso, porcentaje de grasa estimado, simetria) solo para ofrecer el servicio que solicitas. No vendemos ni cedemos datos personales a terceros con fines publicitarios.",
      "Las fotografias de comida y de fisico se comprimen en tu dispositivo, se transmiten cifradas con TLS 1.3 y se procesan en memoria para obtener la estimacion. La imagen no se conserva de forma permanente. Solo se guardan los resultados numericos y el texto del analisis.",
      "Puedes solicitar la eliminacion de tu cuenta y de tus datos asociados en cualquier momento desde el soporte. Los registros de pago se conservan el tiempo que exige la normativa fiscal aplicable.",
      "El acceso a los datos esta protegido con aislamiento por fila en PostgreSQL: cada usuario solo puede leer y modificar sus propios registros, y los campos de rol y suscripcion no pueden ser modificados desde el cliente.",
    ],
  },
  medico: {
    title: "Descargo de responsabilidad medica",
    body: [
      "Las estimaciones de calorias, macronutrientes, indice de inflamacion, porcentaje de grasa corporal y simetria son informativas y se generan mediante modelos de inteligencia artificial que pueden equivocarse.",
      "KALO no sustituye el consejo, diagnostico ni tratamiento de un profesional de la salud. Consulta a tu medico antes de iniciar dietas, suplementos o programas de entrenamiento, sobre todo si tienes condiciones preexistentes, estas embarazada o tomas medicacion.",
      "Ante sintomas de malestar, mareo, dolor en el pecho o cualquier emergencia, busca atencion medica inmediata.",
    ],
  },
  arbitraje: {
    title: "Clausula de arbitraje y sorteos",
    body: [
      "Cualquier disputa comercial derivada del uso de KALO, incluidas las relativas a suscripciones, pagos, cancelaciones y promociones, se resolvera mediante arbitraje individual conforme a las reglas del arbitraje internacional aplicable, con renuncia expresa a acciones colectivas.",
      "Los sorteos, premios mensuales y recompensas variables son promociones de caracter gratuito, sin obligacion de compra. Los resultados se verifican con la hora del servidor y el creador puede descalificar cuentas que incumplan estas condiciones o que empleen invitaciones falsas.",
      "El creador no sera responsable de danos indirectos, lucro cesante o perdida de datos derivados del uso del servicio, en la medida maxima permitida por la ley.",
    ],
  },
} as const;

type LegalKey = keyof typeof LEGAL_SECTIONS;

export function LegalModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [tab, setTab] = useState<LegalKey>("privacidad");
  const section = LEGAL_SECTIONS[tab];
  return (
    <Modal open={open} onClose={onClose} title="Legal y privacidad">
      <div className="mb-4 grid grid-cols-3 gap-1 rounded-2xl bg-white/[0.04] p-1" role="tablist">
        {(Object.keys(LEGAL_SECTIONS) as LegalKey[]).map((key) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={tab === key}
            onClick={() => setTab(key)}
            className={`min-h-[36px] rounded-xl px-1 text-[11px] font-medium capitalize ${tab === key ? "bg-white/[0.08] text-[color:var(--kalo-gold)]" : "text-[color:var(--kalo-muted)]"}`}
          >
            {key}
          </button>
        ))}
      </div>
      <h3 className="mb-3 text-sm font-semibold">{section.title}</h3>
      <div className="space-y-3 text-sm leading-relaxed text-[color:var(--kalo-muted)]">
        {section.body.map((paragraph) => (
          <p key={paragraph.slice(0, 40)}>{paragraph}</p>
        ))}
      </div>
    </Modal>
  );
}
