import { sql } from "drizzle-orm";
import {
  type AnyPgColumn,
  boolean,
  check,
  date,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

const timestamptz = (name: string) => timestamp(name, { withTimezone: true, mode: "date" });
const createdAt = () => timestamptz("created_at").notNull().defaultNow();

export const guilds = pgTable(
  "guilds",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: varchar("name", { length: 24 }).notNull().unique(),
    motto: varchar("motto", { length: 80 }).notNull().default(""),
    emblem: varchar("emblem", { length: 16 }).notNull().default("hex"),
    createdByUserId: uuid("created_by_user_id").references((): AnyPgColumn => users.id, {
      onDelete: "set null",
    }),
    createdAt: createdAt(),
  },
  (t) => [check("guilds_name_length", sql`char_length(name) between 3 and 24`)],
);

export const affiliates = pgTable(
  "affiliates",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    code: varchar("code", { length: 32 }).notNull().unique(),
    label: varchar("label", { length: 80 }).notNull(),
    commissionPct: integer("commission_pct").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: createdAt(),
  },
  (t) => [check("affiliates_commission_range", sql`commission_pct between 0 and 100`)],
);

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: varchar("email", { length: 254 }).notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    name: varchar("name", { length: 24 }).notNull(),
    age: integer("age").notNull(),
    role: varchar("role", { length: 16 }).notNull().default("user"),
    isVip: boolean("is_vip").notNull().default(false),
    vipTier: varchar("vip_tier", { length: 16 }).notNull().default("none"),
    vipUntil: timestamptz("vip_until"),
    vipPermanent: boolean("vip_permanent").notNull().default(false),
    inviteCode: varchar("invite_code", { length: 16 }).notNull().unique(),
    invitedByUserId: uuid("invited_by_user_id").references((): AnyPgColumn => users.id, {
      onDelete: "set null",
    }),
    affiliateId: uuid("affiliate_id").references(() => affiliates.id, { onDelete: "set null" }),
    xp: integer("xp").notNull().default(0),
    streakDays: integer("streak_days").notNull().default(0),
    streakLastDay: date("streak_last_day", { mode: "string" }),
    goalKcal: integer("goal_kcal").notNull().default(2000),
    goalProtein: integer("goal_protein").notNull().default(120),
    dietPlan: varchar("diet_plan", { length: 24 }).notNull().default("equilibrio"),
    theme: varchar("theme", { length: 24 }).notNull().default("obsidian"),
    unlockedThemes: jsonb("unlocked_themes").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    promiseSignedAt: timestamptz("promise_signed_at"),
    promiseHash: varchar("promise_hash", { length: 64 }),
    flashOfferUntil: timestamptz("flash_offer_until"),
    lastActivityAt: timestamptz("last_activity_at").notNull().defaultNow(),
    lastSeenAt: timestamptz("last_seen_at").notNull().defaultNow(),
    createdAt: createdAt(),
    updatedAt: timestamptz("updated_at").notNull().defaultNow(),
  },
  (t) => [
    check("users_role_valid", sql`role in ('user', 'owner')`),
    check("users_owner_email_locked", sql`role <> 'owner' or email = 'valleverdecia@gmail.com'`),
    check("users_vip_tier_valid", sql`vip_tier in ('none', 'basic', 'god')`),
    check("users_age_range", sql`age between 13 and 99`),
    check("users_name_length", sql`char_length(name) between 1 and 24`),
    check("users_counters_positive", sql`xp >= 0 and streak_days >= 0`),
    index("users_affiliate_idx").on(t.affiliateId),
    index("users_invited_by_idx").on(t.invitedByUserId),
  ],
);

export const guildMembers = pgTable(
  "guild_members",
  {
    userId: uuid("user_id")
      .primaryKey()
      .references(() => users.id, { onDelete: "cascade" }),
    guildId: uuid("guild_id")
      .notNull()
      .references(() => guilds.id, { onDelete: "cascade" }),
    joinedAt: createdAt(),
  },
  (t) => [index("guild_members_guild_idx").on(t.guildId)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: varchar("token_hash", { length: 64 }).notNull().unique(),
    expiresAt: timestamptz("expires_at").notNull(),
    ip: varchar("ip", { length: 64 }).notNull().default(""),
    userAgent: varchar("user_agent", { length: 200 }).notNull().default(""),
    createdAt: createdAt(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const meals = pgTable(
  "meals",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    clientId: uuid("client_id").unique(),
    catalogId: varchar("catalog_id", { length: 48 }),
    name: varchar("name", { length: 80 }).notNull(),
    source: varchar("source", { length: 16 }).notNull(),
    grams: integer("grams").notNull().default(0),
    kcal: integer("kcal").notNull(),
    proteinG: integer("protein_g").notNull(),
    carbsG: integer("carbs_g").notNull(),
    fatG: integer("fat_g").notNull(),
    inflammationIndex: integer("inflammation_index").notNull(),
    purityScore: integer("purity_score").notNull(),
    disciplinePoints: integer("discipline_points").notNull(),
    verifiedAi: boolean("verified_ai").notNull().default(false),
    offlineQueued: boolean("offline_queued").notNull().default(false),
    mealAt: timestamptz("meal_at").notNull().defaultNow(),
    createdAt: createdAt(),
  },
  (t) => [
    index("meals_user_time_idx").on(t.userId, t.mealAt),
    check(
      "meals_ranges",
      sql`kcal between 0 and 6000 and grams between 0 and 3000 and purity_score between 0 and 100 and inflammation_index between 0 and 100 and discipline_points between 0 and 10`,
    ),
  ],
);

export const bodyScans = pgTable(
  "body_scans",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    bodyFatPct: integer("body_fat_pct").notNull(),
    symmetryScore: integer("symmetry_score").notNull(),
    auraPoints: integer("aura_points").notNull(),
    verdict: varchar("verdict", { length: 200 }).notNull(),
    createdAt: createdAt(),
  },
  (t) => [index("body_scans_user_idx").on(t.userId)],
);

export const posts = pgTable(
  "posts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    mealId: uuid("meal_id").references(() => meals.id, { onDelete: "set null" }),
    title: varchar("title", { length: 80 }).notNull(),
    kcal: integer("kcal").notNull(),
    purityScore: integer("purity_score").notNull(),
    verifiedAi: boolean("verified_ai").notNull().default(false),
    createdAt: createdAt(),
  },
  (t) => [index("posts_created_idx").on(t.createdAt), index("posts_user_idx").on(t.userId)],
);

export const affiliateClicks = pgTable(
  "affiliate_clicks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    affiliateId: uuid("affiliate_id")
      .notNull()
      .references(() => affiliates.id, { onDelete: "cascade" }),
    visitorHash: varchar("visitor_hash", { length: 64 }).notNull(),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("affiliate_clicks_unique_visitor").on(t.affiliateId, t.visitorHash)],
);

export const purchases = pgTable(
  "purchases",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    planId: varchar("plan_id", { length: 32 }).notNull(),
    amountCents: integer("amount_cents").notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("USD"),
    paymentMethod: varchar("payment_method", { length: 24 }).notNull(),
    status: varchar("status", { length: 16 }).notNull().default("pending"),
    reference: varchar("reference", { length: 24 }).notNull().unique(),
    idempotencyKey: varchar("idempotency_key", { length: 80 }).notNull(),
    affiliateId: uuid("affiliate_id").references(() => affiliates.id, { onDelete: "set null" }),
    flashOffer: boolean("flash_offer").notNull().default(false),
    providerRef: varchar("provider_ref", { length: 128 }),
    paidAt: timestamptz("paid_at"),
    createdAt: createdAt(),
  },
  (t) => [
    uniqueIndex("purchases_user_idempotency_uidx").on(t.userId, t.idempotencyKey),
    index("purchases_status_idx").on(t.status),
    index("purchases_affiliate_idx").on(t.affiliateId),
    check("purchases_amount_positive", sql`amount_cents > 0`),
    check("purchases_status_valid", sql`status in ('pending', 'paid', 'failed')`),
  ],
);

export const rateLimits = pgTable("rate_limits", {
  key: varchar("key", { length: 190 }).primaryKey(),
  attempts: integer("attempts").notNull().default(0),
  windowStartedAt: timestamptz("window_started_at").notNull().defaultNow(),
  strikes: integer("strikes").notNull().default(0),
  blockedUntil: timestamptz("blocked_until"),
  updatedAt: timestamptz("updated_at").notNull().defaultNow(),
});

export const idempotencyKeys = pgTable(
  "idempotency_keys",
  {
    scope: varchar("scope", { length: 64 }).notNull(),
    key: varchar("key", { length: 80 }).notNull(),
    responseStatus: integer("response_status"),
    responseBody: jsonb("response_body").$type<Record<string, unknown>>(),
    createdAt: createdAt(),
  },
  (t) => [primaryKey({ columns: [t.scope, t.key] })],
);

export const rewardRolls = pgTable(
  "reward_rolls",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    sourceKind: varchar("source_kind", { length: 16 }).notNull(),
    sourceRef: varchar("source_ref", { length: 80 }).notNull(),
    rewardType: varchar("reward_type", { length: 16 }),
    rewardValue: varchar("reward_value", { length: 40 }),
    openedAt: timestamptz("opened_at"),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("reward_rolls_user_ref_uidx").on(t.userId, t.sourceRef)],
);

export const globalSettings = pgTable("global_settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: jsonb("value").$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamptz("updated_at").notNull().defaultNow(),
});

export const paywallEvents = pgTable(
  "paywall_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    event: varchar("event", { length: 16 }).notNull(),
    createdAt: createdAt(),
  },
  (t) => [index("paywall_events_user_idx").on(t.userId)],
);
