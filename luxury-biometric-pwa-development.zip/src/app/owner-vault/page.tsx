import type { Metadata } from "next";
import { notFound } from "next/navigation";
import OwnerVault from "@/components/owner/OwnerVault";
import { getSessionUser, isOwner } from "@/lib/server/security";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  robots: { index: false, follow: false, nocache: true },
};

export default async function OwnerVaultPage() {
  const viewer = await getSessionUser();
  if (!isOwner(viewer)) notFound();
  return <OwnerVault />;
}
