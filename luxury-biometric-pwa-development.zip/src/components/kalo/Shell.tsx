"use client";

import { type ReactNode, useCallback, useEffect, useState } from "react";
import { play, setSoundOn, isSoundOn } from "@/lib/client/audio";
import { api, useHydrated, useMutexAction, useTabLock } from "@/lib/client/hooks";
import { cacheGet, cacheSet, queueList, queueRemove } from "@/lib/client/offline";
import { energyFromIdle, type PublicUser } from "@/lib/shared/domain";
import { AuthScreen, LegalModal, Onboarding } from "./AuthOnboarding";
import { Community } from "./Community";
import { Dashboard } from "./Dashboard";
import { Paywall } from "./Paywall";
import { Scanners } from "./Scanners";
import { Glass, Icon, type IconName, MutexButton, Skeleton } from "./ui";

type View = "hoy" | "escanear" | "comunidad" | "vip";

interface Session {
  status: "loading" | "anon" | "authed";
  user: PublicUser | null;
  energy: number;
}

interface MeResponse {
  user: PublicUser | null;
  energy?: number;
}

interface RaffleSnapshot {
  prize: string;
  top: Array<{ rank: number; name: string; verified: number; isMe: boolean }>;
  mine: { verified: number };
}

const NAV: Array<{ id: View; label: string; icon: IconName }> = [
  { id: "hoy", label: "Hoy", icon: "home" },
  { id: "escanear", label: "Escanear", icon: "scan" },
  { id: "comunidad", label: "Comunidad", icon: "users" },
  { id: "vip", label: "VIP", icon: "crown" },
];

const VIEWS: View[] = ["hoy", "escanear", "comunidad", "vip"];

function BootSkeleton() {
  return (
    <div className="mx-auto flex min-h-[100dvh] w-full max-w-[520px] flex-col gap-4 p-5" aria-busy="true" aria-label="Cargando KALO">
      <Skeleton className="h-10 w-44" />
      <Skeleton className="h-64 w-full" />
      <Skeleton className="h-24 w-full" />
      <Skeleton className="h-24 w-full" />
    </div>
  );
}

function TabLockOverlay({ onTakeOver }: { onTakeOver: () => void }) {
  return (
    <div className="fixed inset-0 z-[9500] flex items-center justify-center bg-[#070709] p-6">
      <Glass className="kalo-fade-in w-full max-w-sm p-7 text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-[rgba(229,193,88,0.3)] text-[color:var(--kalo-gold)]">
          <Icon name="shield" size={26} />
        </span>
        <h1 className="mt-5 text-lg font-semibold">Sesion activa en otra pestana</h1>
        <p className="mt-2 text-sm leading-relaxed text-[color:var(--kalo-muted)]">
          KALO opera en una sola pestana a la vez para proteger tu racha, tu Bio-Pou y tus puntos. Cierra la otra pestana o toma el control aqui.
        </p>
        <MutexButton className="mt-6 w-full" onPress={onTakeOver}>
          Usar esta pestana
        </MutexButton>
      </Glass>
    </div>
  );
}

function RaffleTicker({ enabled }: { enabled: boolean }) {
  const [data, setData] = useState<RaffleSnapshot | null>(null);

  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    const load = async () => {
      const result = await api<RaffleSnapshot>("/api/social/raffle");
      if (alive && result.ok) setData(result.data);
    };
    void load();
    const id = window.setInterval(load, 60_000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, [enabled]);

  if (!data) return null;
  const leader = data.top[0];
  return (
    <div className="mx-4 mb-3 flex items-center gap-3 rounded-2xl border border-[rgba(229,193,88,0.22)] bg-[rgba(229,193,88,0.06)] px-3 py-2.5">
      <span className="shrink-0 text-[color:var(--kalo-gold)]">
        <Icon name="trophy" size={18} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="kalo-ellipsis text-[10px] uppercase tracking-[0.16em] text-[color:var(--kalo-gold)]">{data.prize}</p>
        <p className="kalo-ellipsis text-xs text-[color:var(--kalo-titanium)]">
          {leader ? `Lider: ${leader.name} con ${leader.verified} verificadas` : "Aun sin invitaciones verificadas"} · Tus invitaciones: {data.mine.verified}
        </p>
      </div>
    </div>
  );
}

export default function KaloShell() {
  const hydrated = useHydrated();
  const tabLock = useTabLock();
  const [session, setSession] = useState<Session>({ status: "loading", user: null, energy: 0 });
  const [view, setView] = useState<View>("hoy");
  const [refCode, setRefCode] = useState("");
  const [soundOn, setSoundState] = useState(true);
  const [legalOpen, setLegalOpen] = useState(false);
  const [online, setOnline] = useState(true);
  const [pendingCount, setPendingCount] = useState(0);

  const refreshMe = useCallback(async () => {
    const result = await api<MeResponse>("/api/auth/me");
    if (result.ok) {
      if (result.data.user) {
        setSession({ status: "authed", user: result.data.user, energy: result.data.energy ?? 0 });
        void cacheSet("me", result.data.user).catch(() => undefined);
      } else {
        setSession({ status: "anon", user: null, energy: 0 });
      }
      return;
    }
    const cached = await cacheGet<PublicUser>("me").catch(() => null);
    if (cached && result.status === 0) {
      const idle = (Date.now() - Date.parse(cached.lastActivityAt)) / 3_600_000;
      setSession({ status: "authed", user: cached, energy: energyFromIdle(idle) });
      return;
    }
    setSession({ status: "anon", user: null, energy: 0 });
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const params = new URLSearchParams(window.location.search);
    const incomingRef = (params.get("ref") ?? window.localStorage.getItem("kalo_ref") ?? "").trim().toLowerCase();
    if (/^[a-z0-9_-]{3,32}$/.test(incomingRef)) {
      window.localStorage.setItem("kalo_ref", incomingRef);
      setRefCode(incomingRef);
      void api("/api/referral", { body: { code: incomingRef } });
    }
    const tab = params.get("tab");
    if (tab && (VIEWS as string[]).includes(tab)) setView(tab as View);
    setSoundState(isSoundOn());
    setOnline(navigator.onLine);
    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
    try {
      const orientation = screen.orientation as ScreenOrientation & {
        lock?: (value: "portrait-primary") => Promise<void>;
      };
      void orientation.lock?.("portrait-primary")?.catch(() => undefined);
    } catch {
      // Orientation lock is unsupported in most browsers; the CSS guard still applies.
    }
    void refreshMe();
  }, [hydrated, refreshMe]);

  const syncQueue = useCallback(async () => {
    let items: Awaited<ReturnType<typeof queueList>> = [];
    try {
      items = await queueList();
    } catch {
      setPendingCount(0);
      return;
    }
    setPendingCount(items.length);
    if (items.length === 0 || !navigator.onLine) return;

    const batch = items.slice(0, 50);
    const result = await api<{ results: Array<{ clientId: string; status: string }> }>("/api/meals/sync", {
      body: {
        items: batch.map((item) => ({ clientId: item.clientId, catalogId: item.catalogId, grams: item.grams })),
      },
    });
    if (!result.ok) return;
    for (const entry of result.data.results) {
      if (entry.status === "synced" || entry.status === "duplicate" || entry.status === "rejected") {
        await queueRemove(entry.clientId).catch(() => undefined);
      }
    }
    const remaining = await queueList().catch(() => []);
    setPendingCount(remaining.length);
    if (result.data.results.some((entry) => entry.status === "synced")) {
      void refreshMe();
    }
  }, [refreshMe]);

  useEffect(() => {
    if (session.status !== "authed") return;
    const handleOnline = () => {
      setOnline(true);
      void syncQueue();
    };
    const handleOffline = () => setOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    void syncQueue();
    const id = window.setInterval(() => void syncQueue(), 20_000);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      window.clearInterval(id);
    };
  }, [session.status, syncQueue]);

  const logout = useMutexAction(async () => {
    await api("/api/auth/logout", { method: "POST", body: {} });
    await cacheSet("me", null).catch(() => undefined);
    setSession({ status: "anon", user: null, energy: 0 });
    setView("hoy");
  });

  const navigate = (next: View) => {
    if (next === view) return;
    play("menu");
    setView(next);
  };

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    setSoundState(next);
    if (next) play("click");
  };

  const user = session.user;
  const showAuthed = session.status === "authed" && user !== null;

  let content: ReactNode;
  if (!hydrated || session.status === "loading") {
    content = <BootSkeleton />;
  } else if (tabLock.locked) {
    content = <TabLockOverlay onTakeOver={tabLock.takeOver} />;
  } else if (!showAuthed) {
    content = <AuthScreen refCode={refCode} onAuthed={refreshMe} onOpenLegal={() => setLegalOpen(true)} />;
  } else if (!user.promiseSignedAt) {
    content = <Onboarding user={user} onDone={refreshMe} />;
  } else {
    content = (
      <div className="mx-auto flex min-h-[100dvh] w-full max-w-[520px] flex-col">
        <header className="sticky top-0 z-40 flex items-center justify-between gap-3 bg-[#070709]/80 px-4 pb-3 pt-[max(env(safe-area-inset-top),14px)] backdrop-blur-xl">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="h-2 w-2 shrink-0 rounded-full bg-[#00FF87] shadow-[0_0_10px_#00FF87]" aria-hidden="true" />
            <span className="kalo-gold-text kalo-ellipsis text-sm font-semibold tracking-[0.2em]">KALO // AURA AI</span>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {!online ? <span className="rounded-full border border-white/10 px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">Offline</span> : null}
            {pendingCount > 0 ? (
              <span className="rounded-full border border-[rgba(229,193,88,0.3)] px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-gold)]">
                Sync {pendingCount}
              </span>
            ) : null}
            <button
              type="button"
              onClick={toggleSound}
              className="kalo-btn kalo-btn-ghost kalo-btn-sm"
              aria-pressed={soundOn}
              aria-label={soundOn ? "Silenciar sonidos" : "Activar sonidos"}
            >
              <Icon name={soundOn ? "volume" : "volumeOff"} size={15} />
            </button>
            <MutexButton variant="ghost" className="kalo-btn-sm" onPress={() => logout.run()} aria-label="Cerrar sesion">
              <Icon name="logout" size={15} />
            </MutexButton>
          </div>
        </header>

        <RaffleTicker enabled />

        <main className="kalo-scroll flex-1 px-4 pb-36 pt-1">
          {view === "hoy" ? (
            <Dashboard user={user} energy={session.energy} onChanged={refreshMe} onGoScan={() => navigate("escanear")} />
          ) : null}
          {view === "escanear" ? (
            <Scanners user={user} onChanged={refreshMe} onGoVip={() => navigate("vip")} />
          ) : null}
          {view === "comunidad" ? <Community user={user} onChanged={refreshMe} /> : null}
          {view === "vip" ? <Paywall user={user} onChanged={refreshMe} /> : null}

          <div className="mt-10 flex justify-center">
            <button type="button" onClick={() => setLegalOpen(true)} className="text-[11px] uppercase tracking-[0.16em] text-[color:var(--kalo-muted)] underline-offset-4 hover:underline">
              Privacidad, descargo medico y arbitraje
            </button>
          </div>
        </main>

        <nav
          className="kalo-glass kalo-safe-bottom fixed bottom-3 left-1/2 z-40 flex w-[calc(100%-24px)] max-w-[496px] -translate-x-1/2 items-center justify-around px-2 pt-2"
          aria-label="Navegacion principal"
        >
          {NAV.map((item) => {
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigate(item.id)}
                aria-current={active ? "page" : undefined}
                className={`relative flex min-w-[64px] flex-col items-center gap-1 px-2 py-1.5 text-[10px] uppercase tracking-[0.14em] transition-colors ${active ? "kalo-tab-active" : "text-[color:var(--kalo-muted)]"}`}
              >
                <Icon name={item.icon} size={20} />
                <span>{item.label}</span>
                {active ? <span className="sr-only">Seleccionado</span> : null}
              </button>
            );
          })}
        </nav>
      </div>
    );
  }

  return (
    <>
      <div id="kalo-root" className="kalo-app-root">
        {content}
      </div>
      <LegalModal open={legalOpen} onClose={() => setLegalOpen(false)} />
      <div id="kalo-impact" className="kalo-impact" aria-hidden="true" />
      <div className="orientation-guard" role="alert" aria-live="assertive">
        <span className="kalo-phone text-[color:var(--kalo-gold)]">
          <Icon name="phone" size={44} />
        </span>
        <p className="text-base font-semibold">Gira tu telefono a posicion vertical</p>
        <p className="max-w-xs text-sm text-[color:var(--kalo-muted)]">
          KALO se usa en vertical para conservar las proporciones del escaner y del Bio-Pou.
        </p>
      </div>
    </>
  );
}
