import { z } from "zod";
import { DIET_PLANS, PLAN_IDS, THEMES } from "./domain";

const DISPOSABLE_DOMAIN_TOKENS = [
  "tempmail",
  "temp-mail",
  "10minutemail",
  "10minute",
  "guerrillamail",
  "mailinator",
  "yopmail",
  "trashmail",
  "throwaway",
  "getnada",
  "sharklasers",
  "dispostable",
  "maildrop",
  "fakeinbox",
  "tempinbox",
  "mintemail",
  "emailondeck",
  "mohmal",
  "burnermail",
  "discardmail",
  "spamgourmet",
  "moakt",
  "minuteinbox",
  "tempr.email",
];

export function isDisposableEmail(email: string): boolean {
  const domain = email.split("@")[1]?.toLowerCase() ?? "";
  return DISPOSABLE_DOMAIN_TOKENS.some((token) => domain.includes(token));
}

export const UUID_PATTERN = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
const NAME_PATTERN = /^[A-Za-z0-9\u00C0-\u024F][A-Za-z0-9\u00C0-\u024F ._-]*$/;
const SLUG_PATTERN = /^[a-z0-9_-]{3,32}$/;
const EMAIL_PATTERN = /^[^\s@<>"'`;\\]+@[^\s@<>"'`;\\]+\.[^\s@<>"'`;\\]{2,}$/;

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .max(254, "Correo demasiado largo")
  .regex(EMAIL_PATTERN, "Formato de correo no valido")
  .refine((value) => !isDisposableEmail(value), "No se permiten correos temporales o desechables");

export const passwordSchema = z
  .string()
  .min(10, "Minimo 10 caracteres")
  .max(128, "Maximo 128 caracteres")
  .regex(/[A-Za-z]/, "Incluye al menos una letra")
  .regex(/[0-9]/, "Incluye al menos un numero");

export const nameSchema = z
  .string()
  .trim()
  .min(1, "Escribe tu nombre")
  .max(24, "Maximo 24 caracteres")
  .regex(NAME_PATTERN, "Solo letras, numeros, espacio, punto, guion o guion bajo");

export const ageSchema = z
  .number()
  .int("La edad debe ser un numero entero")
  .min(13, "Edad minima 13 anos")
  .max(99, "Edad maxima 99 anos");

const refSchema = z.string().trim().toLowerCase().regex(SLUG_PATTERN, "Codigo no valido");

export const registerSchema = z
  .strictObject({
    email: emailSchema,
    password: passwordSchema,
    name: nameSchema,
    age: z.coerce.number().pipe(ageSchema),
    ref: z.union([refSchema, z.literal("")]).optional(),
    acceptedLegal: z.literal(true, "Debes aceptar los terminos y la privacidad"),
  })
  .transform((value) => ({ ...value, ref: value.ref ? value.ref : undefined }));

export const loginSchema = z.strictObject({
  email: z.string().trim().toLowerCase().max(254),
  password: z.string().min(1).max(128),
});

export const promiseSchema = z.strictObject({
  confirmed: z.literal(true),
  holdMs: z.coerce.number().int().min(2900).max(60000),
});

export const profileSchema = z.strictObject({
  goalKcal: z.coerce.number().int().min(1200).max(4500),
  goalProtein: z.coerce.number().int().min(40).max(300),
  dietPlan: z.enum(DIET_PLANS),
  theme: z.enum(THEMES),
});

const catalogIdSchema = z.string().regex(/^[a-z0-9-]{3,48}$/, "Alimento no valido");
const gramsSchema = z.coerce.number().int().min(10, "Minimo 10 g").max(2000, "Maximo 2000 g");

export const mealSchema = z.strictObject({
  catalogId: catalogIdSchema,
  grams: gramsSchema,
  clientId: z.string().regex(UUID_PATTERN).optional(),
});

export const mealSyncSchema = z.strictObject({
  items: z
    .array(
      z.strictObject({
        clientId: z.string().regex(UUID_PATTERN),
        catalogId: catalogIdSchema,
        grams: gramsSchema,
      }),
    )
    .min(1)
    .max(50),
});

export const postSchema = z.strictObject({
  mealId: z.string().regex(UUID_PATTERN),
});

export const guildCreateSchema = z.strictObject({
  name: z
    .string()
    .trim()
    .min(3, "Minimo 3 caracteres")
    .max(24, "Maximo 24 caracteres")
    .regex(NAME_PATTERN, "Nombre no valido"),
  motto: z.string().trim().max(80, "Maximo 80 caracteres").optional(),
});

export const guildJoinSchema = z.strictObject({
  guildId: z.string().regex(UUID_PATTERN),
});

export const checkoutSchema = z.strictObject({
  planId: z.enum(PLAN_IDS),
  method: z.enum(["card_usd", "transfermovil_cup"]),
});

export const rollOpenSchema = z.strictObject({
  rollId: z.string().regex(UUID_PATTERN),
});

export const shareSchema = z.strictObject({});

export const ownerVipSchema = z.strictObject({
  userId: z.string().regex(UUID_PATTERN),
  duration: z.enum(["7d", "30d", "1y", "permanent"]),
});

export const ownerAffiliateSchema = z.strictObject({
  code: z.string().trim().toLowerCase().regex(SLUG_PATTERN, "Codigo: 3 a 32 caracteres a-z, 0-9, _ o -"),
  label: z.string().trim().min(2).max(80),
  commissionPct: z.coerce.number().int().min(0).max(100),
});

export const ownerAffiliateToggleSchema = z.strictObject({
  id: z.string().regex(UUID_PATTERN),
  active: z.boolean(),
});

export const ownerFlashSchema = z.strictObject({
  enabled: z.boolean(),
});

export const ownerConfirmSchema = z.strictObject({
  reference: z.string().regex(/^KALO-[A-Z0-9]{8}$/),
});

export const referralSchema = z.strictObject({
  code: z.string().trim().toLowerCase().regex(SLUG_PATTERN),
});

export const webhookSchema = z.strictObject({
  reference: z.string().regex(/^KALO-[A-Z0-9]{8}$/),
  status: z.enum(["paid", "failed"]),
  providerRef: z.string().max(128).optional(),
});

export const ownerSearchSchema = z.string().trim().max(80).regex(/^[A-Za-z0-9@._ -]*$/);
