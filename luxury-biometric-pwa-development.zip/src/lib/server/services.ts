import { randomInt } from "node:crypto";
import { and, eq, isNull, sql } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { bodyScans, globalSettings, meals, purchases, rewardRolls, users } from "@/db/schema";
import {
  evolutionFor,
  type FoodItem,
  type MacroSet,
  type MealView,
  PLANS,
  type PlanId,
  type PublicUser,
  shiftDay,
  THEMES,
} from "@/lib/shared/domain";
import { dbClock, ensureDbSecurity, withUser } from "./db";

export class VisionError extends Error {
  readonly status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = "VisionError";
    this.status = status;
  }
}

export interface MealInput {
  name: string;
  source: "vision" | "catalog";
  catalogId: string | null;
  grams: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  inflammation: number;
  purity: number;
  verifiedAi: boolean;
}

export interface RecordResult {
  meal: MealView;
  duplicate: boolean;
  xpGain: number;
  levelUp: boolean;
  streakDays: number;
  goalReached: boolean;
  isFirstMeal: boolean;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, Math.round(value)));
}

export function toMealView(row: typeof meals.$inferSelect): MealView {
  return {
    id: row.id,
    name: row.name,
    source: row.source,
    catalogId: row.catalogId,
    grams: row.grams,
    kcal: row.kcal,
    protein: row.proteinG,
    carbs: row.carbsG,
    fat: row.fatG,
    inflammation: row.inflammationIndex,
    purity: row.purityScore,
    verifiedAi: row.verifiedAi,
    offlineQueued: row.offlineQueued,
    mealAt: row.mealAt.toISOString(),
  };
}

export function catalogMealInput(item: FoodItem, macros: MacroSet): MealInput {
  return {
    name: item.name,
    source: "catalog",
    catalogId: item.id,
    grams: macros.grams,
    kcal: macros.kcal,
    protein: macros.protein,
    carbs: macros.carbs,
    fat: macros.fat,
    inflammation: macros.inflammation,
    purity: macros.purity,
    verifiedAi: false,
  };
}

export async function recordMeal(
  user: PublicUser,
  input: MealInput,
  opts: { clientId?: string; offline?: boolean } = {},
): Promise<RecordResult> {
  const outcome = await withUser(user.id, async (tx) => {
    if (opts.clientId) {
      const [existing] = await tx.select().from(meals).where(eq(meals.clientId, opts.clientId)).limit(1);
      if (existing) return { duplicate: true as const, row: existing };
    }

    const clock = await dbClock(tx);
    const [allTime] = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(meals)
      .where(eq(meals.userId, user.id));
    const [todayBefore] = await tx
      .select({ total: sql<number>`coalesce(sum(${meals.kcal}), 0)::int` })
      .from(meals)
      .where(
        and(
          eq(meals.userId, user.id),
          sql`(${meals.mealAt} at time zone 'UTC')::date = ${clock.today}::date`,
        ),
      );

    const yesterday = shiftDay(clock.today, -1);
    let streakDays = user.streakDays;
    if (user.streakLastDay === clock.today) streakDays = Math.max(streakDays, 1);
    else if (user.streakLastDay === yesterday) streakDays = streakDays + 1;
    else streakDays = 1;

    const xpGain = Math.min(30, 10 + Math.round(input.purity / 5));
    const levelUp = evolutionFor(user.xp + xpGain).stage !== evolutionFor(user.xp).stage;

    const [row] = await tx
      .insert(meals)
      .values({
        userId: user.id,
        clientId: opts.clientId ?? null,
        catalogId: input.catalogId,
        name: input.name,
        source: input.source,
        grams: input.grams,
        kcal: input.kcal,
        proteinG: input.protein,
        carbsG: input.carbs,
        fatG: input.fat,
        inflammationIndex: input.inflammation,
        purityScore: input.purity,
        disciplinePoints: Math.round(input.purity / 10),
        verifiedAi: input.verifiedAi,
        offlineQueued: Boolean(opts.offline),
        mealAt: clock.now,
      })
      .returning();

    await tx
      .update(users)
      .set({
        xp: sql`${users.xp} + ${xpGain}`,
        streakDays,
        streakLastDay: clock.today,
        lastActivityAt: clock.now,
        updatedAt: clock.now,
      })
      .where(eq(users.id, user.id));

    const totalBefore = todayBefore.total;
    return {
      duplicate: false as const,
      row,
      xpGain,
      levelUp,
      streakDays,
      goalReached: totalBefore < user.goalKcal && totalBefore + input.kcal >= user.goalKcal,
      isFirstMeal: allTime.count === 0,
    };
  });

  if (outcome.duplicate) {
    return {
      meal: toMealView(outcome.row),
      duplicate: true,
      xpGain: 0,
      levelUp: false,
      streakDays: user.streakDays,
      goalReached: false,
      isFirstMeal: false,
    };
  }

  await db
    .insert(rewardRolls)
    .values({ userId: user.id, sourceKind: "meal", sourceRef: `meal:${outcome.row.id}` })
    .onConflictDoNothing();

  if (outcome.isFirstMeal && user.invitedByUserId) {
    await db
      .insert(rewardRolls)
      .values({ userId: user.invitedByUserId, sourceKind: "invite", sourceRef: `invite:${user.id}` })
      .onConflictDoNothing();
  }

  return {
    meal: toMealView(outcome.row),
    duplicate: false,
    xpGain: outcome.xpGain,
    levelUp: outcome.levelUp,
    streakDays: outcome.streakDays,
    goalReached: outcome.goalReached,
    isFirstMeal: outcome.isFirstMeal,
  };
}

const FOOD_SYSTEM_PROMPT =
  "Eres un nutricionista clinico y experto en gastronomia cubana, latinoamericana e internacional. " +
  "Analizas la fotografia de un plato y devuelves unicamente el JSON solicitado. " +
  "Identifica con precision platos complejos como arroz congri, picadillo, ropa vieja, viandas, tostones, batidos y carnes. " +
  "Estima las porciones visibles en gramos. inflammationIndex va de 0 a 100 (100 = frituras, azucar refinada, ultraprocesados). " +
  "purityScore va de 0 a 100 (100 = alimento integral y poco procesado). Si la imagen no contiene comida, responde isFood false con valores en cero. " +
  "Son estimaciones informativas y no sustituyen consejo medico.";

const BODY_SYSTEM_PROMPT =
  "Eres un analista de composicion corporal y estetica deportiva. " +
  "Analizas una foto de progreso fisico y devuelves unicamente el JSON solicitado. " +
  "Estima el porcentaje de grasa corporal visual (3 a 60), la simetria muscular (0 a 100) y un veredicto breve en espanol de maximo 160 caracteres. " +
  "Es una estimacion visual informativa, no un diagnostico medico. Si no hay una persona visible responde isHuman false.";

const FOOD_RESPONSE_SCHEMA = {
  type: "OBJECT",
  properties: {
    isFood: { type: "BOOLEAN" },
    name: { type: "STRING" },
    grams: { type: "INTEGER" },
    kcal: { type: "INTEGER" },
    proteinG: { type: "INTEGER" },
    carbsG: { type: "INTEGER" },
    fatG: { type: "INTEGER" },
    inflammationIndex: { type: "INTEGER" },
    purityScore: { type: "INTEGER" },
    confidence: { type: "NUMBER" },
  },
  required: [
    "isFood",
    "name",
    "grams",
    "kcal",
    "proteinG",
    "carbsG",
    "fatG",
    "inflammationIndex",
    "purityScore",
    "confidence",
  ],
};

const BODY_RESPONSE_SCHEMA = {
  type: "OBJECT",
  properties: {
    isHuman: { type: "BOOLEAN" },
    bodyFatPct: { type: "INTEGER" },
    symmetryScore: { type: "INTEGER" },
    verdict: { type: "STRING" },
    confidence: { type: "NUMBER" },
  },
  required: ["isHuman", "bodyFatPct", "symmetryScore", "verdict", "confidence"],
};

const foodResultSchema = z.object({
  isFood: z.boolean(),
  name: z.string().trim().min(1).max(80),
  grams: z.number(),
  kcal: z.number(),
  proteinG: z.number(),
  carbsG: z.number(),
  fatG: z.number(),
  inflammationIndex: z.number(),
  purityScore: z.number(),
  confidence: z.number(),
});

const bodyResultSchema = z.object({
  isHuman: z.boolean(),
  bodyFatPct: z.number(),
  symmetryScore: z.number(),
  verdict: z.string().trim().min(1).max(200),
  confidence: z.number(),
});

async function callGemini(
  system: string,
  mime: string,
  bytes: Buffer,
  responseSchema: Record<string, unknown>,
): Promise<unknown> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) throw new VisionError("Motor de vision no configurado en el servidor.", 503);
  const model = (process.env.GEMINI_MODEL?.trim() || "gemini-2.5-flash").replace(/[^a-zA-Z0-9.-]/g, "");

  let response: Response;
  try {
    response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [
          {
            role: "user",
            parts: [
              { text: "Analiza la imagen adjunta siguiendo las instrucciones del sistema." },
              { inlineData: { mimeType: mime, data: bytes.toString("base64") } },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.2,
          responseMimeType: "application/json",
          responseSchema,
        },
      }),
      signal: AbortSignal.timeout(25_000),
    });
  } catch {
    throw new VisionError("El motor de vision no respondio a tiempo.", 502);
  }

  if (!response.ok) throw new VisionError("El motor de vision no pudo procesar la imagen.", 502);

  const payload = (await response.json()) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };
  const text = payload.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new VisionError("El motor de vision devolvio una respuesta vacia.", 502);
  try {
    return JSON.parse(text) as unknown;
  } catch {
    throw new VisionError("El motor de vision devolvio un formato no valido.", 502);
  }
}

export interface FoodAnalysis {
  isFood: boolean;
  name: string;
  grams: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  inflammation: number;
  purity: number;
  confidence: number;
}

export async function analyzeFood(bytes: Buffer, mime: string): Promise<FoodAnalysis> {
  const parsed = foodResultSchema.safeParse(await callGemini(FOOD_SYSTEM_PROMPT, mime, bytes, FOOD_RESPONSE_SCHEMA));
  if (!parsed.success) throw new VisionError("El analisis no es valido, intenta con otra foto.", 502);
  const value = parsed.data;
  return {
    isFood: value.isFood,
    name: value.name,
    grams: clamp(value.grams, 10, 3000),
    kcal: clamp(value.kcal, 0, 6000),
    protein: clamp(value.proteinG, 0, 400),
    carbs: clamp(value.carbsG, 0, 600),
    fat: clamp(value.fatG, 0, 400),
    inflammation: clamp(value.inflammationIndex, 0, 100),
    purity: clamp(value.purityScore, 0, 100),
    confidence: Math.max(0, Math.min(1, value.confidence)),
  };
}

export interface BodyAnalysis {
  isHuman: boolean;
  bodyFatPct: number;
  symmetryScore: number;
  verdict: string;
  auraPoints: number;
}

export function auraPointsFor(bodyFat: number, symmetry: number): number {
  return clamp(symmetry * 0.7 + Math.max(0, 25 - Math.abs(bodyFat - 11)) * 1.2, 0, 100);
}

export async function analyzeBody(bytes: Buffer, mime: string): Promise<BodyAnalysis> {
  const parsed = bodyResultSchema.safeParse(await callGemini(BODY_SYSTEM_PROMPT, mime, bytes, BODY_RESPONSE_SCHEMA));
  if (!parsed.success) throw new VisionError("El analisis no es valido, intenta con otra foto.", 502);
  const value = parsed.data;
  const bodyFatPct = clamp(value.bodyFatPct, 3, 60);
  const symmetryScore = clamp(value.symmetryScore, 0, 100);
  return {
    isHuman: value.isHuman,
    bodyFatPct,
    symmetryScore,
    verdict: value.verdict,
    auraPoints: auraPointsFor(bodyFatPct, symmetryScore),
  };
}

export async function saveBodyScan(user: PublicUser, scan: BodyAnalysis) {
  return withUser(user.id, async (tx) => {
    const clock = await dbClock(tx);
    const [row] = await tx
      .insert(bodyScans)
      .values({
        userId: user.id,
        bodyFatPct: scan.bodyFatPct,
        symmetryScore: scan.symmetryScore,
        auraPoints: scan.auraPoints,
        verdict: scan.verdict.slice(0, 200),
      })
      .returning();
    await tx
      .update(users)
      .set({
        xp: sql`${users.xp} + ${Math.round(scan.auraPoints / 4)}`,
        lastActivityAt: clock.now,
        updatedAt: clock.now,
      })
      .where(eq(users.id, user.id));
    return row;
  });
}

export async function getFlashEnabled(): Promise<boolean> {
  await ensureDbSecurity();
  const [row] = await db
    .select({ value: globalSettings.value })
    .from(globalSettings)
    .where(eq(globalSettings.key, "flash_sale"))
    .limit(1);
  return row?.value?.enabled === true;
}

export async function fulfillPurchase(
  reference: string,
  providerRef: string | null,
): Promise<{ userId: string; planId: string } | null> {
  await ensureDbSecurity();
  return db.transaction(async (tx) => {
    const [purchase] = await tx
      .update(purchases)
      .set({ status: "paid", paidAt: sql`now()`, providerRef })
      .where(and(eq(purchases.reference, reference), eq(purchases.status, "pending")))
      .returning({ userId: purchases.userId, planId: purchases.planId });
    if (!purchase) return null;

    const plan = PLANS[purchase.planId as PlanId];
    if (!plan) throw new Error("Plan no reconocido en la compra");

    await tx
      .update(users)
      .set({
        isVip: true,
        vipTier: sql`case when ${users.vipTier} = 'god' and (${users.vipPermanent} or ${users.vipUntil} > now()) then 'god' else ${plan.tier} end`,
        vipUntil: sql`greatest(coalesce(${users.vipUntil}, now()), now()) + make_interval(days => ${plan.days})`,
        updatedAt: sql`now()`,
      })
      .where(eq(users.id, purchase.userId));
    return purchase;
  });
}

const VIP_DURATION_DAYS = { "7d": 7, "30d": 30, "1y": 365 } as const;

export async function grantVip(userId: string, duration: "7d" | "30d" | "1y" | "permanent"): Promise<void> {
  await ensureDbSecurity();
  if (duration === "permanent") {
    await db
      .update(users)
      .set({ isVip: true, vipTier: "god", vipPermanent: true, updatedAt: sql`now()` })
      .where(eq(users.id, userId));
    return;
  }
  await db
    .update(users)
    .set({
      isVip: true,
      vipTier: "god",
      vipUntil: sql`greatest(coalesce(${users.vipUntil}, now()), now()) + make_interval(days => ${VIP_DURATION_DAYS[duration]})`,
      updatedAt: sql`now()`,
    })
    .where(eq(users.id, userId));
}

export interface RollReward {
  type: "xp" | "theme" | "vip_24h";
  value: string;
}

export async function openRoll(user: PublicUser, rollId: string): Promise<RollReward | null> {
  await ensureDbSecurity();
  const draw = randomInt(1, 101);
  let reward: RollReward;
  if (draw <= 60) {
    reward = { type: "xp", value: "10" };
  } else if (draw <= 85) {
    const available = THEMES.filter((theme) => theme !== user.theme && !user.unlockedThemes.includes(theme));
    reward =
      available.length > 0
        ? { type: "theme", value: available[randomInt(available.length)] }
        : { type: "xp", value: "10" };
  } else {
    reward = { type: "vip_24h", value: "24h" };
  }

  const [opened] = await db
    .update(rewardRolls)
    .set({ rewardType: reward.type, rewardValue: reward.value, openedAt: sql`now()` })
    .where(and(eq(rewardRolls.id, rollId), eq(rewardRolls.userId, user.id), isNull(rewardRolls.rewardType)))
    .returning({ id: rewardRolls.id });
  if (!opened) return null;

  if (reward.type === "xp") {
    await db
      .update(users)
      .set({ xp: sql`${users.xp} + 10`, updatedAt: sql`now()` })
      .where(eq(users.id, user.id));
  } else if (reward.type === "theme") {
    await db
      .update(users)
      .set({
        unlockedThemes: sql`${users.unlockedThemes} || to_jsonb(${reward.value}::text)`,
        updatedAt: sql`now()`,
      })
      .where(eq(users.id, user.id));
  } else {
    await db
      .update(users)
      .set({
        isVip: true,
        vipTier: sql`case when ${users.vipTier} = 'god' and (${users.vipPermanent} or ${users.vipUntil} > now()) then 'god' else 'basic' end`,
        vipUntil: sql`greatest(coalesce(${users.vipUntil}, now()), now()) + interval '24 hours'`,
        updatedAt: sql`now()`,
      })
      .where(eq(users.id, user.id));
  }
  return reward;
}
