"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { play } from "@/lib/client/audio";
import { api, newKey } from "@/lib/client/hooks";
import { captureFrame, compressImage, fireImpact } from "@/lib/client/media";
import { queueAdd } from "@/lib/client/offline";
import {
  FOOD_CATALOG,
  type FoodGroup,
  findFood,
  hasGodTier,
  type MealView,
  type PublicUser,
  macrosFor,
} from "@/lib/shared/domain";
import { BladeSlice, CodeBodyScanner, LayerExplode } from "./vfx";
import { PostWall } from "./Paywall";
import { Glass, Icon, MutexButton, SectionTitle } from "./ui";

interface ScanResult {
  meal: MealView;
  duplicate: boolean;
  xpGain: number;
  levelUp: boolean;
  streakDays: number;
  goalReached: boolean;
  isFirstMeal: boolean;
  confidence?: number;
}

interface BodyScanResult {
  scan: {
    id: string;
    bodyFatPct: number;
    symmetryScore: number;
    auraPoints: number;
    verdict: string;
    createdAt: string;
  };
}

function celebrate(result: { levelUp: boolean; goalReached: boolean }) {
  if (result.levelUp || result.goalReached) {
    fireImpact();
    play("levelup");
  } else {
    play("success");
  }
}

function CameraCapture({
  facing,
  onCapture,
  busy,
}: {
  facing: "environment" | "user";
  onCapture: (blob: Blob) => void;
  busy: boolean;
}) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [active, setActive] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [denied, setDenied] = useState(false);

  const stop = useCallback(() => {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setActive(false);
  }, []);

  useEffect(() => stop, [stop]);

  useEffect(() => {
    if (active && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
      void videoRef.current.play().catch(() => undefined);
    }
  }, [active]);

  const start = async () => {
    setNotice(null);
    setDenied(false);
    if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== "function") {
      setNotice("Este navegador no ofrece camara en esta pagina. Usa la galeria.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 1280 } },
        audio: false,
      });
      streamRef.current = stream;
      setActive(true);
    } catch {
      setDenied(true);
      setNotice("Permiso de camara bloqueado. Puedes activarlo y volver a intentar, o subir una foto desde tu galeria.");
    }
  };

  const capture = async () => {
    if (!videoRef.current) return;
    try {
      const frame = await captureFrame(videoRef.current);
      stop();
      onCapture(frame);
    } catch {
      setNotice("No se pudo capturar el fotograma. Intenta de nuevo o sube una foto.");
    }
  };

  return (
    <div className="space-y-3">
      {active ? (
        <div className="relative aspect-square w-full overflow-hidden rounded-[22px] border border-white/10 bg-black">
          <video ref={videoRef} playsInline muted className="h-full w-full object-cover" aria-label="Vista de la camara" />
          <div className="kalo-laser" aria-hidden="true" />
          <div className="absolute inset-x-0 bottom-4 flex justify-center gap-3">
            <MutexButton onPress={capture} ready={!busy} className="min-w-[160px]">
              <Icon name="camera" size={16} />
              Capturar
            </MutexButton>
            <button type="button" onClick={stop} className="kalo-btn kalo-btn-ghost">
              Cancelar
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          <MutexButton variant="gold" onPress={start} ready={!busy} className="w-full">
            <Icon name="camera" size={16} />
            Abrir camara
          </MutexButton>
          <button
            type="button"
            disabled={busy}
            onClick={() => fileRef.current?.click()}
            className="kalo-btn kalo-btn-ghost w-full"
          >
            <Icon name="upload" size={16} />
            Galeria
          </button>
        </div>
      )}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture={facing}
        className="hidden"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (file) onCapture(file);
        }}
      />
      {notice ? (
        <div className={`rounded-2xl border p-3 text-xs leading-relaxed ${denied ? "border-[rgba(255,123,123,0.3)] text-[color:var(--kalo-danger)]" : "border-white/10 text-[color:var(--kalo-muted)]"}`} role="status">
          {notice}
          {denied ? (
            <ol className="mt-2 list-decimal space-y-1 pl-4 text-[color:var(--kalo-muted)]">
              <li>Abre los ajustes del sitio en tu navegador.</li>
              <li>En Permisos, cambia la camara a Permitir.</li>
              <li>Recarga KALO y vuelve a abrir la camara.</li>
            </ol>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

const SCAN_TELEMETRY = [
  "Segmentando el plato",
  "Estimando porciones visibles",
  "Cruzando base cubana y latina",
  "Calculando indice de inflamacion",
  "Verificando pureza de ingredientes",
];

const BODY_TELEMETRY = [
  "Alineando silueta",
  "Midiendo simetria muscular",
  "Estimando grasa corporal visual",
  "Calculando puntos de aura",
];

function FoodScanner({
  user,
  onChanged,
  onGoVip,
}: {
  user: PublicUser;
  onChanged: () => Promise<void> | void;
  onGoVip: () => void;
}) {
  const [phase, setPhase] = useState<"idle" | "analyzing" | "result" | "error" | "catalog">("idle");
  const [result, setResult] = useState<ScanResult | null>(null);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [published, setPublished] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    return () => {
      if (photoUrl) URL.revokeObjectURL(photoUrl);
    };
  }, [photoUrl]);

  const analyze = async (source: Blob) => {
    setBusy(true);
    setPhase("analyzing");
    setError(null);
    setPublished(false);
    try {
      const compressed = await compressImage(source);
      const url = URL.createObjectURL(compressed.blob);
      setPhotoUrl((previous) => {
        if (previous) URL.revokeObjectURL(previous);
        return url;
      });
      const form = new FormData();
      form.append("image", compressed.blob, compressed.mime === "image/webp" ? "plate.webp" : "plate.jpg");
      const response = await api<ScanResult>("/api/scan/food", { form });
      if (!response.ok) {
        setError(response.error);
        setPhase("error");
        return;
      }
      setResult(response.data);
      setPhase("result");
      celebrate(response.data);
      await onChanged();
    } catch {
      setError("No se pudo preparar la foto. Intenta con otra imagen.");
      setPhase("error");
    } finally {
      setBusy(false);
    }
  };

  const publish = async () => {
    if (!result) return;
    const response = await api<{ id: string }>("/api/social/post", { body: { mealId: result.meal.id } });
    if (!response.ok) {
      setError(response.error);
      return;
    }
    setPublished(true);
    play("success");
  };

  const reset = () => {
    setResult(null);
    setPhase("idle");
    setError(null);
  };

  if (phase === "catalog") {
    return <CatalogPicker onLogged={onChanged} onBack={reset} />;
  }

  if (phase === "analyzing") {
    return (
      <div className="space-y-4">
        <CodeBodyScanner telemetry={SCAN_TELEMETRY} className="aspect-square w-full">
          {photoUrl ? <img src={photoUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-35" /> : null}
        </CodeBodyScanner>
        <p className="text-center text-xs text-[color:var(--kalo-muted)]" role="status">
          Analizando con el motor de vision. La foto no se conserva en el servidor.
        </p>
      </div>
    );
  }

  if (phase === "result" && result) {
    const isVip = hasGodTier(user) || user.vipActive;
    return (
      <div className="kalo-fade-in space-y-5">
        <BladeSlice photoUrl={photoUrl} kcal={result.meal.kcal} label={result.meal.name} />
        <Glass className="space-y-4 p-5">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="kalo-ellipsis text-base font-semibold">{result.meal.name}</p>
              <p className="text-xs text-[color:var(--kalo-muted)]">
                {result.meal.grams} g estimados · Pureza {result.meal.purity}/100 · Inflamacion {result.meal.inflammation}/100
              </p>
            </div>
            {result.meal.verifiedAi ? (
              <span className="shrink-0 rounded-full border border-[rgba(0,255,135,0.4)] px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-neon)]">
                Sello IA
              </span>
            ) : null}
          </div>
          <LayerExplode
            protein={result.meal.protein}
            carbs={result.meal.carbs}
            fat={result.meal.fat}
            kcal={result.meal.kcal}
            fiberNote={`+${result.xpGain} XP · racha ${result.streakDays} dias`}
          />
        </Glass>

        {isVip ? (
          <Glass className="space-y-2 p-5">
            <p className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-gold)]">Analisis profundo</p>
            <p className="text-sm leading-relaxed text-[color:var(--kalo-muted)]">
              Esta comida aporta {result.meal.protein} g de proteina y {result.meal.carbs} g de carbohidratos. Mantén la pureza por encima de 70 para acelerar la evolucion del Bio-Pou.
            </p>
          </Glass>
        ) : (
          <PostWall
            title="Analisis profundo bloqueado"
            teaser="Perteneces al Top 14% de genetica actual, pero detectamos 2 bloqueos metabolicos que frenan tu Potencial al 94%."
            cta="Desbloquear Analisis Profundo"
            onCta={onGoVip}
          />
        )}

        {error ? (
          <p role="alert" className="text-sm text-[color:var(--kalo-danger)]">
            {error}
          </p>
        ) : null}

        <div className="grid grid-cols-2 gap-3">
          <MutexButton variant="ghost" onPress={publish} ready={!published}>
            <Icon name="share" size={15} />
            {published ? "Publicado" : "Publicar"}
          </MutexButton>
          <button type="button" onClick={reset} className="kalo-btn kalo-btn-gold">
            <Icon name="scan" size={15} />
            Otro plato
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <Glass className="space-y-4 p-5">
        <div>
          <p className="text-sm font-semibold">Escanea tu plato</p>
          <p className="mt-1 text-xs leading-relaxed text-[color:var(--kalo-muted)]">
            La foto se reduce a 800 x 800 px en tu dispositivo antes de enviarse. Reconocemos congri, picadillo, viandas, tostones, batidos y platos internacionales.
          </p>
        </div>
        <CameraCapture facing="environment" onCapture={(blob) => void analyze(blob)} busy={busy} />
      </Glass>
      {error ? (
        <Glass className="space-y-3 p-4">
          <p role="alert" className="text-sm text-[color:var(--kalo-danger)]">
            {error}
          </p>
          <button type="button" onClick={() => setPhase("catalog")} className="kalo-btn kalo-btn-ghost w-full">
            Elegir del catalogo cubano y latino
          </button>
        </Glass>
      ) : (
        <button type="button" onClick={() => setPhase("catalog")} className="kalo-btn kalo-btn-ghost w-full">
          Registrar desde el catalogo
        </button>
      )}
    </div>
  );
}

const GROUP_LABELS: Record<FoodGroup, string> = {
  cubana: "Cubana",
  latina: "Latina",
  global: "Internacional",
  saludable: "Saludable",
  bebida: "Bebidas",
};

function CatalogPicker({ onLogged, onBack }: { onLogged: () => Promise<void> | void; onBack: () => void }) {
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [grams, setGrams] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return FOOD_CATALOG.filter((item) => !term || item.name.toLowerCase().includes(term));
  }, [query]);

  const selected = selectedId ? findFood(selectedId) : undefined;
  const gramsValue = Number(grams || selected?.baseGrams || 0);

  const log = async () => {
    setError(null);
    setMessage(null);
    if (!selected) return;
    if (!Number.isInteger(gramsValue) || gramsValue < 10 || gramsValue > 2000) {
      setError("Indica entre 10 y 2000 gramos.");
      return;
    }
    const clientId = newKey();
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      await queueLocal(clientId);
      return;
    }
    const response = await api<ScanResult>("/api/meals", {
      body: { catalogId: selected.id, grams: gramsValue, clientId },
    });
    if (!response.ok) {
      if (response.status === 0) {
        await queueLocal(clientId);
        return;
      }
      setError(response.error);
      return;
    }
    celebrate(response.data);
    setMessage(`${selected.name} registrado. +${response.data.xpGain} XP · racha ${response.data.streakDays} dias.`);
    setSelectedId(null);
    setGrams("");
    await onLogged();
  };

  const queueLocal = async (clientId: string) => {
    if (!selected) return;
    const macros = macrosFor(selected, gramsValue);
    await queueAdd({
      clientId,
      catalogId: selected.id,
      grams: gramsValue,
      name: selected.name,
      kcal: macros.kcal,
      protein: macros.protein,
      carbs: macros.carbs,
      fat: macros.fat,
      queuedAt: Date.now(),
    });
    play("warn");
    setMessage("Sin conexion. Guardado en este dispositivo y sincronizado al recuperar la red.");
    setSelectedId(null);
    setGrams("");
  };

  return (
    <div className="kalo-fade-in space-y-4">
      <div className="flex items-center justify-between gap-3">
        <button type="button" onClick={onBack} className="kalo-btn kalo-btn-ghost kalo-btn-sm">
          Volver al escaner
        </button>
        <span className="text-[10px] uppercase tracking-[0.16em] text-[color:var(--kalo-muted)]">Catalogo</span>
      </div>
      <div className="relative">
        <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[color:var(--kalo-muted)]">
          <Icon name="search" size={16} />
        </span>
        <input
          className="kalo-input pl-11"
          placeholder="Buscar: congri, tostones, batido..."
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          aria-label="Buscar alimento"
          maxLength={40}
        />
      </div>
      <div className="max-h-[52dvh] space-y-4 overflow-y-auto kalo-scroll pr-1">
        {(Object.keys(GROUP_LABELS) as FoodGroup[]).map((group) => {
          const items = filtered.filter((item) => item.group === group);
          if (items.length === 0) return null;
          return (
            <div key={group}>
              <p className="mb-2 text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-muted)]">{GROUP_LABELS[group]}</p>
              <ul className="space-y-2">
                {items.map((item) => (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedId(item.id);
                        setGrams(String(item.baseGrams));
                        play("menu");
                      }}
                      aria-pressed={selectedId === item.id}
                      className={`kalo-glass flex w-full items-center justify-between gap-3 p-3.5 text-left ${selectedId === item.id ? "border-[rgba(229,193,88,0.55)]" : ""}`}
                    >
                      <span className="kalo-ellipsis text-sm font-medium">{item.name}</span>
                      <span className="shrink-0 text-xs text-[color:var(--kalo-muted)]">{Math.round((item.per100.kcal * item.baseGrams) / 100)} kcal</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
      {selected ? (
        <Glass className="kalo-fade-in space-y-3 p-4">
          <div className="flex items-center justify-between gap-3">
            <p className="kalo-ellipsis text-sm font-semibold">{selected.name}</p>
            <p className="text-xs text-[color:var(--kalo-muted)]">{macrosFor(selected, gramsValue).kcal} kcal</p>
          </div>
          <div className="flex items-center gap-3">
            <label htmlFor="grams" className="shrink-0 text-xs uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">
              Gramos
            </label>
            <input
              id="grams"
              inputMode="numeric"
              className="kalo-input"
              value={grams}
              onChange={(event) => setGrams(event.target.value.replace(/[^0-9]/g, "").slice(0, 4))}
            />
          </div>
          {error ? (
            <p role="alert" className="text-xs text-[color:var(--kalo-danger)]">
              {error}
            </p>
          ) : null}
          <MutexButton className="w-full" onPress={log} busyLabel="Registrando">
            Registrar comida
          </MutexButton>
        </Glass>
      ) : null}
      {message ? (
        <p role="status" className="kalo-fade-in text-center text-xs text-[color:var(--kalo-gold)]">
          {message}
        </p>
      ) : null}
    </div>
  );
}

function BodyScanner({
  user,
  onChanged,
  onGoVip,
}: {
  user: PublicUser;
  onChanged: () => Promise<void> | void;
  onGoVip: () => void;
}) {
  const [phase, setPhase] = useState<"idle" | "analyzing" | "result" | "error">("idle");
  const [result, setResult] = useState<BodyScanResult["scan"] | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!hasGodTier(user)) {
    return (
      <PostWall
        title="Escaner de fisico bloqueado"
        teaser="Analizamos tu grasa corporal visual, tu simetria muscular y tus puntos de aura. Exclusivo de MODO DIOS."
        cta="Desbloquear con MODO DIOS"
        onCta={onGoVip}
      />
    );
  }

  const analyze = async (source: Blob) => {
    setPhase("analyzing");
    setError(null);
    try {
      const compressed = await compressImage(source);
      const form = new FormData();
      form.append("image", compressed.blob, compressed.mime === "image/webp" ? "body.webp" : "body.jpg");
      const response = await api<BodyScanResult>("/api/scan/body", { form });
      if (!response.ok) {
        setError(response.error);
        setPhase("error");
        return;
      }
      setResult(response.data.scan);
      setPhase("result");
      play("scan");
      await onChanged();
    } catch {
      setError("No se pudo procesar la foto. Intenta con otra imagen.");
      setPhase("error");
    }
  };

  if (phase === "analyzing") {
    return (
      <div className="space-y-4">
        <CodeBodyScanner telemetry={BODY_TELEMETRY} className="aspect-[1/2] w-full max-h-[62dvh] mx-auto" />
        <p className="text-center text-xs text-[color:var(--kalo-muted)]" role="status">
          Estimacion visual en curso. No es un diagnostico medico.
        </p>
      </div>
    );
  }

  if (phase === "result" && result) {
    return (
      <div className="kalo-fade-in space-y-4">
        <Glass className="grid grid-cols-3 gap-3 p-5 text-center">
          <Metric label="Grasa visual" value={`${result.bodyFatPct}%`} />
          <Metric label="Simetria" value={`${result.symmetryScore}`} />
          <Metric label="Aura" value={`${result.auraPoints}`} accent />
        </Glass>
        <Glass className="p-5">
          <p className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-gold)]">Veredicto</p>
          <p className="mt-2 text-sm leading-relaxed">{result.verdict}</p>
          <p className="mt-3 text-[11px] text-[color:var(--kalo-muted)]">
            Estimacion visual informativa. No sustituye la valoracion de un profesional de la salud.
          </p>
        </Glass>
        <button type="button" onClick={() => setPhase("idle")} className="kalo-btn kalo-btn-gold w-full">
          Nuevo analisis
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Glass className="space-y-4 p-5">
        <div>
          <p className="text-sm font-semibold">Foto de progreso</p>
          <p className="mt-1 text-xs leading-relaxed text-[color:var(--kalo-muted)]">
            Ponte de frente, con luz uniforme y ropa ajustada. La imagen se procesa en memoria y no se almacena.
          </p>
        </div>
        <CameraCapture facing="user" onCapture={(blob) => void analyze(blob)} busy={false} />
      </Glass>
      {error ? (
        <p role="alert" className="text-sm text-[color:var(--kalo-danger)]">
          {error}
        </p>
      ) : null}
    </div>
  );
}

function Metric({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-[0.16em] text-[color:var(--kalo-muted)]">{label}</p>
      <p className={`mt-1 text-2xl font-semibold ${accent ? "kalo-gold-text" : ""}`}>{value}</p>
    </div>
  );
}

export function Scanners({
  user,
  onChanged,
  onGoVip,
}: {
  user: PublicUser;
  onChanged: () => Promise<void> | void;
  onGoVip: () => void;
}) {
  const [mode, setMode] = useState<"food" | "body">("food");
  return (
    <div className="kalo-fade-in space-y-6 pt-2">
      <SectionTitle eyebrow="Escaner biometrico" title={mode === "food" ? "Comida" : "Fisico"} />
      <div className="grid grid-cols-2 gap-1 rounded-2xl bg-white/[0.04] p-1" role="tablist">
        {(["food", "body"] as const).map((option) => (
          <button
            key={option}
            type="button"
            role="tab"
            aria-selected={mode === option}
            onClick={() => setMode(option)}
            className={`min-h-[40px] rounded-xl text-sm font-medium ${mode === option ? "bg-white/[0.08] text-[color:var(--kalo-gold)]" : "text-[color:var(--kalo-muted)]"}`}
          >
            {option === "food" ? "Comida" : "Espejo fisico"}
          </button>
        ))}
      </div>
      {mode === "food" ? (
        <FoodScanner user={user} onChanged={onChanged} onGoVip={onGoVip} />
      ) : (
        <BodyScanner user={user} onChanged={onChanged} onGoVip={onGoVip} />
      )}
    </div>
  );
}
