"use client";

import { type PointerEvent as ReactPointerEvent, type ReactNode, useEffect, useId, useRef, useState } from "react";
import { play } from "@/lib/client/audio";
import { Icon } from "./ui";

const FIGURE = {
  head: "M100 12 C118 12 128 26 128 44 C128 62 116 74 100 74 C84 74 72 62 72 44 C72 26 82 12 100 12Z",
  torso:
    "M70 94 L130 94 L150 120 L144 226 L130 246 L70 246 L56 226 L50 120 Z",
  leftArm: "M56 102 L30 116 L16 210 L30 214 L58 150 Z",
  rightArm: "M144 102 L170 116 L184 210 L170 214 L142 150 Z",
  leftLeg: "M70 244 L100 250 L94 388 L78 390 L66 268 Z",
  rightLeg: "M130 244 L100 250 L106 388 L122 390 L134 268 Z",
  neck: "M90 72 L110 72 L112 96 L88 96 Z",
};

const FIGURE_PARTS = [FIGURE.head, FIGURE.torso, FIGURE.leftArm, FIGURE.rightArm, FIGURE.leftLeg, FIGURE.rightLeg, FIGURE.neck];

export function CodeBodyScanner({
  telemetry,
  className = "",
  children,
}: {
  telemetry: string[];
  className?: string;
  children?: ReactNode;
}) {
  const clipId = useId().replace(/:/g, "");
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (telemetry.length === 0) return;
    const id = window.setInterval(() => setIndex((value) => (value + 1) % telemetry.length), 1100);
    return () => window.clearInterval(id);
  }, [telemetry.length]);

  const lines = Array.from({ length: 24 }, (_, row) => 8 + row * 16);

  return (
    <div className={`relative overflow-hidden rounded-[22px] border border-white/10 bg-[#070709] ${className}`}>
      <svg viewBox="0 0 200 400" className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
        <defs>
          <clipPath id={clipId}>
            {FIGURE_PARTS.map((path) => (
              <path key={path} d={path} />
            ))}
          </clipPath>
        </defs>
        <g fill="none" stroke="#00FF87" strokeOpacity="0.09" strokeWidth="0.6">
          {Array.from({ length: 11 }, (_, column) => (
            <line key={`v${column}`} x1={column * 20} y1="0" x2={column * 20} y2="400" />
          ))}
        </g>
        <g clipPath={`url(#${clipId})`} fill="none" stroke="#00FF87" strokeOpacity="0.5" strokeWidth="0.7">
          {lines.map((y) => (
            <line key={y} x1="0" y1={y} x2="200" y2={y} />
          ))}
          {Array.from({ length: 14 }, (_, column) => (
            <line key={`d${column}`} x1={column * 16 - 60} y1="0" x2={column * 16 + 40} y2="400" strokeOpacity="0.35" />
          ))}
        </g>
        <g fill="none" stroke="#E5C158" strokeWidth="1.1" strokeOpacity="0.85">
          {FIGURE_PARTS.map((path) => (
            <path key={`o-${path}`} d={path} />
          ))}
        </g>
      </svg>
      <div className="kalo-laser" />
      {telemetry.length > 0 ? (
        <div className="pointer-events-none absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
          <span className="kalo-fade-in kalo-ellipsis rounded-full border border-[rgba(0,255,135,0.35)] bg-black/60 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.16em] text-[color:var(--kalo-neon)]" key={index}>
            {telemetry[index]}
          </span>
        </div>
      ) : null}
      {children}
    </div>
  );
}

export function BladeSlice({
  photoUrl,
  kcal,
  label,
  onReveal,
}: {
  photoUrl: string | null;
  kcal: number;
  label: string;
  onReveal?: () => void;
}) {
  const [sliced, setSliced] = useState(false);
  const [cutting, setCutting] = useState(false);
  const timer = useRef<number | null>(null);

  const cut = () => {
    setCutting(true);
    setSliced(true);
    play("slice");
    onReveal?.();
  };

  useEffect(() => {
    timer.current = window.setTimeout(cut, 650);
    return () => {
      if (timer.current) window.clearTimeout(timer.current);
    };
    // The reveal runs once per mounted result.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <button
      type="button"
      onClick={() => {
        setSliced(false);
        setCutting(false);
        window.setTimeout(cut, 120);
      }}
      className="relative aspect-square w-full overflow-hidden rounded-[22px] border border-white/10 bg-[#0c0c10] text-left"
      aria-label={`${label}: ${kcal} kcal. Toca para repetir el corte.`}
    >
      {photoUrl ? (
        <img
          src={photoUrl}
          alt=""
          className="absolute inset-0 h-full w-full object-cover transition-[clip-path] duration-700"
          style={{ clipPath: sliced ? "polygon(0 0, 100% 0, 0 100%)" : "polygon(0 0, 100% 0, 100% 100%, 0 100%)" }}
        />
      ) : (
        <div
          className="absolute inset-0 transition-[clip-path] duration-700"
          style={{
            background: "linear-gradient(140deg, #1b1b22, #0b0b0f 60%, #16161c)",
            clipPath: sliced ? "polygon(0 0, 100% 0, 0 100%)" : "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
          }}
        />
      )}
      <div
        className="absolute inset-0 transition-transform duration-700 ease-out"
        style={{
          clipPath: "polygon(100% 0, 100% 100%, 0 100%)",
          transform: sliced ? "translate(10px, 10px)" : "translate(100%, 100%)",
          background: "linear-gradient(150deg, #F4F4F6 0%, #d8d8de 100%)",
        }}
      >
        <div className="flex h-full flex-col items-end justify-end gap-1 p-6 text-[#070709]">
          <span className="text-[10px] uppercase tracking-[0.22em] text-[#070709]/60">{label}</span>
          <span className="text-5xl font-semibold leading-none tracking-tight">{kcal}</span>
          <span className="text-xs uppercase tracking-[0.2em] text-[#070709]/70">kcal estimadas</span>
        </div>
      </div>
      <div className={`kalo-blade ${cutting ? "is-cutting" : ""}`} />
    </button>
  );
}

interface Layer {
  title: string;
  value: string;
  tone: string;
  accent: string;
}

export function LayerExplode({
  protein,
  carbs,
  fat,
  kcal,
  fiberNote,
}: {
  protein: number;
  carbs: number;
  fat: number;
  kcal: number;
  fiberNote: string;
}) {
  const [exploded, setExploded] = useState(false);
  const layers: Layer[] = [
    { title: "Capa 1 / Proteinas", value: `${protein} g`, tone: "rgba(229,193,88,0.14)", accent: "#E5C158" },
    { title: "Capa 2 / Carbohidratos", value: `${carbs} g`, tone: "rgba(244,244,246,0.08)", accent: "#F4F4F6" },
    { title: "Capa 3 / Grasas y micros", value: `${fat} g`, tone: "rgba(0,255,135,0.08)", accent: "#00FF87" },
  ];
  const offsets = exploded
    ? ["translate3d(-64px, -58px, 120px)", "translate3d(0px, 0px, 0px)", "translate3d(64px, 58px, -120px)"]
    : ["translate3d(0px, 0px, 24px)", "translate3d(0px, 0px, 0px)", "translate3d(0px, 0px, -24px)"];

  return (
    <div className="space-y-4">
      <div className="kalo-scene relative h-[260px] w-full">
        <div
          className="kalo-stage-3d absolute inset-0"
          style={{ transform: exploded ? "rotateX(58deg) rotateZ(-32deg)" : "rotateX(58deg) rotateZ(-32deg) translateZ(0px)" }}
        >
          {layers.map((layer, index) => (
            <div
              key={layer.title}
              className="kalo-layer-3d kalo-glass flex flex-col justify-between p-4"
              style={{
                inset: "18% 14%",
                transform: offsets[index],
                background: `linear-gradient(160deg, ${layer.tone}, rgba(7,7,9,0.92))`,
                borderColor: `${layer.accent}55`,
                zIndex: 3 - index,
              }}
            >
              <span className="kalo-ellipsis text-[10px] uppercase tracking-[0.18em]" style={{ color: layer.accent }}>
                {layer.title}
              </span>
              <span className="text-3xl font-semibold tracking-tight">{layer.value}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-[color:var(--kalo-muted)]">
          <span className="font-semibold text-[color:var(--kalo-titanium)]">{kcal} kcal</span> · {fiberNote}
        </p>
        <button type="button" className="kalo-btn kalo-btn-ghost kalo-btn-sm" onClick={() => setExploded((value) => !value)} aria-pressed={exploded}>
          <Icon name="layers" size={14} />
          {exploded ? "Compactar" : "Explotar capas"}
        </button>
      </div>
    </div>
  );
}

function zigzagPath(part: "top" | "bottom"): string {
  if (part === "top") {
    const points = ["0% 0%", "100% 0%", "100% 92%"];
    for (let step = 0; step <= 10; step++) {
      const x = 100 - step * 10;
      points.push(`${x}% ${step % 2 === 0 ? 92 : 100}%`);
    }
    points.push("0% 92%");
    return `polygon(${points.join(", ")})`;
  }
  const points = ["0% 100%", "100% 100%", "100% 8%"];
  for (let step = 1; step <= 10; step++) {
    const x = 100 - step * 10;
    points.push(`${x}% ${step % 2 === 0 ? 8 : 0}%`);
  }
  return `polygon(${points.join(", ")})`;
}

export function PaperTear({
  title,
  dateLabel,
  children,
}: {
  title: string;
  dateLabel: string;
  children: ReactNode;
}) {
  const [torn, setTorn] = useState(false);
  const [drag, setDrag] = useState(0);
  const start = useRef<number | null>(null);
  const width = useRef(1);

  const onDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (torn) return;
    start.current = event.clientX;
    width.current = event.currentTarget.getBoundingClientRect().width || 1;
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const onMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (start.current === null || torn) return;
    const delta = event.clientX - start.current;
    setDrag(Math.max(-1, Math.min(1, delta / (width.current * 0.6))));
  };

  const onUp = () => {
    if (start.current === null) return;
    start.current = null;
    if (Math.abs(drag) >= 1) {
      setTorn(true);
      play("rip");
    }
    setDrag(0);
  };

  const shift = torn ? 0 : drag * 6;
  const topTransform = torn
    ? "translate3d(-115%, -26px, 0) rotate(-7deg)"
    : `translate3d(${shift}px, 0, 0) rotate(${drag * 0.6}deg)`;
  const bottomTransform = torn
    ? "translate3d(14px, 18px, 0) rotate(3deg)"
    : `translate3d(${-shift * 0.4}px, 0, 0)`;

  return (
    <div className="relative mx-auto w-full max-w-sm select-none" style={{ perspective: "900px" }}>
      <div
        className="relative min-h-[360px] touch-pan-y cursor-grab active:cursor-grabbing"
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        role="group"
        aria-label={`${title}. Desliza para rasgar el ticket.`}
      >
        <div
          className="kalo-tear-top text-[#070709]"
          style={{ clipPath: zigzagPath("top"), transform: topTransform, background: "linear-gradient(170deg, #F4F4F6, #d6d6dc)" }}
        >
          <TicketFace title={title} dateLabel={dateLabel} torn>
            {children}
          </TicketFace>
        </div>
        <div
          className="kalo-tear-bottom text-[#070709]"
          style={{ clipPath: zigzagPath("bottom"), transform: bottomTransform, background: "linear-gradient(170deg, #F4F4F6, #d6d6dc)" }}
          aria-hidden="true"
        >
          <TicketFace title={title} dateLabel={dateLabel} torn={false}>
            {children}
          </TicketFace>
        </div>
        <div className="invisible min-h-[360px]" />
      </div>
      <div className="mt-3 flex items-center justify-between text-[11px] text-[color:var(--kalo-muted)]">
        <span>{torn ? "Ticket rasgado" : "Desliza el ticket para rasgarlo"}</span>
        {torn ? (
          <button type="button" className="kalo-btn kalo-btn-ghost kalo-btn-sm" onClick={() => setTorn(false)}>
            <Icon name="refresh" size={14} />
            Restaurar
          </button>
        ) : null}
      </div>
    </div>
  );
}

function TicketFace({
  title,
  dateLabel,
  torn,
  children,
}: {
  title: string;
  dateLabel: string;
  torn: boolean;
  children: ReactNode;
}) {
  return (
    <div className="absolute inset-0 flex flex-col p-6">
      <div className="flex items-start justify-between gap-3 border-b border-dashed border-[#070709]/25 pb-3">
        <div className="min-w-0">
          <p className="text-[10px] uppercase tracking-[0.24em] text-[#070709]/60">KALO // AURA AI</p>
          <h3 className="kalo-ellipsis mt-1 text-lg font-semibold tracking-tight">{title}</h3>
        </div>
        <span className="shrink-0 text-[10px] uppercase tracking-[0.16em] text-[#070709]/60">{dateLabel}</span>
      </div>
      <div className="mt-4 flex-1">{children}</div>
      {torn ? null : (
        <p className="mt-4 text-center text-[10px] uppercase tracking-[0.3em] text-[#070709]/50">Resumen diario verificado</p>
      )}
    </div>
  );
}
