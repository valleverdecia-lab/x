import { openRoll } from "@/lib/server/services";
import { assertSameOrigin, getSessionUser, readJson } from "@/lib/server/security";
import { rollOpenSchema } from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ kind: string }> };

export async function POST(req: Request, ctx: Ctx) {
  const { kind } = await ctx.params;
  if (!assertSameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Inicia sesion para continuar" }, { status: 401 });
  if (kind !== "open") return Response.json({ error: "No encontrado" }, { status: 404 });

  const parsed = await readJson(req, rollOpenSchema);
  if (!parsed.ok) return parsed.response;

  const reward = await openRoll(user, parsed.data.rollId);
  if (!reward) {
    return Response.json({ error: "La caja ya fue abierta o no existe" }, { status: 409 });
  }
  return Response.json({ reward });
}
