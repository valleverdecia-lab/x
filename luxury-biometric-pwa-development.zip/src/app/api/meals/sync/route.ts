import { db } from "@/db";
import { dbClock } from "@/lib/server/db";
import { catalogMealInput, recordMeal } from "@/lib/server/services";
import { assertSameOrigin, getSessionUser, readJson } from "@/lib/server/security";
import { findFood, macrosFor } from "@/lib/shared/domain";
import { mealSyncSchema } from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

type SyncStatus = "synced" | "duplicate" | "rejected";

export async function POST(req: Request) {
  if (!assertSameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Inicia sesion para continuar" }, { status: 401 });

  const parsed = await readJson(req, mealSyncSchema);
  if (!parsed.ok) return parsed.response;

  const clock = await dbClock(db);
  let current = user;
  const results: Array<{ clientId: string; status: SyncStatus }> = [];

  for (const item of parsed.data.items) {
    const food = findFood(item.catalogId);
    if (!food) {
      results.push({ clientId: item.clientId, status: "rejected" });
      continue;
    }
    const recorded = await recordMeal(current, catalogMealInput(food, macrosFor(food, item.grams)), {
      clientId: item.clientId,
      offline: true,
    });
    if (recorded.duplicate) {
      results.push({ clientId: item.clientId, status: "duplicate" });
      continue;
    }
    current = {
      ...current,
      streakDays: recorded.streakDays,
      streakLastDay: clock.today,
      xp: current.xp + recorded.xpGain,
    };
    results.push({ clientId: item.clientId, status: "synced" });
  }

  return Response.json({ results, serverNow: clock.now.toISOString() });
}
