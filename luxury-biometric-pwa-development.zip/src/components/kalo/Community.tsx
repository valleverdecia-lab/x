"use client";

import { useCallback, useEffect, useState } from "react";
import { play } from "@/lib/client/audio";
import { api } from "@/lib/client/hooks";
import type { PostView, PublicUser } from "@/lib/shared/domain";
import { guildCreateSchema } from "@/lib/shared/schemas";
import { Glass, Icon, MutexButton, SectionTitle, Skeleton, formatTime } from "./ui";

interface WallPayload {
  posts: PostView[];
}

interface GuildRow {
  id: string;
  name: string;
  motto: string;
  emblem: string;
  members: number;
  weeklyPoints: number;
  rank: number;
  isMine: boolean;
}

interface GuildsPayload {
  myGuildId: string | null;
  guilds: GuildRow[];
}

interface RafflePayload {
  prize: string;
  period: string;
  top: Array<{ rank: number; name: string; verified: number; isMe: boolean }>;
  mine: { verified: number };
}

function Wall() {
  const [payload, setPayload] = useState<WallPayload | null>(null);

  const load = useCallback(async () => {
    const result = await api<WallPayload>("/api/social/posts");
    if (result.ok) setPayload(result.data);
  }, []);

  useEffect(() => {
    void load();
    const id = window.setInterval(() => void load(), 15_000);
    return () => window.clearInterval(id);
  }, [load]);

  return (
    <section aria-label="Muro en vivo">
      <SectionTitle
        eyebrow="Muro en vivo"
        title="Platos verificados"
        right={
          <span className="flex items-center gap-2 text-[10px] uppercase tracking-[0.16em] text-[color:var(--kalo-neon)]">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#00FF87]" aria-hidden="true" />
            En vivo
          </span>
        }
      />
      {payload === null ? (
        <div className="space-y-2">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-20 w-full" />
        </div>
      ) : payload.posts.length === 0 ? (
        <Glass className="p-5 text-sm text-[color:var(--kalo-muted)]">Todavia no hay publicaciones. Escanea un plato y publicalo.</Glass>
      ) : (
        <ul className="space-y-2">
          {payload.posts.map((post) => (
            <li key={post.id} className="kalo-glass kalo-fade-in p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="kalo-ellipsis text-sm font-semibold">{post.title}</p>
                  <p className="kalo-ellipsis mt-1 text-xs text-[color:var(--kalo-muted)]">
                    {post.authorName}
                    {post.isMine ? " · Tu publicacion" : ""} · {formatTime(post.createdAt)}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-sm font-semibold">{post.kcal} kcal</p>
                  <p className="text-[10px] text-[color:var(--kalo-muted)]">Pureza {post.purity}</p>
                </div>
              </div>
              {post.verifiedAi ? (
                <span className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-[rgba(0,255,135,0.35)] px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-neon)]">
                  <Icon name="check" size={12} />
                  Sello de verificacion IA
                </span>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Guilds({ user, onChanged }: { user: PublicUser; onChanged: () => Promise<void> | void }) {
  const [payload, setPayload] = useState<GuildsPayload | null>(null);
  const [name, setName] = useState("");
  const [motto, setMotto] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    const result = await api<GuildsPayload>("/api/social/guilds");
    if (result.ok) setPayload(result.data);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const create = async () => {
    setError(null);
    setNotice(null);
    const candidate = { name: name.trim(), motto: motto.trim() || undefined };
    const checked = guildCreateSchema.safeParse(candidate);
    if (!checked.success) {
      setError(checked.error.issues[0]?.message ?? "Revisa el nombre del gremio.");
      return;
    }
    const result = await api<{ id: string }>("/api/social/guild-create", { body: candidate });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    play("success");
    setName("");
    setMotto("");
    setNotice("Gremio creado. Tu disciplina ya suma puntos semanales.");
    await load();
    await onChanged();
  };

  const join = async (guildId: string) => {
    setError(null);
    const result = await api<{ guildId: string }>("/api/social/guild-join", { body: { guildId } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    play("success");
    setNotice("Te uniste al gremio.");
    await load();
    await onChanged();
  };

  const leave = async () => {
    setError(null);
    const result = await api("/api/social/guild-leave", { body: {} });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    play("menu");
    setNotice("Saliste del gremio.");
    await load();
    await onChanged();
  };

  const mine = payload?.guilds.find((guild) => guild.isMine) ?? null;

  return (
    <section aria-label="Gremios">
      <SectionTitle eyebrow="Guerra semanal" title="Gremios" />
      {mine ? (
        <Glass className="mb-4 space-y-3 p-5">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-gold)]">Tu gremio</p>
              <p className="kalo-ellipsis mt-1 text-lg font-semibold">{mine.name}</p>
              {mine.motto ? <p className="kalo-ellipsis text-xs text-[color:var(--kalo-muted)]">{mine.motto}</p> : null}
            </div>
            <div className="shrink-0 text-right">
              <p className="text-xl font-semibold">{mine.weeklyPoints}</p>
              <p className="text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">puntos 7 dias</p>
            </div>
          </div>
          <MutexButton variant="danger" className="kalo-btn-sm w-full" onPress={leave}>
            Salir del gremio
          </MutexButton>
        </Glass>
      ) : null}

      {!mine ? (
        <Glass className="mb-4 space-y-3 p-5">
          <p className="text-sm font-semibold">Funda un gremio</p>
          <p className="text-xs leading-relaxed text-[color:var(--kalo-muted)]">
            Universidades, gimnasios o barrios. El gremio con mas puntos de disciplina de la semana gana insignias doradas.
          </p>
          <input
            className="kalo-input"
            placeholder="Nombre del gremio"
            maxLength={24}
            value={name}
            onChange={(event) => setName(event.target.value)}
            aria-label="Nombre del gremio"
          />
          <input
            className="kalo-input"
            placeholder="Lema (opcional)"
            maxLength={80}
            value={motto}
            onChange={(event) => setMotto(event.target.value)}
            aria-label="Lema del gremio"
          />
          <MutexButton className="w-full" onPress={create} busyLabel="Creando">
            Crear gremio
          </MutexButton>
        </Glass>
      ) : null}

      {error ? (
        <p role="alert" className="mb-3 text-sm text-[color:var(--kalo-danger)]">
          {error}
        </p>
      ) : null}
      {notice ? (
        <p role="status" className="mb-3 text-sm text-[color:var(--kalo-gold)]">
          {notice}
        </p>
      ) : null}

      {payload === null ? (
        <Skeleton className="h-32 w-full" />
      ) : payload.guilds.length === 0 ? (
        <Glass className="p-5 text-sm text-[color:var(--kalo-muted)]">Aun no hay gremios. Sé el primero en fundarlo.</Glass>
      ) : (
        <ol className="space-y-2">
          {payload.guilds.map((guild) => (
            <li key={guild.id} className="kalo-glass flex items-center gap-3 p-4">
              <span
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border text-sm font-semibold ${guild.rank === 1 ? "border-[rgba(229,193,88,0.6)] text-[color:var(--kalo-gold)]" : "border-white/10 text-[color:var(--kalo-muted)]"}`}
                aria-label={`Posicion ${guild.rank}`}
              >
                {guild.rank === 1 ? <Icon name="trophy" size={16} /> : guild.rank}
              </span>
              <div className="min-w-0 flex-1">
                <p className="kalo-ellipsis text-sm font-semibold">{guild.name}</p>
                <p className="text-xs text-[color:var(--kalo-muted)]">
                  {guild.members} miembros · {guild.weeklyPoints} puntos
                </p>
              </div>
              {guild.isMine ? (
                <span className="shrink-0 text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-gold)]">Tu gremio</span>
              ) : payload.myGuildId === null ? (
                <MutexButton variant="ghost" className="kalo-btn-sm shrink-0" onPress={() => join(guild.id)}>
                  Unirme
                </MutexButton>
              ) : null}
            </li>
          ))}
        </ol>
      )}
      <p className="mt-3 text-[11px] text-[color:var(--kalo-muted)]">Miembro de {user.name.split(" ")[0]}: los puntos suman con cada comida verificada.</p>
    </section>
  );
}

function RaffleBoard({ user }: { user: PublicUser }) {
  const [payload, setPayload] = useState<RafflePayload | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const result = await api<RafflePayload>("/api/social/raffle");
      if (alive && result.ok) setPayload(result.data);
    };
    void load();
    const id = window.setInterval(load, 30_000);
    return () => {
      alive = false;
      window.clearInterval(id);
    };
  }, []);

  const copyLink = async () => {
    const url = `${window.location.origin}/?ref=${user.inviteCode}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section aria-label="Sorteo de invitaciones">
      <SectionTitle eyebrow="Sorteo viral" title="Tabla del premio" />
      <Glass className="space-y-4 p-5">
        <p className="text-sm font-semibold text-[color:var(--kalo-gold)]">{payload?.prize ?? "Premio del Mes para el Top #1 en Invitaciones Verificadas"}</p>
        <p className="text-xs leading-relaxed text-[color:var(--kalo-muted)]">
          Una invitacion cuenta cuando el amigo registra su primera comida. Mas amigos verificados suben tu posicion y evolucionan tu Bio-Pou.
        </p>
        {payload === null ? (
          <Skeleton className="h-40 w-full" />
        ) : (
          <ol className="space-y-2">
            {payload.top.length === 0 ? (
              <li className="text-sm text-[color:var(--kalo-muted)]">Aun no hay invitaciones verificadas este mes.</li>
            ) : (
              payload.top.map((row) => (
                <li key={`${row.rank}-${row.name}`} className={`flex items-center justify-between gap-3 rounded-2xl border p-3 ${row.isMe ? "border-[rgba(229,193,88,0.5)]" : "border-white/[0.06]"}`}>
                  <span className="flex min-w-0 items-center gap-3">
                    <span className="w-6 shrink-0 text-center text-sm font-semibold text-[color:var(--kalo-gold)]">#{row.rank}</span>
                    <span className="kalo-ellipsis text-sm">{row.name}{row.isMe ? " (tu)" : ""}</span>
                  </span>
                  <span className="shrink-0 text-sm font-semibold">{row.verified}</span>
                </li>
              ))
            )}
          </ol>
        )}
        <div className="flex items-center justify-between gap-3 rounded-2xl bg-white/[0.03] p-3">
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-[0.14em] text-[color:var(--kalo-muted)]">Tus invitaciones verificadas</p>
            <p className="text-lg font-semibold">{payload?.mine.verified ?? 0}</p>
          </div>
          <button type="button" onClick={copyLink} className="kalo-btn kalo-btn-ghost kalo-btn-sm shrink-0">
            <Icon name="copy" size={14} />
            {copied ? "Copiado" : "Copiar enlace"}
          </button>
        </div>
      </Glass>
    </section>
  );
}

export function Community({ user, onChanged }: { user: PublicUser; onChanged: () => Promise<void> | void }) {
  return (
    <div className="kalo-fade-in space-y-10 pt-2">
      <Wall />
      <Guilds user={user} onChanged={onChanged} />
      <RaffleBoard user={user} />
    </div>
  );
}
