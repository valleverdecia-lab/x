export type Sfx = "click" | "menu" | "scan" | "levelup" | "success" | "warn" | "heartbeat" | "rip" | "slice";

const STORAGE_KEY = "kalo_sound";
let context: AudioContext | null = null;
let noise: AudioBuffer | null = null;

export function isSoundOn(): boolean {
  if (typeof window === "undefined") return false;
  return window.localStorage.getItem(STORAGE_KEY) !== "off";
}

export function setSoundOn(on: boolean): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, on ? "on" : "off");
  if (on) {
    void unlockAudio();
  } else if (context) {
    void context.suspend();
  }
}

function getContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  const Constructor =
    window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Constructor) return null;
  if (!context) context = new Constructor();
  return context;
}

export async function unlockAudio(): Promise<void> {
  const ctx = getContext();
  if (ctx && ctx.state === "suspended") {
    await ctx.resume();
  }
}

function noiseBuffer(ctx: AudioContext): AudioBuffer {
  if (!noise) {
    const length = Math.floor(ctx.sampleRate * 0.25);
    noise = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = noise.getChannelData(0);
    for (let index = 0; index < length; index++) {
      data[index] = (Math.random() * 2 - 1) * (1 - index / length);
    }
  }
  return noise;
}

interface ToneOptions {
  type: OscillatorType;
  from: number;
  to?: number;
  start?: number;
  duration: number;
  gain: number;
  lowpass?: number;
}

function tone(ctx: AudioContext, options: ToneOptions): void {
  const t0 = ctx.currentTime + (options.start ?? 0);
  const oscillator = ctx.createOscillator();
  const amp = ctx.createGain();
  oscillator.type = options.type;
  oscillator.frequency.setValueAtTime(options.from, t0);
  if (options.to) {
    oscillator.frequency.exponentialRampToValueAtTime(options.to, t0 + options.duration);
  }
  amp.gain.setValueAtTime(0.0001, t0);
  amp.gain.exponentialRampToValueAtTime(options.gain, t0 + 0.012);
  amp.gain.exponentialRampToValueAtTime(0.0001, t0 + options.duration);

  let source: AudioNode = oscillator;
  if (options.lowpass) {
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = options.lowpass;
    oscillator.connect(filter);
    source = filter;
  }
  source.connect(amp);
  amp.connect(ctx.destination);
  oscillator.start(t0);
  oscillator.stop(t0 + options.duration + 0.02);
}

export function play(sfx: Sfx): void {
  if (!isSoundOn()) return;
  const ctx = getContext();
  if (!ctx) return;
  if (ctx.state === "suspended") void ctx.resume();

  switch (sfx) {
    case "click":
      tone(ctx, { type: "sine", from: 1800, to: 900, duration: 0.05, gain: 0.07 });
      break;
    case "menu":
      tone(ctx, { type: "triangle", from: 880, to: 660, duration: 0.09, gain: 0.05 });
      break;
    case "scan":
      tone(ctx, { type: "sawtooth", from: 260, to: 1900, duration: 0.42, gain: 0.035, lowpass: 2400 });
      tone(ctx, { type: "sine", from: 2400, to: 2600, start: 0.36, duration: 0.12, gain: 0.05 });
      break;
    case "levelup":
      [523.25, 659.25, 783.99, 1046.5].forEach((frequency, index) => {
        tone(ctx, { type: "triangle", from: frequency, start: index * 0.075, duration: 0.5, gain: 0.08 });
      });
      break;
    case "success":
      tone(ctx, { type: "sine", from: 880, to: 1320, duration: 0.16, gain: 0.07 });
      break;
    case "warn":
      tone(ctx, { type: "square", from: 220, duration: 0.12, gain: 0.03, lowpass: 900 });
      tone(ctx, { type: "square", from: 220, start: 0.18, duration: 0.12, gain: 0.03, lowpass: 900 });
      break;
    case "heartbeat":
      tone(ctx, { type: "sine", from: 70, to: 45, duration: 0.14, gain: 0.25 });
      tone(ctx, { type: "sine", from: 62, to: 40, start: 0.18, duration: 0.14, gain: 0.18 });
      break;
    case "slice":
      tone(ctx, { type: "sawtooth", from: 2400, to: 400, duration: 0.18, gain: 0.03, lowpass: 3200 });
      break;
    case "rip": {
      const source = ctx.createBufferSource();
      source.buffer = noiseBuffer(ctx);
      const filter = ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(3000, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.3);
      const amp = ctx.createGain();
      amp.gain.value = 0.22;
      source.connect(filter);
      filter.connect(amp);
      amp.connect(ctx.destination);
      source.start();
      break;
    }
  }
}
