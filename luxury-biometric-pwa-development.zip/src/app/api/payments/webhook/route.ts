import { createHmac, timingSafeEqual } from "node:crypto";
import { fulfillPurchase } from "@/lib/server/services";
import { webhookSchema } from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

const MAX_SKEW_SECONDS = 300;

export async function POST(req: Request) {
  const secret = process.env.PAYMENT_WEBHOOK_SECRET?.trim();
  if (!secret) return Response.json({ error: "Webhook no configurado" }, { status: 503 });

  const raw = await req.text();
  const timestamp = req.headers.get("x-kalo-timestamp") ?? "";
  const signature = (req.headers.get("x-kalo-signature") ?? "").replace(/^sha256=/, "");

  const issuedAt = Number(timestamp);
  if (!Number.isFinite(issuedAt) || Math.abs(Date.now() / 1000 - issuedAt) > MAX_SKEW_SECONDS) {
    return Response.json({ error: "Firma caducada" }, { status: 401 });
  }

  const expected = createHmac("sha256", secret).update(`${timestamp}.${raw}`).digest("hex");
  const given = Buffer.from(signature);
  const wanted = Buffer.from(expected);
  if (given.length !== wanted.length || !timingSafeEqual(given, wanted)) {
    return Response.json({ error: "Firma no valida" }, { status: 401 });
  }

  let payload: unknown;
  try {
    payload = JSON.parse(raw);
  } catch {
    return Response.json({ error: "Cuerpo no valido" }, { status: 400 });
  }
  const parsed = webhookSchema.safeParse(payload);
  if (!parsed.success) return Response.json({ error: "Evento no valido" }, { status: 400 });

  if (parsed.data.status !== "paid") {
    return Response.json({ ok: true, activated: false });
  }
  const settled = await fulfillPurchase(parsed.data.reference, parsed.data.providerRef ?? null);
  return Response.json({ ok: true, activated: settled !== null });
}
