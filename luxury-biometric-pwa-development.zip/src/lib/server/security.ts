import { and, eq, gt, sql } from "drizzle-orm";
import { cookies, headers } from "next/headers";
import type { z } from "zod";
import { db } from "@/db";
import { idempotencyKeys, rateLimits, sessions, users } from "@/db/schema";
import { OWNER_EMAIL, type PublicUser } from "@/lib/shared/domain";
import { randomToken, sha256Hex } from "./crypto";
import { ensureDbSecurity } from "./db";

export const SESSION_COOKIE = "kalo_session";
const SESSION_DAYS = 14;

type UserRow = typeof users.$inferSelect;

export function toPublicUser(row: UserRow, vipActive: boolean): PublicUser {
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    age: row.age,
    role: row.role === "owner" ? "owner" : "user",
    vipActive,
    vipTier: row.vipTier === "god" || row.vipTier === "basic" ? row.vipTier : "none",
    vipUntil: row.vipUntil ? row.vipUntil.toISOString() : null,
    vipPermanent: row.vipPermanent,
    inviteCode: row.inviteCode,
    affiliateId: row.affiliateId,
    invitedByUserId: row.invitedByUserId,
    streakDays: row.streakDays,
    streakLastDay: row.streakLastDay,
    xp: row.xp,
    goalKcal: row.goalKcal,
    goalProtein: row.goalProtein,
    dietPlan: row.dietPlan,
    theme: row.theme,
    unlockedThemes: row.unlockedThemes,
    promiseSignedAt: row.promiseSignedAt ? row.promiseSignedAt.toISOString() : null,
    flashOfferUntil: row.flashOfferUntil ? row.flashOfferUntil.toISOString() : null,
    lastActivityAt: row.lastActivityAt.toISOString(),
    createdAt: row.createdAt.toISOString(),
  };
}

export async function loadPublicUser(userId: string): Promise<PublicUser | null> {
  const [row] = await db
    .select({
      user: users,
      vipActive: sql<boolean>`(${users.vipPermanent} or ${users.vipUntil} > now())`,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  return row ? toPublicUser(row.user, Boolean(row.vipActive)) : null;
}

export async function getSessionUser(): Promise<PublicUser | null> {
  await ensureDbSecurity();
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token || token.length < 20 || token.length > 128) return null;
  const [row] = await db
    .select({
      user: users,
      vipActive: sql<boolean>`(${users.vipPermanent} or ${users.vipUntil} > now())`,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.tokenHash, sha256Hex(token)), gt(sessions.expiresAt, sql`now()`)))
    .limit(1);
  if (!row) return null;
  return toPublicUser(row.user, Boolean(row.vipActive));
}

export async function createSession(userId: string): Promise<void> {
  const token = randomToken();
  const requestHeaders = await headers();
  const proto = (requestHeaders.get("x-forwarded-proto") ?? "http").split(",")[0]?.trim();
  await db.insert(sessions).values({
    userId,
    tokenHash: sha256Hex(token),
    expiresAt: sql`now() + make_interval(days => ${SESSION_DAYS})`,
    ip: (await clientIp()).slice(0, 64),
    userAgent: (requestHeaders.get("user-agent") ?? "").slice(0, 200),
  });
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: proto === "https",
    sameSite: "strict",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  });
}

export async function destroySession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.tokenHash, sha256Hex(token)));
  }
  jar.delete(SESSION_COOKIE);
}

export async function clientIp(): Promise<string> {
  const requestHeaders = await headers();
  const forwarded = requestHeaders.get("x-forwarded-for")?.split(",")[0]?.trim();
  return (forwarded || requestHeaders.get("x-real-ip") || "unknown").slice(0, 64);
}

export function isOwner(user: PublicUser | null): user is PublicUser {
  return user !== null && user.role === "owner" && user.email === OWNER_EMAIL;
}

export async function rateLimitCheck(key: string): Promise<number> {
  const [row] = await db
    .select({ blockedUntil: rateLimits.blockedUntil })
    .from(rateLimits)
    .where(eq(rateLimits.key, key))
    .limit(1);
  if (!row?.blockedUntil) return 0;
  return Math.max(0, Math.ceil((row.blockedUntil.getTime() - Date.now()) / 1000));
}

export async function rateLimitFail(key: string, maxAttempts = 5, windowMs = 60_000): Promise<number> {
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${key}))`);
    const now = Date.now();
    const [row] = await tx.select().from(rateLimits).where(eq(rateLimits.key, key)).limit(1);
    let windowBegin = row ? row.windowStartedAt.getTime() : now;
    let attempts = row?.attempts ?? 0;
    const strikes = row?.strikes ?? 0;
    let nextStrikes = strikes;
    if (now - windowBegin > windowMs) {
      windowBegin = now;
      attempts = 0;
    }
    attempts += 1;
    let retry = 0;
    let blockedUntil: Date | null = null;
    if (attempts >= maxAttempts) {
      nextStrikes = strikes + 1;
      retry = Math.min(900, 30 * 2 ** (nextStrikes - 1));
      blockedUntil = new Date(now + retry * 1000);
      attempts = 0;
      windowBegin = now;
    }
    const values = {
      attempts,
      windowStartedAt: new Date(windowBegin),
      strikes: nextStrikes,
      blockedUntil,
      updatedAt: new Date(now),
    };
    await tx.insert(rateLimits).values({ key, ...values }).onConflictDoUpdate({ target: rateLimits.key, set: values });
    return retry;
  });
}

export async function rateLimitReset(key: string): Promise<void> {
  await db.delete(rateLimits).where(eq(rateLimits.key, key));
}

export function readIdempotencyKey(req: Request): string | null {
  const key = req.headers.get("idempotency-key");
  return key && /^[A-Za-z0-9-]{16,64}$/.test(key) ? key : null;
}

export interface IdempotentResult {
  status: number;
  body: Record<string, unknown>;
}

export async function withIdempotency(
  scope: string,
  key: string,
  run: () => Promise<IdempotentResult>,
): Promise<IdempotentResult> {
  const claimed = await db
    .insert(idempotencyKeys)
    .values({ scope, key })
    .onConflictDoNothing()
    .returning({ key: idempotencyKeys.key });

  if (claimed.length === 0) {
    const [existing] = await db
      .select()
      .from(idempotencyKeys)
      .where(and(eq(idempotencyKeys.scope, scope), eq(idempotencyKeys.key, key)))
      .limit(1);
    if (!existing || existing.responseStatus === null) {
      return { status: 409, body: { error: "La solicitud ya se esta procesando." } };
    }
    return { status: existing.responseStatus, body: { ...(existing.responseBody ?? {}), replayed: true } };
  }

  try {
    const result = await run();
    await db
      .update(idempotencyKeys)
      .set({ responseStatus: result.status, responseBody: result.body })
      .where(and(eq(idempotencyKeys.scope, scope), eq(idempotencyKeys.key, key)));
    return result;
  } catch (error) {
    await db
      .delete(idempotencyKeys)
      .where(and(eq(idempotencyKeys.scope, scope), eq(idempotencyKeys.key, key)));
    throw error;
  }
}

export function assertSameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export async function readJson<T extends z.ZodType>(
  req: Request,
  schema: T,
): Promise<{ ok: true; data: z.output<T> } | { ok: false; response: Response }> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return { ok: false, response: Response.json({ error: "Cuerpo de solicitud no valido" }, { status: 400 }) };
  }
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    const message = parsed.error.issues[0]?.message ?? "Datos no validos";
    return { ok: false, response: Response.json({ error: message }, { status: 400 }) };
  }
  return { ok: true, data: parsed.data as z.output<T> };
}
