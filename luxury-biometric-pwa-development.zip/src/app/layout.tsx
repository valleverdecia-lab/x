import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "KALO // AURA AI",
  description: "Escaner biometrico de nutricion latina y global, analisis de fisico y Bio-Pou simbiotico.",
  applicationName: "KALO",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    title: "KALO",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: "/icons/kalo.svg",
    apple: "/icons/kalo.svg",
  },
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  themeColor: "#070709",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body className="bg-[#070709] text-[#F4F4F6] antialiased">{children}</body>
    </html>
  );
}
