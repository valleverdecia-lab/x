"use client";

import { useEffect, useRef } from "react";
import { play } from "@/lib/client/audio";
import { Icon } from "./ui";

interface BioPouProps {
  energy: number;
  stage: string;
  size?: number;
}

function paletteFor(energy: number) {
  if (energy >= 60) return { core: "#E5C158", glow: "rgba(229,193,88,0.55)", ring: "#F4DA8C" };
  if (energy >= 30) return { core: "#B8922F", glow: "rgba(184,146,47,0.35)", ring: "#8A6D2A" };
  return { core: "#5C5C66", glow: "rgba(92,92,102,0.25)", ring: "#3A3A42" };
}

export function BioPou({ energy, stage, size = 220 }: BioPouProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const energyRef = useRef(energy);

  useEffect(() => {
    energyRef.current = energy;
  }, [energy]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width = `${size}px`;
    canvas.style.height = `${size}px`;
    context.setTransform(dpr, 0, 0, dpr, 0, 0);

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let frame = 0;
    let raf = 0;
    const center = size / 2;
    const stageRadius = size * 0.26;

    const draw = () => {
      const level = energyRef.current;
      const palette = paletteFor(level);
      const speed = 0.004 + (level / 100) * 0.012;
      const pulse = reduced ? 1 : 1 + Math.sin(frame * (0.03 + level / 2000)) * (0.02 + level / 1500);
      context.clearRect(0, 0, size, size);

      const glow = context.createRadialGradient(center, center, stageRadius * 0.2, center, center, size * 0.5);
      glow.addColorStop(0, palette.glow);
      glow.addColorStop(1, "rgba(0,0,0,0)");
      context.fillStyle = glow;
      context.fillRect(0, 0, size, size);

      for (let ring = 0; ring < 3; ring++) {
        const radiusX = size * (0.36 + ring * 0.05) * pulse;
        const radiusY = radiusX * (0.36 + ring * 0.08);
        const angle = frame * speed * (ring % 2 === 0 ? 1 : -1.4) + ring * 1.1;
        context.save();
        context.translate(center, center);
        context.rotate(angle);
        context.beginPath();
        context.ellipse(0, 0, radiusX, radiusY, 0, 0, Math.PI * 2);
        context.strokeStyle = palette.ring;
        context.globalAlpha = Math.max(0.12, level / 100) * (0.9 - ring * 0.2);
        context.lineWidth = 1.2;
        context.stroke();
        const orbX = Math.cos(frame * speed * 3 + ring) * radiusX;
        const orbY = Math.sin(frame * speed * 3 + ring) * radiusY;
        context.globalAlpha = Math.max(0.2, level / 100);
        context.beginPath();
        context.arc(orbX, orbY, 3 + ring * 0.6, 0, Math.PI * 2);
        context.fillStyle = palette.core;
        context.fill();
        context.restore();
      }

      context.save();
      context.translate(center, center);
      context.rotate(frame * speed * 0.6);
      const sides = 6;
      context.beginPath();
      for (let index = 0; index <= sides; index++) {
        const angle = (index / sides) * Math.PI * 2;
        const radius = stageRadius * pulse;
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        if (index === 0) context.moveTo(x, y);
        else context.lineTo(x, y);
      }
      context.closePath();
      const fill = context.createLinearGradient(-stageRadius, -stageRadius, stageRadius, stageRadius);
      fill.addColorStop(0, palette.ring);
      fill.addColorStop(1, palette.core);
      context.globalAlpha = 0.15 + (level / 100) * 0.85;
      context.fillStyle = fill;
      context.shadowColor = palette.core;
      context.shadowBlur = 10 + (level / 100) * 26;
      context.fill();
      context.lineWidth = 1.4;
      context.strokeStyle = palette.ring;
      context.stroke();
      context.restore();

      context.save();
      context.globalAlpha = 0.9;
      context.fillStyle = "#070709";
      context.beginPath();
      context.arc(center, center, stageRadius * 0.28, 0, Math.PI * 2);
      context.fill();
      context.restore();

      frame += 1;
      raf = window.requestAnimationFrame(draw);
    };

    raf = window.requestAnimationFrame(draw);
    return () => window.cancelAnimationFrame(raf);
  }, [size]);

  return (
    <div className="relative flex flex-col items-center" role="img" aria-label={`Bio-Pou ${stage}, energia ${energy} por ciento`}>
      <canvas ref={canvasRef} className="kalo-pou-breathe" aria-hidden="true" />
      <span className="mt-1 text-[10px] uppercase tracking-[0.22em] text-[color:var(--kalo-muted)]">{stage}</span>
    </div>
  );
}

export function BioAlert({ energy }: { energy: number }) {
  useEffect(() => {
    if (energy >= 30) return;
    play("heartbeat");
    const id = window.setInterval(() => play("heartbeat"), 1400);
    return () => window.clearInterval(id);
  }, [energy]);

  if (energy >= 30) return null;
  return (
    <div className="flex items-start gap-3 rounded-2xl border border-[rgba(255,123,123,0.25)] bg-[rgba(255,123,123,0.06)] p-3">
      <span className="mt-0.5 text-[color:var(--kalo-danger)]">
        <Icon name="alert" size={18} />
      </span>
      <p className="text-sm leading-snug text-[color:var(--kalo-titanium)]">
        Tu Bio-Core esta al <strong>{energy}%</strong> de energia vital y tus puntos de Gremio estan en riesgo. Escanea tu proxima comida o comparte tu enlace para alimentarlo.
      </p>
    </div>
  );
}

export function BioWidget({ energy, stage, streak }: { energy: number; stage: string; streak: number }) {
  return (
    <div className="kalo-glass flex items-center gap-4 p-4" aria-label="Vista previa del widget de inicio">
      <BioPou energy={energy} stage={stage} size={92} />
      <div className="min-w-0 flex-1">
        <p className="text-[10px] uppercase tracking-[0.2em] text-[color:var(--kalo-muted)]">Live Widget</p>
        <p className="mt-1 text-sm font-semibold">Energia {energy}%</p>
        <p className="kalo-ellipsis text-xs text-[color:var(--kalo-muted)]">Racha de {streak} dias</p>
        <p className="mt-2 text-[10px] leading-snug text-[color:var(--kalo-muted)]">
          Vista previa. El widget nativo se activa al instalar la app desde el navegador o el APK.
        </p>
      </div>
    </div>
  );
}
