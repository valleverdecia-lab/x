import KaloShell from "@/components/kalo/Shell";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <KaloShell />;
}
