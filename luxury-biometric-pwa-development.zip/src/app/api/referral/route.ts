import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { affiliateClicks, affiliates, users } from "@/db/schema";
import { sha256Hex } from "@/lib/server/crypto";
import { ensureDbSecurity } from "@/lib/server/db";
import { assertSameOrigin, clientIp, rateLimitCheck, rateLimitFail, readJson } from "@/lib/server/security";
import { referralSchema } from "@/lib/shared/schemas";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  if (!assertSameOrigin(req)) return Response.json({ error: "Origen no permitido" }, { status: 403 });
  await ensureDbSecurity();

  const parsed = await readJson(req, referralSchema);
  if (!parsed.ok) return parsed.response;

  const ip = await clientIp();
  const ipKey = `ref:ip:${ip}`;
  const wait = await rateLimitCheck(ipKey);
  if (wait > 0) {
    return Response.json({ error: "Demasiadas consultas. Espera un momento.", retryAfter: wait }, { status: 429 });
  }

  const code = parsed.data.code;
  const [affiliate] = await db
    .select({ id: affiliates.id })
    .from(affiliates)
    .where(and(eq(affiliates.code, code), eq(affiliates.active, true)))
    .limit(1);

  if (affiliate) {
    const userAgent = req.headers.get("user-agent") ?? "";
    await db
      .insert(affiliateClicks)
      .values({ affiliateId: affiliate.id, visitorHash: sha256Hex(`${ip}|${userAgent}`) })
      .onConflictDoNothing();
    return Response.json({ valid: true, kind: "affiliate" });
  }

  const [inviter] = await db.select({ id: users.id }).from(users).where(eq(users.inviteCode, code)).limit(1);
  if (inviter) return Response.json({ valid: true, kind: "invite" });

  await rateLimitFail(ipKey, 10, 60_000);
  return Response.json({ valid: false });
}
