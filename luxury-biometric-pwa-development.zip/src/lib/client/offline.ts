"use client";

const DB_NAME = "kalo_offline";
const DB_VERSION = 1;

export interface QueuedMeal {
  clientId: string;
  catalogId: string;
  grams: number;
  name: string;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  queuedAt: number;
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains("queue")) {
        database.createObjectStore("queue", { keyPath: "clientId" });
      }
      if (!database.objectStoreNames.contains("cache")) {
        database.createObjectStore("cache", { keyPath: "key" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function run<T>(
  store: "queue" | "cache",
  mode: IDBTransactionMode,
  operation: (objectStore: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const database = await openDatabase();
  return new Promise<T>((resolve, reject) => {
    const transaction = database.transaction(store, mode);
    const request = operation(transaction.objectStore(store));
    transaction.oncomplete = () => {
      database.close();
      resolve(request.result);
    };
    transaction.onerror = () => {
      database.close();
      reject(transaction.error);
    };
    transaction.onabort = () => {
      database.close();
      reject(transaction.error);
    };
  });
}

export function queueAdd(item: QueuedMeal): Promise<IDBValidKey> {
  return run("queue", "readwrite", (store) => store.put(item));
}

export async function queueList(): Promise<QueuedMeal[]> {
  const rows = await run<QueuedMeal[]>("queue", "readonly", (store) => store.getAll());
  return rows.sort((a, b) => a.queuedAt - b.queuedAt);
}

export function queueRemove(clientId: string): Promise<undefined> {
  return run("queue", "readwrite", (store) => store.delete(clientId));
}

export function cacheSet<T>(key: string, value: T): Promise<IDBValidKey> {
  return run("cache", "readwrite", (store) => store.put({ key, value, savedAt: Date.now() }));
}

export async function cacheGet<T>(key: string): Promise<T | null> {
  const row = await run<{ key: string; value: T } | undefined>("cache", "readonly", (store) => store.get(key));
  return row ? row.value : null;
}
